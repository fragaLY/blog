var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "699180",
        "ok": "581761",
        "ko": "117419"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "1",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "23845",
        "ok": "23845",
        "ko": "23236"
    },
    "meanResponseTime": {
        "total": "12220",
        "ok": "14045",
        "ko": "3174"
    },
    "standardDeviation": {
        "total": "6304",
        "ok": "4468",
        "ko": "6273"
    },
    "percentiles1": {
        "total": "15069",
        "ok": "15268",
        "ko": "0"
    },
    "percentiles2": {
        "total": "15944",
        "ok": "16091",
        "ko": "1"
    },
    "percentiles3": {
        "total": "18955",
        "ok": "19078",
        "ko": "16383"
    },
    "percentiles4": {
        "total": "21288",
        "ok": "21433",
        "ko": "19229"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 13807,
    "percentage": 2
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 5016,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 562938,
    "percentage": 81
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 117419,
    "percentage": 17
},
    "meanNumberOfRequestsPerSecond": {
        "total": "631.599",
        "ok": "525.529",
        "ko": "106.07"
    }
},
contents: {
"req_-get--the-list--c0b76": {
        type: "REQUEST",
        name: "[GET] The list of available countries is presented.",
path: "[GET] The list of available countries is presented.",
pathFormatted: "req_-get--the-list--c0b76",
stats: {
    "name": "[GET] The list of available countries is presented.",
    "numberOfRequests": {
        "total": "149808",
        "ok": "58052",
        "ko": "91756"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "3",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "23845",
        "ok": "23845",
        "ko": "1062"
    },
    "meanResponseTime": {
        "total": "5416",
        "ok": "13971",
        "ko": "3"
    },
    "standardDeviation": {
        "total": "7424",
        "ok": "4767",
        "ko": "33"
    },
    "percentiles1": {
        "total": "1",
        "ok": "15363",
        "ko": "0"
    },
    "percentiles2": {
        "total": "14951",
        "ok": "16194",
        "ko": "0"
    },
    "percentiles3": {
        "total": "17131",
        "ok": "19126",
        "ko": "1"
    },
    "percentiles4": {
        "total": "20088",
        "ok": "21806",
        "ko": "108"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2008,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 610,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 55434,
    "percentage": 37
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 91756,
    "percentage": 61
},
    "meanNumberOfRequestsPerSecond": {
        "total": "135.328",
        "ok": "52.441",
        "ko": "82.887"
    }
}
    },"req_-get--the-list--3525d": {
        type: "REQUEST",
        name: "[GET] The list of available cities is presented.",
path: "[GET] The list of available cities is presented.",
pathFormatted: "req_-get--the-list--3525d",
stats: {
    "name": "[GET] The list of available cities is presented.",
    "numberOfRequests": {
        "total": "116104",
        "ok": "116104",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "23302",
        "ok": "23302",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14206",
        "ok": "14206",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4315",
        "ok": "4315",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15276",
        "ok": "15277",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16088",
        "ok": "16092",
        "ko": "-"
    },
    "percentiles3": {
        "total": "19104",
        "ok": "19097",
        "ko": "-"
    },
    "percentiles4": {
        "total": "21435",
        "ok": "21435",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2971,
    "percentage": 3
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 984,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 112149,
    "percentage": 97
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "104.882",
        "ok": "104.882",
        "ko": "-"
    }
}
    },"req_-get--the-list--11d52": {
        type: "REQUEST",
        name: "[GET] The list of available origins is presented.",
path: "[GET] The list of available origins is presented.",
pathFormatted: "req_-get--the-list--11d52",
stats: {
    "name": "[GET] The list of available origins is presented.",
    "numberOfRequests": {
        "total": "58052",
        "ok": "58052",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "23288",
        "ok": "23288",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14189",
        "ok": "14189",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4312",
        "ok": "4312",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15233",
        "ok": "15233",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16062",
        "ok": "16058",
        "ko": "-"
    },
    "percentiles3": {
        "total": "19145",
        "ok": "19145",
        "ko": "-"
    },
    "percentiles4": {
        "total": "21343",
        "ok": "21343",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1559,
    "percentage": 3
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 463,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 56030,
    "percentage": 97
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "52.441",
        "ok": "52.441",
        "ko": "-"
    }
}
    },"req_-get--the-list--0dc40": {
        type: "REQUEST",
        name: "[GET] The list of available destinations is presented.",
path: "[GET] The list of available destinations is presented.",
pathFormatted: "req_-get--the-list--0dc40",
stats: {
    "name": "[GET] The list of available destinations is presented.",
    "numberOfRequests": {
        "total": "58052",
        "ok": "58052",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "23279",
        "ok": "23279",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14431",
        "ok": "14431",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4019",
        "ok": "4019",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15262",
        "ok": "15262",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16156",
        "ok": "16157",
        "ko": "-"
    },
    "percentiles3": {
        "total": "19214",
        "ok": "19214",
        "ko": "-"
    },
    "percentiles4": {
        "total": "21050",
        "ok": "21050",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 945,
    "percentage": 2
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 471,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 56636,
    "percentage": 98
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "52.441",
        "ok": "52.441",
        "ko": "-"
    }
}
    },"req_-get--the-list--8bddb": {
        type: "REQUEST",
        name: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
path: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
pathFormatted: "req_-get--the-list--8bddb",
stats: {
    "name": "[GET] The list of available transfers by selected origin, destination, and date is presented.",
    "numberOfRequests": {
        "total": "58052",
        "ok": "32389",
        "ko": "25663"
    },
    "minResponseTime": {
        "total": "5",
        "ok": "8",
        "ko": "5"
    },
    "maxResponseTime": {
        "total": "23263",
        "ok": "23263",
        "ko": "23236"
    },
    "meanResponseTime": {
        "total": "14505",
        "ok": "14500",
        "ko": "14511"
    },
    "standardDeviation": {
        "total": "3952",
        "ok": "3955",
        "ko": "3949"
    },
    "percentiles1": {
        "total": "15372",
        "ok": "15361",
        "ko": "15384"
    },
    "percentiles2": {
        "total": "16225",
        "ok": "16221",
        "ko": "16234"
    },
    "percentiles3": {
        "total": "19194",
        "ok": "19218",
        "ko": "19162"
    },
    "percentiles4": {
        "total": "21109",
        "ok": "21157",
        "ko": "20992"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 316,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 231,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 31842,
    "percentage": 55
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 25663,
    "percentage": 44
},
    "meanNumberOfRequestsPerSecond": {
        "total": "52.441",
        "ok": "29.258",
        "ko": "23.182"
    }
}
    },"req_-post--the-tran-5ac29": {
        type: "REQUEST",
        name: "[POST] The transfer is booked in the system.",
path: "[POST] The transfer is booked in the system.",
pathFormatted: "req_-post--the-tran-5ac29",
stats: {
    "name": "[POST] The transfer is booked in the system.",
    "numberOfRequests": {
        "total": "32389",
        "ok": "32389",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "176",
        "ok": "176",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "23313",
        "ok": "23313",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14452",
        "ok": "14452",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4037",
        "ok": "4037",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15373",
        "ok": "15373",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16197",
        "ok": "16196",
        "ko": "-"
    },
    "percentiles3": {
        "total": "19254",
        "ok": "19254",
        "ko": "-"
    },
    "percentiles4": {
        "total": "21951",
        "ok": "21951",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 97,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 249,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 32043,
    "percentage": 99
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "29.258",
        "ok": "29.258",
        "ko": "-"
    }
}
    },"req_-get--the-list--4f742": {
        type: "REQUEST",
        name: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
path: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
pathFormatted: "req_-get--the-list--4f742",
stats: {
    "name": "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
    "numberOfRequests": {
        "total": "32389",
        "ok": "32389",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "554",
        "ok": "554",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "23319",
        "ok": "23319",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14266",
        "ok": "14266",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4101",
        "ok": "4101",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15294",
        "ok": "15294",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16102",
        "ok": "16102",
        "ko": "-"
    },
    "percentiles3": {
        "total": "19096",
        "ok": "19096",
        "ko": "-"
    },
    "percentiles4": {
        "total": "21548",
        "ok": "21551",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 15,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 205,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 32169,
    "percentage": 99
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "29.258",
        "ok": "29.258",
        "ko": "-"
    }
}
    },"req_-get--one-of-th-c14cc": {
        type: "REQUEST",
        name: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
path: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
pathFormatted: "req_-get--one-of-th-c14cc",
stats: {
    "name": "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
    "numberOfRequests": {
        "total": "32389",
        "ok": "32389",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "782",
        "ok": "782",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "23256",
        "ok": "23256",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14107",
        "ok": "14107",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4231",
        "ok": "4231",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15283",
        "ok": "15283",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16075",
        "ok": "16075",
        "ko": "-"
    },
    "percentiles3": {
        "total": "18986",
        "ok": "18986",
        "ko": "-"
    },
    "percentiles4": {
        "total": "21409",
        "ok": "21409",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 7,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 109,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 32273,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "29.258",
        "ok": "29.258",
        "ko": "-"
    }
}
    },"req_-put--any--book-143cf": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer description is updated.",
path: "[PUT] Any (BOOKED) transfer description is updated.",
pathFormatted: "req_-put--any--book-143cf",
stats: {
    "name": "[PUT] Any (BOOKED) transfer description is updated.",
    "numberOfRequests": {
        "total": "32389",
        "ok": "32389",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "148",
        "ok": "148",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "23257",
        "ok": "23257",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "13869",
        "ok": "13869",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4430",
        "ok": "4430",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15207",
        "ok": "15206",
        "ko": "-"
    },
    "percentiles2": {
        "total": "15999",
        "ok": "16000",
        "ko": "-"
    },
    "percentiles3": {
        "total": "18892",
        "ok": "18892",
        "ko": "-"
    },
    "percentiles4": {
        "total": "21356",
        "ok": "21356",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 208,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 274,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 31907,
    "percentage": 99
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "29.258",
        "ok": "29.258",
        "ko": "-"
    }
}
    },"req_-put--any--book-bb16d": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
path: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
pathFormatted: "req_-put--any--book-bb16d",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
    "numberOfRequests": {
        "total": "32389",
        "ok": "32389",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "23278",
        "ok": "23278",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "13675",
        "ok": "13675",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4620",
        "ok": "4620",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15172",
        "ok": "15172",
        "ko": "-"
    },
    "percentiles2": {
        "total": "15962",
        "ok": "15962",
        "ko": "-"
    },
    "percentiles3": {
        "total": "18736",
        "ok": "18736",
        "ko": "-"
    },
    "percentiles4": {
        "total": "21061",
        "ok": "21056",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 613,
    "percentage": 2
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 399,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 31377,
    "percentage": 97
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "29.258",
        "ok": "29.258",
        "ko": "-"
    }
}
    },"req_-put--any--book-fdf7e": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
path: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
pathFormatted: "req_-put--any--book-fdf7e",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
    "numberOfRequests": {
        "total": "32389",
        "ok": "32389",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "23285",
        "ok": "23285",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "13540",
        "ok": "13540",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4878",
        "ok": "4878",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15194",
        "ok": "15194",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16016",
        "ok": "16015",
        "ko": "-"
    },
    "percentiles3": {
        "total": "18770",
        "ok": "18766",
        "ko": "-"
    },
    "percentiles4": {
        "total": "21267",
        "ok": "21268",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1165,
    "percentage": 4
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 402,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 30822,
    "percentage": 95
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "29.258",
        "ok": "29.258",
        "ko": "-"
    }
}
    },"req_-get--user-is-r-f03f4": {
        type: "REQUEST",
        name: "[GET] User is retrieved with her/his transfers data.",
path: "[GET] User is retrieved with her/his transfers data.",
pathFormatted: "req_-get--user-is-r-f03f4",
stats: {
    "name": "[GET] User is retrieved with her/his transfers data.",
    "numberOfRequests": {
        "total": "32389",
        "ok": "32389",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "23290",
        "ok": "23290",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "13417",
        "ok": "13417",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5151",
        "ok": "5151",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15207",
        "ok": "15206",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16009",
        "ok": "16009",
        "ko": "-"
    },
    "percentiles3": {
        "total": "18951",
        "ok": "18951",
        "ko": "-"
    },
    "percentiles4": {
        "total": "21732",
        "ok": "21730",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1722,
    "percentage": 5
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 325,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 30342,
    "percentage": 94
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "29.258",
        "ok": "29.258",
        "ko": "-"
    }
}
    },"req_-put--user-upda-c8c46": {
        type: "REQUEST",
        name: "[PUT] User updates with her/his own data.",
path: "[PUT] User updates with her/his own data.",
pathFormatted: "req_-put--user-upda-c8c46",
stats: {
    "name": "[PUT] User updates with her/his own data.",
    "numberOfRequests": {
        "total": "32389",
        "ok": "32389",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "23324",
        "ok": "23324",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "13191",
        "ok": "13191",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5338",
        "ok": "5338",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15196",
        "ok": "15196",
        "ko": "-"
    },
    "percentiles2": {
        "total": "15976",
        "ok": "15976",
        "ko": "-"
    },
    "percentiles3": {
        "total": "18786",
        "ok": "18783",
        "ko": "-"
    },
    "percentiles4": {
        "total": "21549",
        "ok": "21558",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2181,
    "percentage": 7
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 294,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 29914,
    "percentage": 92
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "29.258",
        "ok": "29.258",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
