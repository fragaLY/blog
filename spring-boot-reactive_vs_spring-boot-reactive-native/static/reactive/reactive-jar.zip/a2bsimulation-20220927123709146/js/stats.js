var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "1168782",
        "ok": "1079847",
        "ko": "88935"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "1",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "17158",
        "ok": "17158",
        "ko": "16167"
    },
    "meanResponseTime": {
        "total": "3721",
        "ok": "3855",
        "ko": "2092"
    },
    "standardDeviation": {
        "total": "4048",
        "ok": "4059",
        "ko": "3535"
    },
    "percentiles1": {
        "total": "1772",
        "ok": "2228",
        "ko": "5"
    },
    "percentiles2": {
        "total": "7352",
        "ok": "7476",
        "ko": "3203"
    },
    "percentiles3": {
        "total": "10406",
        "ok": "10494",
        "ko": "9639"
    },
    "percentiles4": {
        "total": "14101",
        "ok": "14162",
        "ko": "12909"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 438792,
    "percentage": 38
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 54729,
    "percentage": 5
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 586326,
    "percentage": 50
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 88935,
    "percentage": 8
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1091.3",
        "ok": "1008.261",
        "ko": "83.039"
    }
},
contents: {
"req_-get--the-list--c0b76": {
        type: "REQUEST",
        name: "[GET] The list of available countries is presented.",
path: "[GET] The list of available countries is presented.",
pathFormatted: "req_-get--the-list--c0b76",
stats: {
    "name": "[GET] The list of available countries is presented.",
    "numberOfRequests": {
        "total": "149158",
        "ok": "107568",
        "ko": "41590"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "1",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "17158",
        "ok": "17158",
        "ko": "1450"
    },
    "meanResponseTime": {
        "total": "2764",
        "ok": "3829",
        "ko": "8"
    },
    "standardDeviation": {
        "total": "3885",
        "ok": "4105",
        "ko": "74"
    },
    "percentiles1": {
        "total": "62",
        "ok": "1972",
        "ko": "0"
    },
    "percentiles2": {
        "total": "6282",
        "ok": "7554",
        "ko": "1"
    },
    "percentiles3": {
        "total": "10055",
        "ok": "10577",
        "ko": "3"
    },
    "percentiles4": {
        "total": "13956",
        "ok": "14342",
        "ko": "227"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 44205,
    "percentage": 30
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 5613,
    "percentage": 4
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 57750,
    "percentage": 39
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 41590,
    "percentage": 28
},
    "meanNumberOfRequestsPerSecond": {
        "total": "139.27",
        "ok": "100.437",
        "ko": "38.833"
    }
}
    },"req_-get--the-list--3525d": {
        type: "REQUEST",
        name: "[GET] The list of available cities is presented.",
path: "[GET] The list of available cities is presented.",
pathFormatted: "req_-get--the-list--3525d",
stats: {
    "name": "[GET] The list of available cities is presented.",
    "numberOfRequests": {
        "total": "215136",
        "ok": "215136",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16166",
        "ok": "16166",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3869",
        "ok": "3869",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4087",
        "ok": "4087",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2195",
        "ok": "2212",
        "ko": "-"
    },
    "percentiles2": {
        "total": "7494",
        "ok": "7491",
        "ko": "-"
    },
    "percentiles3": {
        "total": "10579",
        "ok": "10579",
        "ko": "-"
    },
    "percentiles4": {
        "total": "14252",
        "ok": "14246",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 88159,
    "percentage": 41
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 10235,
    "percentage": 5
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 116742,
    "percentage": 54
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "200.874",
        "ok": "200.874",
        "ko": "-"
    }
}
    },"req_-get--the-list--11d52": {
        type: "REQUEST",
        name: "[GET] The list of available origins is presented.",
path: "[GET] The list of available origins is presented.",
pathFormatted: "req_-get--the-list--11d52",
stats: {
    "name": "[GET] The list of available origins is presented.",
    "numberOfRequests": {
        "total": "107568",
        "ok": "107568",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16142",
        "ok": "16142",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3850",
        "ok": "3850",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4063",
        "ok": "4063",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2206",
        "ok": "2195",
        "ko": "-"
    },
    "percentiles2": {
        "total": "7470",
        "ok": "7470",
        "ko": "-"
    },
    "percentiles3": {
        "total": "10539",
        "ok": "10539",
        "ko": "-"
    },
    "percentiles4": {
        "total": "14064",
        "ok": "14064",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 44352,
    "percentage": 41
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 5063,
    "percentage": 5
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 58153,
    "percentage": 54
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "100.437",
        "ok": "100.437",
        "ko": "-"
    }
}
    },"req_-get--the-list--0dc40": {
        type: "REQUEST",
        name: "[GET] The list of available destinations is presented.",
path: "[GET] The list of available destinations is presented.",
pathFormatted: "req_-get--the-list--0dc40",
stats: {
    "name": "[GET] The list of available destinations is presented.",
    "numberOfRequests": {
        "total": "107568",
        "ok": "107568",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16155",
        "ok": "16155",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3873",
        "ok": "3873",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4025",
        "ok": "4025",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2382",
        "ok": "2385",
        "ko": "-"
    },
    "percentiles2": {
        "total": "7391",
        "ok": "7391",
        "ko": "-"
    },
    "percentiles3": {
        "total": "10416",
        "ok": "10416",
        "ko": "-"
    },
    "percentiles4": {
        "total": "14095",
        "ok": "14095",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 43458,
    "percentage": 40
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 4903,
    "percentage": 5
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 59207,
    "percentage": 55
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "100.437",
        "ok": "100.437",
        "ko": "-"
    }
}
    },"req_-get--the-list--8bddb": {
        type: "REQUEST",
        name: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
path: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
pathFormatted: "req_-get--the-list--8bddb",
stats: {
    "name": "[GET] The list of available transfers by selected origin, destination, and date is presented.",
    "numberOfRequests": {
        "total": "107568",
        "ok": "60223",
        "ko": "47345"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "2"
    },
    "maxResponseTime": {
        "total": "16199",
        "ok": "16199",
        "ko": "16167"
    },
    "meanResponseTime": {
        "total": "3923",
        "ok": "3922",
        "ko": "3923"
    },
    "standardDeviation": {
        "total": "4032",
        "ok": "4028",
        "ko": "4037"
    },
    "percentiles1": {
        "total": "2556",
        "ok": "2569",
        "ko": "2544"
    },
    "percentiles2": {
        "total": "7495",
        "ok": "7484",
        "ko": "7504"
    },
    "percentiles3": {
        "total": "10408",
        "ok": "10382",
        "ko": "10454"
    },
    "percentiles4": {
        "total": "14100",
        "ok": "14095",
        "ko": "14103"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 23512,
    "percentage": 22
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 3026,
    "percentage": 3
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 33685,
    "percentage": 31
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 47345,
    "percentage": 44
},
    "meanNumberOfRequestsPerSecond": {
        "total": "100.437",
        "ok": "56.231",
        "ko": "44.206"
    }
}
    },"req_-post--the-tran-5ac29": {
        type: "REQUEST",
        name: "[POST] The transfer is booked in the system.",
path: "[POST] The transfer is booked in the system.",
pathFormatted: "req_-post--the-tran-5ac29",
stats: {
    "name": "[POST] The transfer is booked in the system.",
    "numberOfRequests": {
        "total": "60223",
        "ok": "60223",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16166",
        "ok": "16166",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3940",
        "ok": "3940",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4065",
        "ok": "4065",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2453",
        "ok": "2452",
        "ko": "-"
    },
    "percentiles2": {
        "total": "7570",
        "ok": "7571",
        "ko": "-"
    },
    "percentiles3": {
        "total": "10547",
        "ok": "10547",
        "ko": "-"
    },
    "percentiles4": {
        "total": "14263",
        "ok": "14263",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 23241,
    "percentage": 39
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 3343,
    "percentage": 6
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 33639,
    "percentage": 56
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "56.231",
        "ok": "56.231",
        "ko": "-"
    }
}
    },"req_-get--the-list--4f742": {
        type: "REQUEST",
        name: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
path: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
pathFormatted: "req_-get--the-list--4f742",
stats: {
    "name": "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
    "numberOfRequests": {
        "total": "60223",
        "ok": "60223",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16165",
        "ok": "16165",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3919",
        "ok": "3919",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4054",
        "ok": "4054",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2379",
        "ok": "2374",
        "ko": "-"
    },
    "percentiles2": {
        "total": "7557",
        "ok": "7558",
        "ko": "-"
    },
    "percentiles3": {
        "total": "10609",
        "ok": "10609",
        "ko": "-"
    },
    "percentiles4": {
        "total": "14042",
        "ok": "14042",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 23586,
    "percentage": 39
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 3305,
    "percentage": 5
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 33332,
    "percentage": 55
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "56.231",
        "ok": "56.231",
        "ko": "-"
    }
}
    },"req_-get--one-of-th-c14cc": {
        type: "REQUEST",
        name: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
path: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
pathFormatted: "req_-get--one-of-th-c14cc",
stats: {
    "name": "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
    "numberOfRequests": {
        "total": "60223",
        "ok": "60223",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16172",
        "ok": "16172",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3888",
        "ok": "3888",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4048",
        "ok": "4048",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2328",
        "ok": "2328",
        "ko": "-"
    },
    "percentiles2": {
        "total": "7494",
        "ok": "7494",
        "ko": "-"
    },
    "percentiles3": {
        "total": "10579",
        "ok": "10579",
        "ko": "-"
    },
    "percentiles4": {
        "total": "14168",
        "ok": "14168",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 23920,
    "percentage": 40
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 3224,
    "percentage": 5
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 33079,
    "percentage": 55
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "56.231",
        "ok": "56.231",
        "ko": "-"
    }
}
    },"req_-put--any--book-143cf": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer description is updated.",
path: "[PUT] Any (BOOKED) transfer description is updated.",
pathFormatted: "req_-put--any--book-143cf",
stats: {
    "name": "[PUT] Any (BOOKED) transfer description is updated.",
    "numberOfRequests": {
        "total": "60223",
        "ok": "60223",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16170",
        "ok": "16170",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3869",
        "ok": "3869",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4065",
        "ok": "4065",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2281",
        "ok": "2283",
        "ko": "-"
    },
    "percentiles2": {
        "total": "7458",
        "ok": "7459",
        "ko": "-"
    },
    "percentiles3": {
        "total": "10528",
        "ok": "10528",
        "ko": "-"
    },
    "percentiles4": {
        "total": "14324",
        "ok": "14324",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 24208,
    "percentage": 40
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 3254,
    "percentage": 5
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 32761,
    "percentage": 54
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "56.231",
        "ok": "56.231",
        "ko": "-"
    }
}
    },"req_-put--any--book-bb16d": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
path: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
pathFormatted: "req_-put--any--book-bb16d",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
    "numberOfRequests": {
        "total": "60223",
        "ok": "60223",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16166",
        "ok": "16166",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3825",
        "ok": "3825",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4042",
        "ok": "4042",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2100",
        "ok": "2096",
        "ko": "-"
    },
    "percentiles2": {
        "total": "7366",
        "ok": "7368",
        "ko": "-"
    },
    "percentiles3": {
        "total": "10510",
        "ok": "10510",
        "ko": "-"
    },
    "percentiles4": {
        "total": "14119",
        "ok": "14119",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 24602,
    "percentage": 41
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 3152,
    "percentage": 5
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 32469,
    "percentage": 54
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "56.231",
        "ok": "56.231",
        "ko": "-"
    }
}
    },"req_-put--any--book-fdf7e": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
path: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
pathFormatted: "req_-put--any--book-fdf7e",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
    "numberOfRequests": {
        "total": "60223",
        "ok": "60223",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16162",
        "ok": "16162",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3784",
        "ok": "3784",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4016",
        "ok": "4016",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2018",
        "ok": "2008",
        "ko": "-"
    },
    "percentiles2": {
        "total": "7349",
        "ok": "7348",
        "ko": "-"
    },
    "percentiles3": {
        "total": "10333",
        "ok": "10333",
        "ko": "-"
    },
    "percentiles4": {
        "total": "14011",
        "ok": "14011",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 24899,
    "percentage": 41
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 3164,
    "percentage": 5
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 32160,
    "percentage": 53
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "56.231",
        "ok": "56.231",
        "ko": "-"
    }
}
    },"req_-get--user-is-r-f03f4": {
        type: "REQUEST",
        name: "[GET] User is retrieved with her/his transfers data.",
path: "[GET] User is retrieved with her/his transfers data.",
pathFormatted: "req_-get--user-is-r-f03f4",
stats: {
    "name": "[GET] User is retrieved with her/his transfers data.",
    "numberOfRequests": {
        "total": "60223",
        "ok": "60223",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16146",
        "ok": "16146",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3765",
        "ok": "3765",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4031",
        "ok": "4031",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1881",
        "ok": "1881",
        "ko": "-"
    },
    "percentiles2": {
        "total": "7409",
        "ok": "7410",
        "ko": "-"
    },
    "percentiles3": {
        "total": "10336",
        "ok": "10336",
        "ko": "-"
    },
    "percentiles4": {
        "total": "14047",
        "ok": "14047",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 25189,
    "percentage": 42
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 3168,
    "percentage": 5
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 31866,
    "percentage": 53
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "56.231",
        "ok": "56.231",
        "ko": "-"
    }
}
    },"req_-put--user-upda-c8c46": {
        type: "REQUEST",
        name: "[PUT] User updates with her/his own data.",
path: "[PUT] User updates with her/his own data.",
pathFormatted: "req_-put--user-upda-c8c46",
stats: {
    "name": "[PUT] User updates with her/his own data.",
    "numberOfRequests": {
        "total": "60223",
        "ok": "60223",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16162",
        "ok": "16162",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3749",
        "ok": "3749",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4039",
        "ok": "4039",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1765",
        "ok": "1768",
        "ko": "-"
    },
    "percentiles2": {
        "total": "7453",
        "ok": "7453",
        "ko": "-"
    },
    "percentiles3": {
        "total": "10370",
        "ok": "10370",
        "ko": "-"
    },
    "percentiles4": {
        "total": "13748",
        "ok": "13748",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 25461,
    "percentage": 42
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 3279,
    "percentage": 5
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 31483,
    "percentage": 52
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "56.231",
        "ok": "56.231",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
