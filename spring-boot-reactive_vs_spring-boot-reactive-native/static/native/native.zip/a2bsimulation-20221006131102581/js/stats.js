var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "1013549",
        "ok": "915094",
        "ko": "98455"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "1",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "17984",
        "ok": "17984",
        "ko": "16815"
    },
    "meanResponseTime": {
        "total": "6047",
        "ok": "6409",
        "ko": "2679"
    },
    "standardDeviation": {
        "total": "4576",
        "ok": "4459",
        "ko": "4268"
    },
    "percentiles1": {
        "total": "7781",
        "ok": "8025",
        "ko": "1"
    },
    "percentiles2": {
        "total": "9510",
        "ok": "9629",
        "ko": "6772"
    },
    "percentiles3": {
        "total": "12591",
        "ok": "12695",
        "ko": "11029"
    },
    "percentiles4": {
        "total": "15141",
        "ok": "15183",
        "ko": "13904"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 167023,
    "percentage": 16
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 63729,
    "percentage": 6
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 684342,
    "percentage": 68
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 98455,
    "percentage": 10
},
    "meanNumberOfRequestsPerSecond": {
        "total": "934.147",
        "ok": "843.405",
        "ko": "90.742"
    }
},
contents: {
"req_-get--the-list--c0b76": {
        type: "REQUEST",
        name: "[GET] The list of available countries is presented.",
path: "[GET] The list of available countries is presented.",
pathFormatted: "req_-get--the-list--c0b76",
stats: {
    "name": "[GET] The list of available countries is presented.",
    "numberOfRequests": {
        "total": "149451",
        "ok": "91226",
        "ko": "58225"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "1",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "17984",
        "ok": "17984",
        "ko": "757"
    },
    "meanResponseTime": {
        "total": "3839",
        "ok": "6285",
        "ko": "5"
    },
    "standardDeviation": {
        "total": "4674",
        "ok": "4518",
        "ko": "39"
    },
    "percentiles1": {
        "total": "686",
        "ok": "7826",
        "ko": "0"
    },
    "percentiles2": {
        "total": "8452",
        "ok": "9628",
        "ko": "0"
    },
    "percentiles3": {
        "total": "11907",
        "ok": "12745",
        "ko": "2"
    },
    "percentiles4": {
        "total": "14832",
        "ok": "15286",
        "ko": "194"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 17445,
    "percentage": 12
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 6467,
    "percentage": 4
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 67314,
    "percentage": 45
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 58225,
    "percentage": 39
},
    "meanNumberOfRequestsPerSecond": {
        "total": "137.743",
        "ok": "84.079",
        "ko": "53.664"
    }
}
    },"req_-get--the-list--3525d": {
        type: "REQUEST",
        name: "[GET] The list of available cities is presented.",
path: "[GET] The list of available cities is presented.",
pathFormatted: "req_-get--the-list--3525d",
stats: {
    "name": "[GET] The list of available cities is presented.",
    "numberOfRequests": {
        "total": "182452",
        "ok": "182452",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16917",
        "ok": "16917",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "6409",
        "ok": "6409",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4470",
        "ok": "4470",
        "ko": "-"
    },
    "percentiles1": {
        "total": "7995",
        "ok": "7996",
        "ko": "-"
    },
    "percentiles2": {
        "total": "9633",
        "ok": "9633",
        "ko": "-"
    },
    "percentiles3": {
        "total": "12700",
        "ok": "12701",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15199",
        "ok": "15199",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 33889,
    "percentage": 19
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 12493,
    "percentage": 7
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 136070,
    "percentage": 75
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "168.159",
        "ok": "168.159",
        "ko": "-"
    }
}
    },"req_-get--the-list--11d52": {
        type: "REQUEST",
        name: "[GET] The list of available origins is presented.",
path: "[GET] The list of available origins is presented.",
pathFormatted: "req_-get--the-list--11d52",
stats: {
    "name": "[GET] The list of available origins is presented.",
    "numberOfRequests": {
        "total": "91226",
        "ok": "91226",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "17020",
        "ok": "17020",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "6401",
        "ok": "6401",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4471",
        "ok": "4471",
        "ko": "-"
    },
    "percentiles1": {
        "total": "8016",
        "ok": "8017",
        "ko": "-"
    },
    "percentiles2": {
        "total": "9629",
        "ok": "9628",
        "ko": "-"
    },
    "percentiles3": {
        "total": "12711",
        "ok": "12703",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15159",
        "ok": "15158",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 17072,
    "percentage": 19
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 6234,
    "percentage": 7
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 67920,
    "percentage": 74
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "84.079",
        "ok": "84.079",
        "ko": "-"
    }
}
    },"req_-get--the-list--0dc40": {
        type: "REQUEST",
        name: "[GET] The list of available destinations is presented.",
path: "[GET] The list of available destinations is presented.",
pathFormatted: "req_-get--the-list--0dc40",
stats: {
    "name": "[GET] The list of available destinations is presented.",
    "numberOfRequests": {
        "total": "91226",
        "ok": "91226",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16946",
        "ok": "16946",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "6487",
        "ok": "6487",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4403",
        "ok": "4403",
        "ko": "-"
    },
    "percentiles1": {
        "total": "8058",
        "ok": "8058",
        "ko": "-"
    },
    "percentiles2": {
        "total": "9616",
        "ok": "9615",
        "ko": "-"
    },
    "percentiles3": {
        "total": "12656",
        "ok": "12656",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15093",
        "ok": "15091",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 16308,
    "percentage": 18
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 6016,
    "percentage": 7
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 68902,
    "percentage": 76
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "84.079",
        "ok": "84.079",
        "ko": "-"
    }
}
    },"req_-get--the-list--8bddb": {
        type: "REQUEST",
        name: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
path: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
pathFormatted: "req_-get--the-list--8bddb",
stats: {
    "name": "[GET] The list of available transfers by selected origin, destination, and date is presented.",
    "numberOfRequests": {
        "total": "91226",
        "ok": "50996",
        "ko": "40230"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "2"
    },
    "maxResponseTime": {
        "total": "17059",
        "ok": "17059",
        "ko": "16815"
    },
    "meanResponseTime": {
        "total": "6537",
        "ok": "6528",
        "ko": "6548"
    },
    "standardDeviation": {
        "total": "4391",
        "ok": "4394",
        "ko": "4388"
    },
    "percentiles1": {
        "total": "8104",
        "ok": "8097",
        "ko": "8111"
    },
    "percentiles2": {
        "total": "9670",
        "ok": "9666",
        "ko": "9675"
    },
    "percentiles3": {
        "total": "12604",
        "ok": "12617",
        "ko": "12578"
    },
    "percentiles4": {
        "total": "15202",
        "ok": "15206",
        "ko": "15197"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 8719,
    "percentage": 10
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 3257,
    "percentage": 4
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 39020,
    "percentage": 43
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 40230,
    "percentage": 44
},
    "meanNumberOfRequestsPerSecond": {
        "total": "84.079",
        "ok": "47.001",
        "ko": "37.078"
    }
}
    },"req_-post--the-tran-5ac29": {
        type: "REQUEST",
        name: "[POST] The transfer is booked in the system.",
path: "[POST] The transfer is booked in the system.",
pathFormatted: "req_-post--the-tran-5ac29",
stats: {
    "name": "[POST] The transfer is booked in the system.",
    "numberOfRequests": {
        "total": "50996",
        "ok": "50996",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16939",
        "ok": "16939",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "6529",
        "ok": "6529",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4415",
        "ok": "4415",
        "ko": "-"
    },
    "percentiles1": {
        "total": "8080",
        "ok": "8080",
        "ko": "-"
    },
    "percentiles2": {
        "total": "9661",
        "ok": "9661",
        "ko": "-"
    },
    "percentiles3": {
        "total": "12696",
        "ok": "12696",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15195",
        "ok": "15195",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 8546,
    "percentage": 17
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 3359,
    "percentage": 7
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 39091,
    "percentage": 77
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "47.001",
        "ok": "47.001",
        "ko": "-"
    }
}
    },"req_-get--the-list--4f742": {
        type: "REQUEST",
        name: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
path: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
pathFormatted: "req_-get--the-list--4f742",
stats: {
    "name": "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
    "numberOfRequests": {
        "total": "50996",
        "ok": "50996",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "17027",
        "ok": "17027",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "6497",
        "ok": "6497",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4407",
        "ok": "4407",
        "ko": "-"
    },
    "percentiles1": {
        "total": "8073",
        "ok": "8072",
        "ko": "-"
    },
    "percentiles2": {
        "total": "9647",
        "ok": "9647",
        "ko": "-"
    },
    "percentiles3": {
        "total": "12698",
        "ok": "12698",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15178",
        "ok": "15178",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 8413,
    "percentage": 16
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 3771,
    "percentage": 7
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 38812,
    "percentage": 76
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "47.001",
        "ok": "47.001",
        "ko": "-"
    }
}
    },"req_-get--one-of-th-c14cc": {
        type: "REQUEST",
        name: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
path: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
pathFormatted: "req_-get--one-of-th-c14cc",
stats: {
    "name": "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
    "numberOfRequests": {
        "total": "50996",
        "ok": "50996",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16855",
        "ok": "16855",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "6480",
        "ok": "6480",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4426",
        "ok": "4426",
        "ko": "-"
    },
    "percentiles1": {
        "total": "8099",
        "ok": "8099",
        "ko": "-"
    },
    "percentiles2": {
        "total": "9638",
        "ok": "9638",
        "ko": "-"
    },
    "percentiles3": {
        "total": "12733",
        "ok": "12733",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15230",
        "ok": "15230",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 8633,
    "percentage": 17
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 3701,
    "percentage": 7
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 38662,
    "percentage": 76
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "47.001",
        "ok": "47.001",
        "ko": "-"
    }
}
    },"req_-put--any--book-143cf": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer description is updated.",
path: "[PUT] Any (BOOKED) transfer description is updated.",
pathFormatted: "req_-put--any--book-143cf",
stats: {
    "name": "[PUT] Any (BOOKED) transfer description is updated.",
    "numberOfRequests": {
        "total": "50996",
        "ok": "50996",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16840",
        "ok": "16840",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "6435",
        "ok": "6435",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4450",
        "ok": "4450",
        "ko": "-"
    },
    "percentiles1": {
        "total": "8070",
        "ok": "8069",
        "ko": "-"
    },
    "percentiles2": {
        "total": "9619",
        "ok": "9619",
        "ko": "-"
    },
    "percentiles3": {
        "total": "12706",
        "ok": "12706",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15215",
        "ok": "15215",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 9008,
    "percentage": 18
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 3685,
    "percentage": 7
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 38303,
    "percentage": 75
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "47.001",
        "ok": "47.001",
        "ko": "-"
    }
}
    },"req_-put--any--book-bb16d": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
path: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
pathFormatted: "req_-put--any--book-bb16d",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
    "numberOfRequests": {
        "total": "50996",
        "ok": "50996",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "17006",
        "ok": "17006",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "6375",
        "ok": "6375",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4446",
        "ok": "4446",
        "ko": "-"
    },
    "percentiles1": {
        "total": "8042",
        "ok": "8041",
        "ko": "-"
    },
    "percentiles2": {
        "total": "9598",
        "ok": "9598",
        "ko": "-"
    },
    "percentiles3": {
        "total": "12592",
        "ok": "12592",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15226",
        "ok": "15226",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 9300,
    "percentage": 18
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 3666,
    "percentage": 7
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 38030,
    "percentage": 75
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "47.001",
        "ok": "47.001",
        "ko": "-"
    }
}
    },"req_-put--any--book-fdf7e": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
path: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
pathFormatted: "req_-put--any--book-fdf7e",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
    "numberOfRequests": {
        "total": "50996",
        "ok": "50996",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16841",
        "ok": "16841",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "6334",
        "ok": "6334",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4459",
        "ok": "4459",
        "ko": "-"
    },
    "percentiles1": {
        "total": "8037",
        "ok": "8037",
        "ko": "-"
    },
    "percentiles2": {
        "total": "9569",
        "ok": "9569",
        "ko": "-"
    },
    "percentiles3": {
        "total": "12604",
        "ok": "12604",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15074",
        "ok": "15074",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 9562,
    "percentage": 19
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 3688,
    "percentage": 7
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 37746,
    "percentage": 74
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "47.001",
        "ok": "47.001",
        "ko": "-"
    }
}
    },"req_-get--user-is-r-f03f4": {
        type: "REQUEST",
        name: "[GET] User is retrieved with her/his transfers data.",
path: "[GET] User is retrieved with her/his transfers data.",
pathFormatted: "req_-get--user-is-r-f03f4",
stats: {
    "name": "[GET] User is retrieved with her/his transfers data.",
    "numberOfRequests": {
        "total": "50996",
        "ok": "50996",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16762",
        "ok": "16762",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "6315",
        "ok": "6315",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4510",
        "ok": "4510",
        "ko": "-"
    },
    "percentiles1": {
        "total": "8030",
        "ok": "8030",
        "ko": "-"
    },
    "percentiles2": {
        "total": "9615",
        "ok": "9615",
        "ko": "-"
    },
    "percentiles3": {
        "total": "12683",
        "ok": "12683",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15168",
        "ok": "15168",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 9924,
    "percentage": 19
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 3709,
    "percentage": 7
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 37363,
    "percentage": 73
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "47.001",
        "ok": "47.001",
        "ko": "-"
    }
}
    },"req_-put--user-upda-c8c46": {
        type: "REQUEST",
        name: "[PUT] User updates with her/his own data.",
path: "[PUT] User updates with her/his own data.",
pathFormatted: "req_-put--user-upda-c8c46",
stats: {
    "name": "[PUT] User updates with her/his own data.",
    "numberOfRequests": {
        "total": "50996",
        "ok": "50996",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "17040",
        "ok": "17040",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "6291",
        "ok": "6291",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4545",
        "ok": "4545",
        "ko": "-"
    },
    "percentiles1": {
        "total": "7999",
        "ok": "7999",
        "ko": "-"
    },
    "percentiles2": {
        "total": "9652",
        "ok": "9652",
        "ko": "-"
    },
    "percentiles3": {
        "total": "12717",
        "ok": "12717",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15094",
        "ok": "15094",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 10204,
    "percentage": 20
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 3683,
    "percentage": 7
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 37109,
    "percentage": 73
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "47.001",
        "ok": "47.001",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
