var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "691487",
        "ok": "573983",
        "ko": "117504"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "1",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "20440",
        "ok": "20440",
        "ko": "20222"
    },
    "meanResponseTime": {
        "total": "12552",
        "ok": "14462",
        "ko": "3223"
    },
    "standardDeviation": {
        "total": "6232",
        "ok": "4130",
        "ko": "6355"
    },
    "percentiles1": {
        "total": "15378",
        "ok": "15627",
        "ko": "0"
    },
    "percentiles2": {
        "total": "16465",
        "ok": "16626",
        "ko": "1"
    },
    "percentiles3": {
        "total": "17891",
        "ok": "17976",
        "ko": "16894"
    },
    "percentiles4": {
        "total": "18760",
        "ok": "18837",
        "ko": "18086"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 9251,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 2727,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 562005,
    "percentage": 81
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 117504,
    "percentage": 17
},
    "meanNumberOfRequestsPerSecond": {
        "total": "615.75",
        "ok": "511.116",
        "ko": "104.634"
    }
},
contents: {
"req_-get--the-list--c0b76": {
        type: "REQUEST",
        name: "[GET] The list of available countries is presented.",
path: "[GET] The list of available countries is presented.",
pathFormatted: "req_-get--the-list--c0b76",
stats: {
    "name": "[GET] The list of available countries is presented.",
    "numberOfRequests": {
        "total": "149426",
        "ok": "57337",
        "ko": "92089"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "3",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "20440",
        "ok": "20440",
        "ko": "824"
    },
    "meanResponseTime": {
        "total": "5520",
        "ok": "14382",
        "ko": "3"
    },
    "standardDeviation": {
        "total": "7522",
        "ok": "4475",
        "ko": "30"
    },
    "percentiles1": {
        "total": "0",
        "ok": "15751",
        "ko": "0"
    },
    "percentiles2": {
        "total": "15267",
        "ok": "16657",
        "ko": "0"
    },
    "percentiles3": {
        "total": "17311",
        "ok": "17985",
        "ko": "1"
    },
    "percentiles4": {
        "total": "18391",
        "ok": "18990",
        "ko": "31"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1671,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 387,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 55279,
    "percentage": 37
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 92089,
    "percentage": 62
},
    "meanNumberOfRequestsPerSecond": {
        "total": "133.06",
        "ok": "51.057",
        "ko": "82.003"
    }
}
    },"req_-get--the-list--3525d": {
        type: "REQUEST",
        name: "[GET] The list of available cities is presented.",
path: "[GET] The list of available cities is presented.",
pathFormatted: "req_-get--the-list--3525d",
stats: {
    "name": "[GET] The list of available cities is presented.",
    "numberOfRequests": {
        "total": "114674",
        "ok": "114674",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "20284",
        "ok": "20284",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14679",
        "ok": "14679",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4005",
        "ok": "4005",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15687",
        "ok": "15686",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16709",
        "ok": "16709",
        "ko": "-"
    },
    "percentiles3": {
        "total": "17991",
        "ok": "17991",
        "ko": "-"
    },
    "percentiles4": {
        "total": "18806",
        "ok": "18805",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2261,
    "percentage": 2
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 632,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 111781,
    "percentage": 97
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "102.114",
        "ok": "102.114",
        "ko": "-"
    }
}
    },"req_-get--the-list--11d52": {
        type: "REQUEST",
        name: "[GET] The list of available origins is presented.",
path: "[GET] The list of available origins is presented.",
pathFormatted: "req_-get--the-list--11d52",
stats: {
    "name": "[GET] The list of available origins is presented.",
    "numberOfRequests": {
        "total": "57337",
        "ok": "57337",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "20092",
        "ok": "20092",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14749",
        "ok": "14749",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4029",
        "ok": "4029",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15696",
        "ok": "15694",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16775",
        "ok": "16775",
        "ko": "-"
    },
    "percentiles3": {
        "total": "18108",
        "ok": "18108",
        "ko": "-"
    },
    "percentiles4": {
        "total": "18886",
        "ok": "18886",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1242,
    "percentage": 2
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 272,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 55823,
    "percentage": 97
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "51.057",
        "ok": "51.057",
        "ko": "-"
    }
}
    },"req_-get--the-list--0dc40": {
        type: "REQUEST",
        name: "[GET] The list of available destinations is presented.",
path: "[GET] The list of available destinations is presented.",
pathFormatted: "req_-get--the-list--0dc40",
stats: {
    "name": "[GET] The list of available destinations is presented.",
    "numberOfRequests": {
        "total": "57337",
        "ok": "57337",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "20103",
        "ok": "20103",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14843",
        "ok": "14843",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3671",
        "ok": "3671",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15734",
        "ok": "15734",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16788",
        "ok": "16788",
        "ko": "-"
    },
    "percentiles3": {
        "total": "18052",
        "ok": "18052",
        "ko": "-"
    },
    "percentiles4": {
        "total": "18905",
        "ok": "18905",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 615,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 236,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 56486,
    "percentage": 99
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "51.057",
        "ok": "51.057",
        "ko": "-"
    }
}
    },"req_-get--the-list--8bddb": {
        type: "REQUEST",
        name: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
path: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
pathFormatted: "req_-get--the-list--8bddb",
stats: {
    "name": "[GET] The list of available transfers by selected origin, destination, and date is presented.",
    "numberOfRequests": {
        "total": "57337",
        "ok": "31922",
        "ko": "25415"
    },
    "minResponseTime": {
        "total": "5",
        "ok": "6",
        "ko": "5"
    },
    "maxResponseTime": {
        "total": "20222",
        "ok": "20222",
        "ko": "20222"
    },
    "meanResponseTime": {
        "total": "14896",
        "ok": "14899",
        "ko": "14893"
    },
    "standardDeviation": {
        "total": "3601",
        "ok": "3601",
        "ko": "3599"
    },
    "percentiles1": {
        "total": "15854",
        "ok": "15849",
        "ko": "15853"
    },
    "percentiles2": {
        "total": "16813",
        "ok": "16818",
        "ko": "16808"
    },
    "percentiles3": {
        "total": "18040",
        "ok": "18055",
        "ko": "18020"
    },
    "percentiles4": {
        "total": "19005",
        "ok": "19021",
        "ko": "18971"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 152,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 129,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 31641,
    "percentage": 55
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 25415,
    "percentage": 44
},
    "meanNumberOfRequestsPerSecond": {
        "total": "51.057",
        "ok": "28.426",
        "ko": "22.631"
    }
}
    },"req_-post--the-tran-5ac29": {
        type: "REQUEST",
        name: "[POST] The transfer is booked in the system.",
path: "[POST] The transfer is booked in the system.",
pathFormatted: "req_-post--the-tran-5ac29",
stats: {
    "name": "[POST] The transfer is booked in the system.",
    "numberOfRequests": {
        "total": "31922",
        "ok": "31922",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "400",
        "ok": "400",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "19715",
        "ok": "19715",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14780",
        "ok": "14780",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3585",
        "ok": "3585",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15746",
        "ok": "15746",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16718",
        "ok": "16718",
        "ko": "-"
    },
    "percentiles3": {
        "total": "17915",
        "ok": "17915",
        "ko": "-"
    },
    "percentiles4": {
        "total": "18871",
        "ok": "18871",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 6,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 74,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 31842,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "28.426",
        "ok": "28.426",
        "ko": "-"
    }
}
    },"req_-get--the-list--4f742": {
        type: "REQUEST",
        name: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
path: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
pathFormatted: "req_-get--the-list--4f742",
stats: {
    "name": "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
    "numberOfRequests": {
        "total": "31922",
        "ok": "31922",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "945",
        "ok": "945",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "20161",
        "ok": "20161",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14621",
        "ok": "14621",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3662",
        "ok": "3662",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15627",
        "ok": "15627",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16590",
        "ok": "16590",
        "ko": "-"
    },
    "percentiles3": {
        "total": "17872",
        "ok": "17872",
        "ko": "-"
    },
    "percentiles4": {
        "total": "18776",
        "ok": "18776",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 9,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 31913,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "28.426",
        "ok": "28.426",
        "ko": "-"
    }
}
    },"req_-get--one-of-th-c14cc": {
        type: "REQUEST",
        name: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
path: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
pathFormatted: "req_-get--one-of-th-c14cc",
stats: {
    "name": "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
    "numberOfRequests": {
        "total": "31922",
        "ok": "31922",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1095",
        "ok": "1095",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "19991",
        "ok": "19991",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14484",
        "ok": "14484",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3811",
        "ok": "3811",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15553",
        "ok": "15550",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16522",
        "ok": "16522",
        "ko": "-"
    },
    "percentiles3": {
        "total": "17866",
        "ok": "17866",
        "ko": "-"
    },
    "percentiles4": {
        "total": "18766",
        "ok": "18766",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 1,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 31921,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "28.426",
        "ok": "28.426",
        "ko": "-"
    }
}
    },"req_-put--any--book-143cf": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer description is updated.",
path: "[PUT] Any (BOOKED) transfer description is updated.",
pathFormatted: "req_-put--any--book-143cf",
stats: {
    "name": "[PUT] Any (BOOKED) transfer description is updated.",
    "numberOfRequests": {
        "total": "31922",
        "ok": "31922",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "704",
        "ok": "704",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "19649",
        "ok": "19649",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14261",
        "ok": "14261",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4043",
        "ok": "4043",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15456",
        "ok": "15453",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16442",
        "ok": "16442",
        "ko": "-"
    },
    "percentiles3": {
        "total": "17871",
        "ok": "17871",
        "ko": "-"
    },
    "percentiles4": {
        "total": "18707",
        "ok": "18707",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 65,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 84,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 31773,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "28.426",
        "ok": "28.426",
        "ko": "-"
    }
}
    },"req_-put--any--book-bb16d": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
path: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
pathFormatted: "req_-put--any--book-bb16d",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
    "numberOfRequests": {
        "total": "31922",
        "ok": "31922",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "19716",
        "ok": "19716",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14108",
        "ok": "14108",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4280",
        "ok": "4280",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15450",
        "ok": "15449",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16449",
        "ok": "16450",
        "ko": "-"
    },
    "percentiles3": {
        "total": "17969",
        "ok": "17969",
        "ko": "-"
    },
    "percentiles4": {
        "total": "18790",
        "ok": "18790",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 198,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 147,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 31577,
    "percentage": 99
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "28.426",
        "ok": "28.426",
        "ko": "-"
    }
}
    },"req_-put--any--book-fdf7e": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
path: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
pathFormatted: "req_-put--any--book-fdf7e",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
    "numberOfRequests": {
        "total": "31922",
        "ok": "31922",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "19715",
        "ok": "19715",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "13934",
        "ok": "13934",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4527",
        "ok": "4527",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15469",
        "ok": "15473",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16420",
        "ok": "16421",
        "ko": "-"
    },
    "percentiles3": {
        "total": "17899",
        "ok": "17900",
        "ko": "-"
    },
    "percentiles4": {
        "total": "18790",
        "ok": "18790",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 511,
    "percentage": 2
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 273,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 31138,
    "percentage": 98
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "28.426",
        "ok": "28.426",
        "ko": "-"
    }
}
    },"req_-get--user-is-r-f03f4": {
        type: "REQUEST",
        name: "[GET] User is retrieved with her/his transfers data.",
path: "[GET] User is retrieved with her/his transfers data.",
pathFormatted: "req_-get--user-is-r-f03f4",
stats: {
    "name": "[GET] User is retrieved with her/his transfers data.",
    "numberOfRequests": {
        "total": "31922",
        "ok": "31922",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "19715",
        "ok": "19715",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "13712",
        "ok": "13712",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4771",
        "ok": "4771",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15421",
        "ok": "15422",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16358",
        "ok": "16358",
        "ko": "-"
    },
    "percentiles3": {
        "total": "17795",
        "ok": "17795",
        "ko": "-"
    },
    "percentiles4": {
        "total": "18736",
        "ok": "18736",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 986,
    "percentage": 3
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 239,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 30697,
    "percentage": 96
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "28.426",
        "ok": "28.426",
        "ko": "-"
    }
}
    },"req_-put--user-upda-c8c46": {
        type: "REQUEST",
        name: "[PUT] User updates with her/his own data.",
path: "[PUT] User updates with her/his own data.",
pathFormatted: "req_-put--user-upda-c8c46",
stats: {
    "name": "[PUT] User updates with her/his own data.",
    "numberOfRequests": {
        "total": "31922",
        "ok": "31922",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "19719",
        "ok": "19719",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "13521",
        "ok": "13521",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5032",
        "ok": "5032",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15407",
        "ok": "15407",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16347",
        "ok": "16347",
        "ko": "-"
    },
    "percentiles3": {
        "total": "17785",
        "ok": "17786",
        "ko": "-"
    },
    "percentiles4": {
        "total": "18775",
        "ok": "18777",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1544,
    "percentage": 5
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 244,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 30134,
    "percentage": 94
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "28.426",
        "ok": "28.426",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
