var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "604610",
        "ok": "481218",
        "ko": "123392"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "4",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "35382",
        "ok": "35382",
        "ko": "35329"
    },
    "meanResponseTime": {
        "total": "14735",
        "ok": "17702",
        "ko": "3165"
    },
    "standardDeviation": {
        "total": "9348",
        "ok": "7232",
        "ko": "7487"
    },
    "percentiles1": {
        "total": "18822",
        "ok": "19382",
        "ko": "0"
    },
    "percentiles2": {
        "total": "20814",
        "ok": "21282",
        "ko": "1"
    },
    "percentiles3": {
        "total": "25728",
        "ok": "26660",
        "ko": "21019"
    },
    "percentiles4": {
        "total": "33380",
        "ok": "33652",
        "ko": "26674"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 8075,
    "percentage": 1
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 25413,
    "percentage": 4
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 447730,
    "percentage": 74
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 123392,
    "percentage": 20
},
    "meanNumberOfRequestsPerSecond": {
        "total": "534.58",
        "ok": "425.48",
        "ko": "109.1"
    }
},
contents: {
"req_-get--the-list--c0b76": {
        type: "REQUEST",
        name: "[GET] The list of available countries is presented.",
path: "[GET] The list of available countries is presented.",
pathFormatted: "req_-get--the-list--c0b76",
stats: {
    "name": "[GET] The list of available countries is presented.",
    "numberOfRequests": {
        "total": "150191",
        "ok": "48005",
        "ko": "102186"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "4",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "35302",
        "ok": "35302",
        "ko": "383"
    },
    "meanResponseTime": {
        "total": "5565",
        "ok": "17411",
        "ko": "1"
    },
    "standardDeviation": {
        "total": "9263",
        "ok": "7888",
        "ko": "9"
    },
    "percentiles1": {
        "total": "0",
        "ok": "19475",
        "ko": "0"
    },
    "percentiles2": {
        "total": "11313",
        "ok": "21593",
        "ko": "0"
    },
    "percentiles3": {
        "total": "23093",
        "ok": "26914",
        "ko": "1"
    },
    "percentiles4": {
        "total": "31280",
        "ok": "33725",
        "ko": "2"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 1779,
    "percentage": 1
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 2802,
    "percentage": 2
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 43424,
    "percentage": 29
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 102186,
    "percentage": 68
},
    "meanNumberOfRequestsPerSecond": {
        "total": "132.795",
        "ok": "42.445",
        "ko": "90.35"
    }
}
    },"req_-get--the-list--3525d": {
        type: "REQUEST",
        name: "[GET] The list of available cities is presented.",
path: "[GET] The list of available cities is presented.",
pathFormatted: "req_-get--the-list--3525d",
stats: {
    "name": "[GET] The list of available cities is presented.",
    "numberOfRequests": {
        "total": "96010",
        "ok": "96010",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "35286",
        "ok": "35286",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "17855",
        "ok": "17855",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "7200",
        "ok": "7200",
        "ko": "-"
    },
    "percentiles1": {
        "total": "19398",
        "ok": "19399",
        "ko": "-"
    },
    "percentiles2": {
        "total": "21367",
        "ok": "21349",
        "ko": "-"
    },
    "percentiles3": {
        "total": "26355",
        "ok": "26356",
        "ko": "-"
    },
    "percentiles4": {
        "total": "33440",
        "ok": "33440",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 2524,
    "percentage": 3
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 4789,
    "percentage": 5
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 88697,
    "percentage": 92
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "84.889",
        "ok": "84.889",
        "ko": "-"
    }
}
    },"req_-get--the-list--11d52": {
        type: "REQUEST",
        name: "[GET] The list of available origins is presented.",
path: "[GET] The list of available origins is presented.",
pathFormatted: "req_-get--the-list--11d52",
stats: {
    "name": "[GET] The list of available origins is presented.",
    "numberOfRequests": {
        "total": "48005",
        "ok": "48005",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "35286",
        "ok": "35286",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "17914",
        "ok": "17914",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "7191",
        "ok": "7191",
        "ko": "-"
    },
    "percentiles1": {
        "total": "19542",
        "ok": "19542",
        "ko": "-"
    },
    "percentiles2": {
        "total": "21362",
        "ok": "21369",
        "ko": "-"
    },
    "percentiles3": {
        "total": "26334",
        "ok": "26334",
        "ko": "-"
    },
    "percentiles4": {
        "total": "33394",
        "ok": "33394",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 1345,
    "percentage": 3
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 2365,
    "percentage": 5
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 44295,
    "percentage": 92
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "42.445",
        "ok": "42.445",
        "ko": "-"
    }
}
    },"req_-get--the-list--0dc40": {
        type: "REQUEST",
        name: "[GET] The list of available destinations is presented.",
path: "[GET] The list of available destinations is presented.",
pathFormatted: "req_-get--the-list--0dc40",
stats: {
    "name": "[GET] The list of available destinations is presented.",
    "numberOfRequests": {
        "total": "48005",
        "ok": "48005",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "35286",
        "ok": "35286",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "18207",
        "ok": "18207",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "6833",
        "ok": "6833",
        "ko": "-"
    },
    "percentiles1": {
        "total": "19361",
        "ok": "19361",
        "ko": "-"
    },
    "percentiles2": {
        "total": "21317",
        "ok": "21290",
        "ko": "-"
    },
    "percentiles3": {
        "total": "26665",
        "ok": "26665",
        "ko": "-"
    },
    "percentiles4": {
        "total": "34896",
        "ok": "34896",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 737,
    "percentage": 2
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 2124,
    "percentage": 4
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 45144,
    "percentage": 94
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "42.445",
        "ok": "42.445",
        "ko": "-"
    }
}
    },"req_-get--the-list--8bddb": {
        type: "REQUEST",
        name: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
path: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
pathFormatted: "req_-get--the-list--8bddb",
stats: {
    "name": "[GET] The list of available transfers by selected origin, destination, and date is presented.",
    "numberOfRequests": {
        "total": "48005",
        "ok": "26800",
        "ko": "21205"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "6"
    },
    "maxResponseTime": {
        "total": "35329",
        "ok": "35306",
        "ko": "35329"
    },
    "meanResponseTime": {
        "total": "18362",
        "ok": "18322",
        "ko": "18413"
    },
    "standardDeviation": {
        "total": "6764",
        "ok": "6783",
        "ko": "6741"
    },
    "percentiles1": {
        "total": "19443",
        "ok": "19423",
        "ko": "19464"
    },
    "percentiles2": {
        "total": "21341",
        "ok": "21301",
        "ko": "21383"
    },
    "percentiles3": {
        "total": "29122",
        "ok": "29213",
        "ko": "29041"
    },
    "percentiles4": {
        "total": "33781",
        "ok": "33781",
        "ko": "33747"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 178,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 1205,
    "percentage": 3
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 25417,
    "percentage": 53
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 21205,
    "percentage": 44
},
    "meanNumberOfRequestsPerSecond": {
        "total": "42.445",
        "ok": "23.696",
        "ko": "18.749"
    }
}
    },"req_-post--the-tran-5ac29": {
        type: "REQUEST",
        name: "[POST] The transfer is booked in the system.",
path: "[POST] The transfer is booked in the system.",
pathFormatted: "req_-post--the-tran-5ac29",
stats: {
    "name": "[POST] The transfer is booked in the system.",
    "numberOfRequests": {
        "total": "26800",
        "ok": "26799",
        "ko": "1"
    },
    "minResponseTime": {
        "total": "70",
        "ok": "70",
        "ko": "5940"
    },
    "maxResponseTime": {
        "total": "35301",
        "ok": "35301",
        "ko": "5940"
    },
    "meanResponseTime": {
        "total": "18301",
        "ok": "18302",
        "ko": "5940"
    },
    "standardDeviation": {
        "total": "6844",
        "ok": "6844",
        "ko": "0"
    },
    "percentiles1": {
        "total": "19373",
        "ok": "19373",
        "ko": "5940"
    },
    "percentiles2": {
        "total": "21284",
        "ok": "21298",
        "ko": "5940"
    },
    "percentiles3": {
        "total": "29521",
        "ok": "29522",
        "ko": "5940"
    },
    "percentiles4": {
        "total": "34664",
        "ok": "34664",
        "ko": "5940"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 21,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 1115,
    "percentage": 4
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 25663,
    "percentage": 96
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 1,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "23.696",
        "ok": "23.695",
        "ko": "0.001"
    }
}
    },"req_-get--the-list--4f742": {
        type: "REQUEST",
        name: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
path: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
pathFormatted: "req_-get--the-list--4f742",
stats: {
    "name": "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
    "numberOfRequests": {
        "total": "26800",
        "ok": "26800",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "161",
        "ok": "161",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "35284",
        "ok": "35284",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "18072",
        "ok": "18072",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "6819",
        "ok": "6819",
        "ko": "-"
    },
    "percentiles1": {
        "total": "19411",
        "ok": "19411",
        "ko": "-"
    },
    "percentiles2": {
        "total": "21215",
        "ok": "21216",
        "ko": "-"
    },
    "percentiles3": {
        "total": "28533",
        "ok": "28437",
        "ko": "-"
    },
    "percentiles4": {
        "total": "33681",
        "ok": "33679",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 2,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 980,
    "percentage": 4
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 25818,
    "percentage": 96
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "23.696",
        "ok": "23.696",
        "ko": "-"
    }
}
    },"req_-get--one-of-th-c14cc": {
        type: "REQUEST",
        name: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
path: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
pathFormatted: "req_-get--one-of-th-c14cc",
stats: {
    "name": "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
    "numberOfRequests": {
        "total": "26799",
        "ok": "26799",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "524",
        "ok": "524",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "35280",
        "ok": "35280",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "17802",
        "ok": "17802",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "6792",
        "ok": "6792",
        "ko": "-"
    },
    "percentiles1": {
        "total": "19445",
        "ok": "19444",
        "ko": "-"
    },
    "percentiles2": {
        "total": "21060",
        "ok": "21060",
        "ko": "-"
    },
    "percentiles3": {
        "total": "26512",
        "ok": "26512",
        "ko": "-"
    },
    "percentiles4": {
        "total": "33191",
        "ok": "33191",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 1094,
    "percentage": 4
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 25705,
    "percentage": 96
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "23.695",
        "ok": "23.695",
        "ko": "-"
    }
}
    },"req_-put--any--book-143cf": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer description is updated.",
path: "[PUT] Any (BOOKED) transfer description is updated.",
pathFormatted: "req_-put--any--book-143cf",
stats: {
    "name": "[PUT] Any (BOOKED) transfer description is updated.",
    "numberOfRequests": {
        "total": "26799",
        "ok": "26799",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "755",
        "ok": "755",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "35283",
        "ok": "35283",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "17512",
        "ok": "17512",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "6932",
        "ok": "6932",
        "ko": "-"
    },
    "percentiles1": {
        "total": "19288",
        "ok": "19286",
        "ko": "-"
    },
    "percentiles2": {
        "total": "20966",
        "ok": "20966",
        "ko": "-"
    },
    "percentiles3": {
        "total": "25756",
        "ok": "25756",
        "ko": "-"
    },
    "percentiles4": {
        "total": "33400",
        "ok": "33400",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 1349,
    "percentage": 5
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 25450,
    "percentage": 95
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "23.695",
        "ok": "23.695",
        "ko": "-"
    }
}
    },"req_-put--any--book-bb16d": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
path: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
pathFormatted: "req_-put--any--book-bb16d",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
    "numberOfRequests": {
        "total": "26799",
        "ok": "26799",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "259",
        "ok": "259",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "35302",
        "ok": "35302",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "17261",
        "ok": "17261",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "7068",
        "ok": "7068",
        "ko": "-"
    },
    "percentiles1": {
        "total": "19268",
        "ok": "19268",
        "ko": "-"
    },
    "percentiles2": {
        "total": "21002",
        "ok": "21002",
        "ko": "-"
    },
    "percentiles3": {
        "total": "25504",
        "ok": "25504",
        "ko": "-"
    },
    "percentiles4": {
        "total": "33109",
        "ok": "33109",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 2,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 1623,
    "percentage": 6
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 25174,
    "percentage": 94
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "23.695",
        "ok": "23.695",
        "ko": "-"
    }
}
    },"req_-put--any--book-fdf7e": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
path: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
pathFormatted: "req_-put--any--book-fdf7e",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
    "numberOfRequests": {
        "total": "26799",
        "ok": "26799",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "35382",
        "ok": "35382",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "16995",
        "ok": "16995",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "7243",
        "ok": "7243",
        "ko": "-"
    },
    "percentiles1": {
        "total": "19304",
        "ok": "19304",
        "ko": "-"
    },
    "percentiles2": {
        "total": "20964",
        "ok": "20966",
        "ko": "-"
    },
    "percentiles3": {
        "total": "25419",
        "ok": "25414",
        "ko": "-"
    },
    "percentiles4": {
        "total": "32593",
        "ok": "32593",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 146,
    "percentage": 1
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 1940,
    "percentage": 7
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 24713,
    "percentage": 92
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "23.695",
        "ok": "23.695",
        "ko": "-"
    }
}
    },"req_-get--user-is-r-f03f4": {
        type: "REQUEST",
        name: "[GET] User is retrieved with her/his transfers data.",
path: "[GET] User is retrieved with her/his transfers data.",
pathFormatted: "req_-get--user-is-r-f03f4",
stats: {
    "name": "[GET] User is retrieved with her/his transfers data.",
    "numberOfRequests": {
        "total": "26799",
        "ok": "26799",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "35284",
        "ok": "35284",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "16939",
        "ok": "16939",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "7766",
        "ok": "7766",
        "ko": "-"
    },
    "percentiles1": {
        "total": "19192",
        "ok": "19192",
        "ko": "-"
    },
    "percentiles2": {
        "total": "21085",
        "ok": "21085",
        "ko": "-"
    },
    "percentiles3": {
        "total": "26766",
        "ok": "26764",
        "ko": "-"
    },
    "percentiles4": {
        "total": "34240",
        "ok": "34242",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 509,
    "percentage": 2
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 1916,
    "percentage": 7
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 24374,
    "percentage": 91
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "23.695",
        "ok": "23.695",
        "ko": "-"
    }
}
    },"req_-put--user-upda-c8c46": {
        type: "REQUEST",
        name: "[PUT] User updates with her/his own data.",
path: "[PUT] User updates with her/his own data.",
pathFormatted: "req_-put--user-upda-c8c46",
stats: {
    "name": "[PUT] User updates with her/his own data.",
    "numberOfRequests": {
        "total": "26799",
        "ok": "26799",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "35284",
        "ok": "35284",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "16800",
        "ok": "16800",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "8101",
        "ok": "8101",
        "ko": "-"
    },
    "percentiles1": {
        "total": "19271",
        "ok": "19271",
        "ko": "-"
    },
    "percentiles2": {
        "total": "21379",
        "ok": "21364",
        "ko": "-"
    },
    "percentiles3": {
        "total": "26835",
        "ok": "26836",
        "ko": "-"
    },
    "percentiles4": {
        "total": "33179",
        "ok": "33176",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 832,
    "percentage": 3
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 2111,
    "percentage": 8
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 23856,
    "percentage": 89
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "23.695",
        "ok": "23.695",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
