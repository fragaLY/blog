var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "371624",
        "ok": "206856",
        "ko": "164768"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "2",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "75228",
        "ok": "71177",
        "ko": "75228"
    },
    "meanResponseTime": {
        "total": "21143",
        "ok": "27687",
        "ko": "12927"
    },
    "standardDeviation": {
        "total": "15530",
        "ok": "13051",
        "ko": "14453"
    },
    "percentiles1": {
        "total": "19722",
        "ok": "27645",
        "ko": "7562"
    },
    "percentiles2": {
        "total": "35810",
        "ok": "38770",
        "ko": "21398"
    },
    "percentiles3": {
        "total": "46090",
        "ok": "47403",
        "ko": "41261"
    },
    "percentiles4": {
        "total": "49264",
        "ok": "49578",
        "ko": "48414"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 2491,
    "percentage": 1
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 3637,
    "percentage": 1
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 200728,
    "percentage": 54
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 164768,
    "percentage": 44
},
    "meanNumberOfRequestsPerSecond": {
        "total": "338.455",
        "ok": "188.393",
        "ko": "150.062"
    }
},
contents: {
"req_-get--the-list--c0b76": {
        type: "REQUEST",
        name: "[GET] The list of available countries is presented.",
path: "[GET] The list of available countries is presented.",
pathFormatted: "req_-get--the-list--c0b76",
stats: {
    "name": "[GET] The list of available countries is presented.",
    "numberOfRequests": {
        "total": "149786",
        "ok": "54333",
        "ko": "95453"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "4",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "75228",
        "ok": "69953",
        "ko": "75228"
    },
    "meanResponseTime": {
        "total": "14300",
        "ok": "28781",
        "ko": "6058"
    },
    "standardDeviation": {
        "total": "15174",
        "ok": "12869",
        "ko": "8930"
    },
    "percentiles1": {
        "total": "8568",
        "ok": "28695",
        "ko": "698"
    },
    "percentiles2": {
        "total": "25415",
        "ok": "39392",
        "ko": "9466"
    },
    "percentiles3": {
        "total": "42659",
        "ok": "47318",
        "ko": "25366"
    },
    "percentiles4": {
        "total": "48663",
        "ok": "50630",
        "ko": "36405"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 421,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 1015,
    "percentage": 1
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 52897,
    "percentage": 35
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 95453,
    "percentage": 64
},
    "meanNumberOfRequestsPerSecond": {
        "total": "136.417",
        "ok": "49.484",
        "ko": "86.934"
    }
}
    },"req_-get--the-list--3525d": {
        type: "REQUEST",
        name: "[GET] The list of available cities is presented.",
path: "[GET] The list of available cities is presented.",
pathFormatted: "req_-get--the-list--3525d",
stats: {
    "name": "[GET] The list of available cities is presented.",
    "numberOfRequests": {
        "total": "108666",
        "ok": "91876",
        "ko": "16790"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "4",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "71177",
        "ok": "71177",
        "ko": "62348"
    },
    "meanResponseTime": {
        "total": "25108",
        "ok": "28560",
        "ko": "6220"
    },
    "standardDeviation": {
        "total": "14549",
        "ok": "12578",
        "ko": "9073"
    },
    "percentiles1": {
        "total": "24752",
        "ok": "28461",
        "ko": "1599"
    },
    "percentiles2": {
        "total": "37739",
        "ok": "39045",
        "ko": "10215"
    },
    "percentiles3": {
        "total": "47467",
        "ok": "47921",
        "ko": "24062"
    },
    "percentiles4": {
        "total": "49495",
        "ok": "49540",
        "ko": "42586"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 231,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 1237,
    "percentage": 1
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 90408,
    "percentage": 83
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 16790,
    "percentage": 15
},
    "meanNumberOfRequestsPerSecond": {
        "total": "98.967",
        "ok": "83.676",
        "ko": "15.291"
    }
}
    },"req_-get--the-list--11d52": {
        type: "REQUEST",
        name: "[GET] The list of available origins is presented.",
path: "[GET] The list of available origins is presented.",
pathFormatted: "req_-get--the-list--11d52",
stats: {
    "name": "[GET] The list of available origins is presented.",
    "numberOfRequests": {
        "total": "54333",
        "ok": "27202",
        "ko": "27131"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "11"
    },
    "maxResponseTime": {
        "total": "61758",
        "ok": "60967",
        "ko": "61758"
    },
    "meanResponseTime": {
        "total": "29967",
        "ok": "29982",
        "ko": "29952"
    },
    "standardDeviation": {
        "total": "12031",
        "ok": "12072",
        "ko": "11991"
    },
    "percentiles1": {
        "total": "32406",
        "ok": "32491",
        "ko": "32313"
    },
    "percentiles2": {
        "total": "40201",
        "ok": "40247",
        "ko": "40129"
    },
    "percentiles3": {
        "total": "47781",
        "ok": "47776",
        "ko": "47796"
    },
    "percentiles4": {
        "total": "49549",
        "ok": "49568",
        "ko": "49535"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 24,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 309,
    "percentage": 1
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 26869,
    "percentage": 49
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 27131,
    "percentage": 50
},
    "meanNumberOfRequestsPerSecond": {
        "total": "49.484",
        "ok": "24.774",
        "ko": "24.709"
    }
}
    },"req_-get--the-list--0dc40": {
        type: "REQUEST",
        name: "[GET] The list of available destinations is presented.",
path: "[GET] The list of available destinations is presented.",
pathFormatted: "req_-get--the-list--0dc40",
stats: {
    "name": "[GET] The list of available destinations is presented.",
    "numberOfRequests": {
        "total": "27202",
        "ok": "13559",
        "ko": "13643"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "12",
        "ko": "7"
    },
    "maxResponseTime": {
        "total": "61783",
        "ok": "61783",
        "ko": "60964"
    },
    "meanResponseTime": {
        "total": "25975",
        "ok": "25957",
        "ko": "25994"
    },
    "standardDeviation": {
        "total": "12735",
        "ok": "12739",
        "ko": "12731"
    },
    "percentiles1": {
        "total": "25562",
        "ok": "25517",
        "ko": "25694"
    },
    "percentiles2": {
        "total": "36749",
        "ok": "36756",
        "ko": "36742"
    },
    "percentiles3": {
        "total": "45008",
        "ok": "45180",
        "ko": "44778"
    },
    "percentiles4": {
        "total": "49216",
        "ok": "49224",
        "ko": "49198"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 4,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 227,
    "percentage": 1
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 13328,
    "percentage": 49
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 13643,
    "percentage": 50
},
    "meanNumberOfRequestsPerSecond": {
        "total": "24.774",
        "ok": "12.349",
        "ko": "12.425"
    }
}
    },"req_-get--the-list--8bddb": {
        type: "REQUEST",
        name: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
path: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
pathFormatted: "req_-get--the-list--8bddb",
stats: {
    "name": "[GET] The list of available transfers by selected origin, destination, and date is presented.",
    "numberOfRequests": {
        "total": "13559",
        "ok": "3615",
        "ko": "9944"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "4",
        "ko": "3"
    },
    "maxResponseTime": {
        "total": "58160",
        "ok": "58160",
        "ko": "58159"
    },
    "meanResponseTime": {
        "total": "24572",
        "ok": "24157",
        "ko": "24723"
    },
    "standardDeviation": {
        "total": "14431",
        "ok": "14386",
        "ko": "14445"
    },
    "percentiles1": {
        "total": "23276",
        "ok": "21831",
        "ko": "23816"
    },
    "percentiles2": {
        "total": "38714",
        "ok": "38340",
        "ko": "38841"
    },
    "percentiles3": {
        "total": "44740",
        "ok": "44849",
        "ko": "44694"
    },
    "percentiles4": {
        "total": "49542",
        "ok": "49239",
        "ko": "49559"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 75,
    "percentage": 1
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 128,
    "percentage": 1
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 3412,
    "percentage": 25
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 9944,
    "percentage": 73
},
    "meanNumberOfRequestsPerSecond": {
        "total": "12.349",
        "ok": "3.292",
        "ko": "9.056"
    }
}
    },"req_-post--the-tran-5ac29": {
        type: "REQUEST",
        name: "[POST] The transfer is booked in the system.",
path: "[POST] The transfer is booked in the system.",
pathFormatted: "req_-post--the-tran-5ac29",
stats: {
    "name": "[POST] The transfer is booked in the system.",
    "numberOfRequests": {
        "total": "3615",
        "ok": "3615",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "59279",
        "ok": "59279",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "21581",
        "ok": "21581",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "14113",
        "ok": "14113",
        "ko": "-"
    },
    "percentiles1": {
        "total": "19173",
        "ok": "19178",
        "ko": "-"
    },
    "percentiles2": {
        "total": "35353",
        "ok": "35353",
        "ko": "-"
    },
    "percentiles3": {
        "total": "43774",
        "ok": "43774",
        "ko": "-"
    },
    "percentiles4": {
        "total": "49604",
        "ok": "49604",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 140,
    "percentage": 4
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 117,
    "percentage": 3
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 3358,
    "percentage": 93
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "3.292",
        "ok": "3.292",
        "ko": "-"
    }
}
    },"req_-get--the-list--4f742": {
        type: "REQUEST",
        name: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
path: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
pathFormatted: "req_-get--the-list--4f742",
stats: {
    "name": "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
    "numberOfRequests": {
        "total": "3615",
        "ok": "1808",
        "ko": "1807"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "3"
    },
    "maxResponseTime": {
        "total": "56826",
        "ok": "53929",
        "ko": "56826"
    },
    "meanResponseTime": {
        "total": "18774",
        "ok": "18662",
        "ko": "18887"
    },
    "standardDeviation": {
        "total": "13586",
        "ok": "13484",
        "ko": "13686"
    },
    "percentiles1": {
        "total": "16450",
        "ok": "16213",
        "ko": "16581"
    },
    "percentiles2": {
        "total": "30217",
        "ok": "28648",
        "ko": "31789"
    },
    "percentiles3": {
        "total": "41343",
        "ok": "41575",
        "ko": "41251"
    },
    "percentiles4": {
        "total": "48379",
        "ok": "48440",
        "ko": "48293"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 92,
    "percentage": 3
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 128,
    "percentage": 4
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 1588,
    "percentage": 44
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 1807,
    "percentage": 50
},
    "meanNumberOfRequestsPerSecond": {
        "total": "3.292",
        "ok": "1.647",
        "ko": "1.646"
    }
}
    },"req_-get--one-of-th-c14cc": {
        type: "REQUEST",
        name: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
path: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
pathFormatted: "req_-get--one-of-th-c14cc",
stats: {
    "name": "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
    "numberOfRequests": {
        "total": "1808",
        "ok": "1808",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "58777",
        "ok": "58777",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "17105",
        "ok": "17105",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "12916",
        "ok": "12916",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15291",
        "ok": "15291",
        "ko": "-"
    },
    "percentiles2": {
        "total": "22418",
        "ok": "22418",
        "ko": "-"
    },
    "percentiles3": {
        "total": "41703",
        "ok": "41703",
        "ko": "-"
    },
    "percentiles4": {
        "total": "48371",
        "ok": "48371",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 163,
    "percentage": 9
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 118,
    "percentage": 7
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 1527,
    "percentage": 84
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.647",
        "ok": "1.647",
        "ko": "-"
    }
}
    },"req_-put--any--book-143cf": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer description is updated.",
path: "[PUT] Any (BOOKED) transfer description is updated.",
pathFormatted: "req_-put--any--book-143cf",
stats: {
    "name": "[PUT] Any (BOOKED) transfer description is updated.",
    "numberOfRequests": {
        "total": "1808",
        "ok": "1808",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "58237",
        "ok": "58237",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "16232",
        "ok": "16232",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "12382",
        "ok": "12382",
        "ko": "-"
    },
    "percentiles1": {
        "total": "14759",
        "ok": "14759",
        "ko": "-"
    },
    "percentiles2": {
        "total": "22561",
        "ok": "22561",
        "ko": "-"
    },
    "percentiles3": {
        "total": "40652",
        "ok": "40652",
        "ko": "-"
    },
    "percentiles4": {
        "total": "47751",
        "ok": "47751",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 233,
    "percentage": 13
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 82,
    "percentage": 5
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 1493,
    "percentage": 83
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.647",
        "ok": "1.647",
        "ko": "-"
    }
}
    },"req_-put--any--book-bb16d": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
path: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
pathFormatted: "req_-put--any--book-bb16d",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
    "numberOfRequests": {
        "total": "1808",
        "ok": "1808",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "53923",
        "ok": "53923",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "15182",
        "ok": "15182",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "11893",
        "ok": "11893",
        "ko": "-"
    },
    "percentiles1": {
        "total": "14112",
        "ok": "14112",
        "ko": "-"
    },
    "percentiles2": {
        "total": "23124",
        "ok": "23124",
        "ko": "-"
    },
    "percentiles3": {
        "total": "39124",
        "ok": "39124",
        "ko": "-"
    },
    "percentiles4": {
        "total": "45856",
        "ok": "45856",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 274,
    "percentage": 15
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 81,
    "percentage": 4
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 1453,
    "percentage": 80
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.647",
        "ok": "1.647",
        "ko": "-"
    }
}
    },"req_-put--any--book-fdf7e": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
path: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
pathFormatted: "req_-put--any--book-fdf7e",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
    "numberOfRequests": {
        "total": "1808",
        "ok": "1808",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "53925",
        "ok": "53925",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "15108",
        "ok": "15108",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "11682",
        "ok": "11682",
        "ko": "-"
    },
    "percentiles1": {
        "total": "14745",
        "ok": "14745",
        "ko": "-"
    },
    "percentiles2": {
        "total": "22297",
        "ok": "22297",
        "ko": "-"
    },
    "percentiles3": {
        "total": "37331",
        "ok": "37331",
        "ko": "-"
    },
    "percentiles4": {
        "total": "43410",
        "ok": "43410",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 280,
    "percentage": 15
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 91,
    "percentage": 5
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 1437,
    "percentage": 79
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.647",
        "ok": "1.647",
        "ko": "-"
    }
}
    },"req_-get--user-is-r-f03f4": {
        type: "REQUEST",
        name: "[GET] User is retrieved with her/his transfers data.",
path: "[GET] User is retrieved with her/his transfers data.",
pathFormatted: "req_-get--user-is-r-f03f4",
stats: {
    "name": "[GET] User is retrieved with her/his transfers data.",
    "numberOfRequests": {
        "total": "1808",
        "ok": "1808",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "53926",
        "ok": "53926",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "15862",
        "ok": "15862",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "11829",
        "ok": "11829",
        "ko": "-"
    },
    "percentiles1": {
        "total": "14923",
        "ok": "14923",
        "ko": "-"
    },
    "percentiles2": {
        "total": "21823",
        "ok": "21823",
        "ko": "-"
    },
    "percentiles3": {
        "total": "39394",
        "ok": "39394",
        "ko": "-"
    },
    "percentiles4": {
        "total": "41513",
        "ok": "41513",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 277,
    "percentage": 15
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 62,
    "percentage": 3
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 1469,
    "percentage": 81
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.647",
        "ok": "1.647",
        "ko": "-"
    }
}
    },"req_-put--user-upda-c8c46": {
        type: "REQUEST",
        name: "[PUT] User updates with her/his own data.",
path: "[PUT] User updates with her/his own data.",
pathFormatted: "req_-put--user-upda-c8c46",
stats: {
    "name": "[PUT] User updates with her/his own data.",
    "numberOfRequests": {
        "total": "1808",
        "ok": "1808",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "52351",
        "ok": "52351",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "16109",
        "ok": "16109",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "11887",
        "ok": "11887",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15403",
        "ok": "15403",
        "ko": "-"
    },
    "percentiles2": {
        "total": "21747",
        "ok": "21747",
        "ko": "-"
    },
    "percentiles3": {
        "total": "39009",
        "ok": "39009",
        "ko": "-"
    },
    "percentiles4": {
        "total": "41317",
        "ok": "41317",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 277,
    "percentage": 15
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 42,
    "percentage": 2
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 1489,
    "percentage": 82
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.647",
        "ok": "1.647",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
