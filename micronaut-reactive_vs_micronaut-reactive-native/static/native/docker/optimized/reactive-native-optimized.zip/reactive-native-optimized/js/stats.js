var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "339333",
        "ok": "174323",
        "ko": "165010"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "2",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "78622",
        "ok": "78622",
        "ko": "77846"
    },
    "meanResponseTime": {
        "total": "21479",
        "ok": "28352",
        "ko": "14218"
    },
    "standardDeviation": {
        "total": "16160",
        "ok": "14927",
        "ko": "14108"
    },
    "percentiles1": {
        "total": "18251",
        "ok": "27165",
        "ko": "9861"
    },
    "percentiles2": {
        "total": "34011",
        "ok": "37614",
        "ko": "19374"
    },
    "percentiles3": {
        "total": "53506",
        "ok": "56016",
        "ko": "43556"
    },
    "percentiles4": {
        "total": "62786",
        "ok": "64512",
        "ko": "60484"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 3500,
    "percentage": 1
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 3117,
    "percentage": 1
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 167706,
    "percentage": 49
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 165010,
    "percentage": 49
},
    "meanNumberOfRequestsPerSecond": {
        "total": "308.204",
        "ok": "158.332",
        "ko": "149.873"
    }
},
contents: {
"req_-get--the-list--c0b76": {
        type: "REQUEST",
        name: "[GET] The list of available countries is presented.",
path: "[GET] The list of available countries is presented.",
pathFormatted: "req_-get--the-list--c0b76",
stats: {
    "name": "[GET] The list of available countries is presented.",
    "numberOfRequests": {
        "total": "150731",
        "ok": "46289",
        "ko": "104442"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "4",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "78254",
        "ok": "78254",
        "ko": "76011"
    },
    "meanResponseTime": {
        "total": "15936",
        "ok": "31597",
        "ko": "8995"
    },
    "standardDeviation": {
        "total": "15266",
        "ok": "14396",
        "ko": "9360"
    },
    "percentiles1": {
        "total": "10482",
        "ok": "30270",
        "ko": "7004"
    },
    "percentiles2": {
        "total": "25006",
        "ok": "39592",
        "ko": "12659"
    },
    "percentiles3": {
        "total": "47130",
        "ok": "57340",
        "ko": "25903"
    },
    "percentiles4": {
        "total": "61122",
        "ok": "65699",
        "ko": "43427"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 604,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 905,
    "percentage": 1
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 44780,
    "percentage": 30
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 104442,
    "percentage": 69
},
    "meanNumberOfRequestsPerSecond": {
        "total": "136.904",
        "ok": "42.043",
        "ko": "94.861"
    }
}
    },"req_-get--the-list--3525d": {
        type: "REQUEST",
        name: "[GET] The list of available cities is presented.",
path: "[GET] The list of available cities is presented.",
pathFormatted: "req_-get--the-list--3525d",
stats: {
    "name": "[GET] The list of available cities is presented.",
    "numberOfRequests": {
        "total": "92462",
        "ok": "76421",
        "ko": "16041"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "5",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "78622",
        "ok": "78622",
        "ko": "76328"
    },
    "meanResponseTime": {
        "total": "24916",
        "ok": "28058",
        "ko": "9947"
    },
    "standardDeviation": {
        "total": "15747",
        "ok": "14729",
        "ko": "11166"
    },
    "percentiles1": {
        "total": "22915",
        "ok": "26593",
        "ko": "7167"
    },
    "percentiles2": {
        "total": "35772",
        "ok": "37000",
        "ko": "13668"
    },
    "percentiles3": {
        "total": "55247",
        "ok": "56314",
        "ko": "30053"
    },
    "percentiles4": {
        "total": "64201",
        "ok": "64872",
        "ko": "60438"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 384,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 1256,
    "percentage": 1
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 74781,
    "percentage": 81
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 16041,
    "percentage": 17
},
    "meanNumberOfRequestsPerSecond": {
        "total": "83.98",
        "ok": "69.411",
        "ko": "14.569"
    }
}
    },"req_-get--the-list--11d52": {
        type: "REQUEST",
        name: "[GET] The list of available origins is presented.",
path: "[GET] The list of available origins is presented.",
pathFormatted: "req_-get--the-list--11d52",
stats: {
    "name": "[GET] The list of available origins is presented.",
    "numberOfRequests": {
        "total": "46173",
        "ok": "23088",
        "ko": "23085"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "8"
    },
    "maxResponseTime": {
        "total": "77846",
        "ok": "77311",
        "ko": "77846"
    },
    "meanResponseTime": {
        "total": "30445",
        "ok": "30199",
        "ko": "30690"
    },
    "standardDeviation": {
        "total": "14358",
        "ok": "14142",
        "ko": "14568"
    },
    "percentiles1": {
        "total": "29261",
        "ok": "29269",
        "ko": "29389"
    },
    "percentiles2": {
        "total": "40050",
        "ok": "39876",
        "ko": "40084"
    },
    "percentiles3": {
        "total": "57139",
        "ok": "55679",
        "ko": "58080"
    },
    "percentiles4": {
        "total": "62948",
        "ok": "62797",
        "ko": "63117"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 95,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 323,
    "percentage": 1
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 22670,
    "percentage": 49
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 23085,
    "percentage": 50
},
    "meanNumberOfRequestsPerSecond": {
        "total": "41.937",
        "ok": "20.97",
        "ko": "20.967"
    }
}
    },"req_-get--the-list--0dc40": {
        type: "REQUEST",
        name: "[GET] The list of available destinations is presented.",
path: "[GET] The list of available destinations is presented.",
pathFormatted: "req_-get--the-list--0dc40",
stats: {
    "name": "[GET] The list of available destinations is presented.",
    "numberOfRequests": {
        "total": "22972",
        "ok": "11483",
        "ko": "11489"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "167",
        "ko": "6"
    },
    "maxResponseTime": {
        "total": "77120",
        "ok": "75574",
        "ko": "77120"
    },
    "meanResponseTime": {
        "total": "25809",
        "ok": "25709",
        "ko": "25908"
    },
    "standardDeviation": {
        "total": "15245",
        "ok": "15047",
        "ko": "15439"
    },
    "percentiles1": {
        "total": "20643",
        "ok": "20786",
        "ko": "20602"
    },
    "percentiles2": {
        "total": "36352",
        "ok": "36223",
        "ko": "36464"
    },
    "percentiles3": {
        "total": "56094",
        "ok": "55208",
        "ko": "57091"
    },
    "percentiles4": {
        "total": "64205",
        "ok": "63835",
        "ko": "64725"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 1,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 162,
    "percentage": 1
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 11320,
    "percentage": 49
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 11489,
    "percentage": 50
},
    "meanNumberOfRequestsPerSecond": {
        "total": "20.865",
        "ok": "10.43",
        "ko": "10.435"
    }
}
    },"req_-get--the-list--8bddb": {
        type: "REQUEST",
        name: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
path: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
pathFormatted: "req_-get--the-list--8bddb",
stats: {
    "name": "[GET] The list of available transfers by selected origin, destination, and date is presented.",
    "numberOfRequests": {
        "total": "11483",
        "ok": "3073",
        "ko": "8410"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "4",
        "ko": "3"
    },
    "maxResponseTime": {
        "total": "74606",
        "ok": "74606",
        "ko": "74476"
    },
    "meanResponseTime": {
        "total": "24887",
        "ok": "24863",
        "ko": "24896"
    },
    "standardDeviation": {
        "total": "14260",
        "ok": "14179",
        "ko": "14289"
    },
    "percentiles1": {
        "total": "21908",
        "ok": "21686",
        "ko": "22018"
    },
    "percentiles2": {
        "total": "35152",
        "ok": "35184",
        "ko": "35134"
    },
    "percentiles3": {
        "total": "51107",
        "ok": "51632",
        "ko": "51042"
    },
    "percentiles4": {
        "total": "62421",
        "ok": "62447",
        "ko": "62376"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 60,
    "percentage": 1
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 50,
    "percentage": 0
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 2963,
    "percentage": 26
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 8410,
    "percentage": 73
},
    "meanNumberOfRequestsPerSecond": {
        "total": "10.43",
        "ok": "2.791",
        "ko": "7.639"
    }
}
    },"req_-post--the-tran-5ac29": {
        type: "REQUEST",
        name: "[POST] The transfer is booked in the system.",
path: "[POST] The transfer is booked in the system.",
pathFormatted: "req_-post--the-tran-5ac29",
stats: {
    "name": "[POST] The transfer is booked in the system.",
    "numberOfRequests": {
        "total": "3073",
        "ok": "3060",
        "ko": "13"
    },
    "minResponseTime": {
        "total": "4",
        "ok": "4",
        "ko": "15"
    },
    "maxResponseTime": {
        "total": "78570",
        "ok": "78570",
        "ko": "60895"
    },
    "meanResponseTime": {
        "total": "20460",
        "ok": "20315",
        "ko": "54516"
    },
    "standardDeviation": {
        "total": "14522",
        "ok": "14343",
        "ko": "16305"
    },
    "percentiles1": {
        "total": "16849",
        "ok": "16824",
        "ko": "60326"
    },
    "percentiles2": {
        "total": "26833",
        "ok": "26718",
        "ko": "60575"
    },
    "percentiles3": {
        "total": "48433",
        "ok": "46874",
        "ko": "60798"
    },
    "percentiles4": {
        "total": "64046",
        "ok": "64088",
        "ko": "60876"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 142,
    "percentage": 5
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 116,
    "percentage": 4
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 2802,
    "percentage": 91
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 13,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2.791",
        "ok": "2.779",
        "ko": "0.012"
    }
}
    },"req_-get--the-list--4f742": {
        type: "REQUEST",
        name: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
path: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
pathFormatted: "req_-get--the-list--4f742",
stats: {
    "name": "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
    "numberOfRequests": {
        "total": "3073",
        "ok": "1563",
        "ko": "1510"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "3",
        "ko": "1"
    },
    "maxResponseTime": {
        "total": "68860",
        "ok": "68860",
        "ko": "66984"
    },
    "meanResponseTime": {
        "total": "19720",
        "ok": "19372",
        "ko": "20080"
    },
    "standardDeviation": {
        "total": "14268",
        "ok": "14281",
        "ko": "14245"
    },
    "percentiles1": {
        "total": "16513",
        "ok": "15818",
        "ko": "16829"
    },
    "percentiles2": {
        "total": "28565",
        "ok": "27719",
        "ko": "28981"
    },
    "percentiles3": {
        "total": "45226",
        "ok": "45206",
        "ko": "45200"
    },
    "percentiles4": {
        "total": "60009",
        "ok": "58595",
        "ko": "60346"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 139,
    "percentage": 5
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 93,
    "percentage": 3
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 1331,
    "percentage": 43
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 1510,
    "percentage": 49
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2.791",
        "ok": "1.42",
        "ko": "1.371"
    }
}
    },"req_-get--one-of-th-c14cc": {
        type: "REQUEST",
        name: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
path: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
pathFormatted: "req_-get--one-of-th-c14cc",
stats: {
    "name": "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
    "numberOfRequests": {
        "total": "1561",
        "ok": "1558",
        "ko": "3"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "60001"
    },
    "maxResponseTime": {
        "total": "71774",
        "ok": "71774",
        "ko": "60629"
    },
    "meanResponseTime": {
        "total": "19064",
        "ok": "18985",
        "ko": "60387"
    },
    "standardDeviation": {
        "total": "13797",
        "ok": "13690",
        "ko": "276"
    },
    "percentiles1": {
        "total": "17667",
        "ok": "17649",
        "ko": "60532"
    },
    "percentiles2": {
        "total": "28521",
        "ok": "28474",
        "ko": "60581"
    },
    "percentiles3": {
        "total": "42913",
        "ok": "42086",
        "ko": "60619"
    },
    "percentiles4": {
        "total": "57900",
        "ok": "57395",
        "ko": "60627"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 231,
    "percentage": 15
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 47,
    "percentage": 3
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 1280,
    "percentage": 82
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 3,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.418",
        "ok": "1.415",
        "ko": "0.003"
    }
}
    },"req_-put--any--book-143cf": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer description is updated.",
path: "[PUT] Any (BOOKED) transfer description is updated.",
pathFormatted: "req_-put--any--book-143cf",
stats: {
    "name": "[PUT] Any (BOOKED) transfer description is updated.",
    "numberOfRequests": {
        "total": "1561",
        "ok": "1558",
        "ko": "3"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "9126"
    },
    "maxResponseTime": {
        "total": "73435",
        "ok": "68303",
        "ko": "73435"
    },
    "meanResponseTime": {
        "total": "17571",
        "ok": "17546",
        "ko": "30704"
    },
    "standardDeviation": {
        "total": "13754",
        "ok": "13691",
        "ko": "30216"
    },
    "percentiles1": {
        "total": "16625",
        "ok": "16632",
        "ko": "9551"
    },
    "percentiles2": {
        "total": "24395",
        "ok": "24387",
        "ko": "41493"
    },
    "percentiles3": {
        "total": "41938",
        "ok": "41862",
        "ko": "67047"
    },
    "percentiles4": {
        "total": "56946",
        "ok": "56494",
        "ko": "72157"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 285,
    "percentage": 18
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 53,
    "percentage": 3
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 1220,
    "percentage": 78
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 3,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.418",
        "ok": "1.415",
        "ko": "0.003"
    }
}
    },"req_-put--any--book-bb16d": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
path: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
pathFormatted: "req_-put--any--book-bb16d",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
    "numberOfRequests": {
        "total": "1561",
        "ok": "1558",
        "ko": "3"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "16051"
    },
    "maxResponseTime": {
        "total": "76328",
        "ok": "73661",
        "ko": "76328"
    },
    "meanResponseTime": {
        "total": "19013",
        "ok": "18973",
        "ko": "39613"
    },
    "standardDeviation": {
        "total": "14651",
        "ok": "14592",
        "ko": "26307"
    },
    "percentiles1": {
        "total": "18371",
        "ok": "18365",
        "ko": "26461"
    },
    "percentiles2": {
        "total": "29777",
        "ok": "29774",
        "ko": "51395"
    },
    "percentiles3": {
        "total": "43613",
        "ok": "43546",
        "ko": "71341"
    },
    "percentiles4": {
        "total": "55239",
        "ok": "54793",
        "ko": "75331"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 337,
    "percentage": 22
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 54,
    "percentage": 3
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 1167,
    "percentage": 75
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 3,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.418",
        "ok": "1.415",
        "ko": "0.003"
    }
}
    },"req_-put--any--book-fdf7e": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
path: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
pathFormatted: "req_-put--any--book-fdf7e",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
    "numberOfRequests": {
        "total": "1561",
        "ok": "1557",
        "ko": "4"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "2283"
    },
    "maxResponseTime": {
        "total": "64527",
        "ok": "64527",
        "ko": "60682"
    },
    "meanResponseTime": {
        "total": "18137",
        "ok": "18111",
        "ko": "28166"
    },
    "standardDeviation": {
        "total": "14688",
        "ok": "14657",
        "ko": "21692"
    },
    "percentiles1": {
        "total": "15982",
        "ok": "15979",
        "ko": "24849"
    },
    "percentiles2": {
        "total": "28447",
        "ok": "28402",
        "ko": "39922"
    },
    "percentiles3": {
        "total": "44045",
        "ok": "43872",
        "ko": "56530"
    },
    "percentiles4": {
        "total": "51084",
        "ok": "50925",
        "ko": "59852"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 390,
    "percentage": 25
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 14,
    "percentage": 1
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 1153,
    "percentage": 74
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 4,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.418",
        "ok": "1.414",
        "ko": "0.004"
    }
}
    },"req_-get--user-is-r-f03f4": {
        type: "REQUEST",
        name: "[GET] User is retrieved with her/his transfers data.",
path: "[GET] User is retrieved with her/his transfers data.",
pathFormatted: "req_-get--user-is-r-f03f4",
stats: {
    "name": "[GET] User is retrieved with her/his transfers data.",
    "numberOfRequests": {
        "total": "1561",
        "ok": "1557",
        "ko": "4"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "5967"
    },
    "maxResponseTime": {
        "total": "66071",
        "ok": "66071",
        "ko": "21631"
    },
    "meanResponseTime": {
        "total": "19516",
        "ok": "19540",
        "ko": "10428"
    },
    "standardDeviation": {
        "total": "15424",
        "ok": "15434",
        "ko": "6527"
    },
    "percentiles1": {
        "total": "19851",
        "ok": "19855",
        "ko": "7056"
    },
    "percentiles2": {
        "total": "32657",
        "ok": "32667",
        "ko": "11498"
    },
    "percentiles3": {
        "total": "43490",
        "ok": "43503",
        "ko": "19604"
    },
    "percentiles4": {
        "total": "50960",
        "ok": "50960",
        "ko": "21226"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 405,
    "percentage": 26
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 21,
    "percentage": 1
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 1131,
    "percentage": 72
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 4,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.418",
        "ok": "1.414",
        "ko": "0.004"
    }
}
    },"req_-put--user-upda-c8c46": {
        type: "REQUEST",
        name: "[PUT] User updates with her/his own data.",
path: "[PUT] User updates with her/his own data.",
pathFormatted: "req_-put--user-upda-c8c46",
stats: {
    "name": "[PUT] User updates with her/his own data.",
    "numberOfRequests": {
        "total": "1561",
        "ok": "1558",
        "ko": "3"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "4058"
    },
    "maxResponseTime": {
        "total": "66453",
        "ok": "66453",
        "ko": "60787"
    },
    "meanResponseTime": {
        "total": "18785",
        "ok": "18741",
        "ko": "41615"
    },
    "standardDeviation": {
        "total": "15412",
        "ok": "15350",
        "ko": "26559"
    },
    "percentiles1": {
        "total": "17941",
        "ok": "17930",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "31517",
        "ok": "31465",
        "ko": "60394"
    },
    "percentiles3": {
        "total": "43246",
        "ok": "43230",
        "ko": "60708"
    },
    "percentiles4": {
        "total": "49311",
        "ok": "48731",
        "ko": "60771"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 427,
    "percentage": 27
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 23,
    "percentage": 1
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 1108,
    "percentage": 71
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 3,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.418",
        "ok": "1.415",
        "ko": "0.003"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
