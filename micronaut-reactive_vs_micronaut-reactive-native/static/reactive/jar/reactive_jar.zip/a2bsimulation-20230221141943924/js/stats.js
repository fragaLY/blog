var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "683907",
        "ok": "565186",
        "ko": "118721"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "2",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "22813",
        "ok": "22813",
        "ko": "22429"
    },
    "meanResponseTime": {
        "total": "12701",
        "ok": "14696",
        "ko": "3207"
    },
    "standardDeviation": {
        "total": "6384",
        "ok": "4231",
        "ko": "6361"
    },
    "percentiles1": {
        "total": "15157",
        "ok": "15559",
        "ko": "0"
    },
    "percentiles2": {
        "total": "16696",
        "ok": "17035",
        "ko": "1"
    },
    "percentiles3": {
        "total": "19540",
        "ok": "19869",
        "ko": "17188"
    },
    "percentiles4": {
        "total": "21426",
        "ok": "21523",
        "ko": "20022"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 3191,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 16479,
    "percentage": 2
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 545516,
    "percentage": 80
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 118721,
    "percentage": 17
},
    "meanNumberOfRequestsPerSecond": {
        "total": "616.132",
        "ok": "509.177",
        "ko": "106.956"
    }
},
contents: {
"req_-get--the-list--c0b76": {
        type: "REQUEST",
        name: "[GET] The list of available countries is presented.",
path: "[GET] The list of available countries is presented.",
pathFormatted: "req_-get--the-list--c0b76",
stats: {
    "name": "[GET] The list of available countries is presented.",
    "numberOfRequests": {
        "total": "150042",
        "ok": "56657",
        "ko": "93385"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "428",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "22813",
        "ok": "22813",
        "ko": "396"
    },
    "meanResponseTime": {
        "total": "5514",
        "ok": "14602",
        "ko": "1"
    },
    "standardDeviation": {
        "total": "7579",
        "ok": "4406",
        "ko": "10"
    },
    "percentiles1": {
        "total": "1",
        "ok": "15664",
        "ko": "0"
    },
    "percentiles2": {
        "total": "14793",
        "ok": "17091",
        "ko": "0"
    },
    "percentiles3": {
        "total": "18288",
        "ok": "20094",
        "ko": "1"
    },
    "percentiles4": {
        "total": "20937",
        "ok": "21704",
        "ko": "1"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 2126,
    "percentage": 1
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 54531,
    "percentage": 36
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 93385,
    "percentage": 62
},
    "meanNumberOfRequestsPerSecond": {
        "total": "135.173",
        "ok": "51.042",
        "ko": "84.131"
    }
}
    },"req_-get--the-list--3525d": {
        type: "REQUEST",
        name: "[GET] The list of available cities is presented.",
path: "[GET] The list of available cities is presented.",
pathFormatted: "req_-get--the-list--3525d",
stats: {
    "name": "[GET] The list of available cities is presented.",
    "numberOfRequests": {
        "total": "113314",
        "ok": "113314",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "587",
        "ok": "587",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "22440",
        "ok": "22440",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14845",
        "ok": "14845",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3974",
        "ok": "3974",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15541",
        "ok": "15541",
        "ko": "-"
    },
    "percentiles2": {
        "total": "17083",
        "ok": "17082",
        "ko": "-"
    },
    "percentiles3": {
        "total": "19955",
        "ok": "19955",
        "ko": "-"
    },
    "percentiles4": {
        "total": "21598",
        "ok": "21598",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 2781,
    "percentage": 2
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 110533,
    "percentage": 98
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "102.085",
        "ok": "102.085",
        "ko": "-"
    }
}
    },"req_-get--the-list--11d52": {
        type: "REQUEST",
        name: "[GET] The list of available origins is presented.",
path: "[GET] The list of available origins is presented.",
pathFormatted: "req_-get--the-list--11d52",
stats: {
    "name": "[GET] The list of available origins is presented.",
    "numberOfRequests": {
        "total": "56657",
        "ok": "56657",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1005",
        "ok": "1005",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "22432",
        "ok": "22432",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14826",
        "ok": "14826",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3927",
        "ok": "3927",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15515",
        "ok": "15515",
        "ko": "-"
    },
    "percentiles2": {
        "total": "17038",
        "ok": "17038",
        "ko": "-"
    },
    "percentiles3": {
        "total": "19630",
        "ok": "19630",
        "ko": "-"
    },
    "percentiles4": {
        "total": "21460",
        "ok": "21460",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 1463,
    "percentage": 3
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 55194,
    "percentage": 97
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "51.042",
        "ok": "51.042",
        "ko": "-"
    }
}
    },"req_-get--the-list--0dc40": {
        type: "REQUEST",
        name: "[GET] The list of available destinations is presented.",
path: "[GET] The list of available destinations is presented.",
pathFormatted: "req_-get--the-list--0dc40",
stats: {
    "name": "[GET] The list of available destinations is presented.",
    "numberOfRequests": {
        "total": "56657",
        "ok": "56657",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1577",
        "ok": "1577",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "22424",
        "ok": "22424",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14951",
        "ok": "14951",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3499",
        "ok": "3499",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15462",
        "ok": "15462",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16966",
        "ok": "16966",
        "ko": "-"
    },
    "percentiles3": {
        "total": "19727",
        "ok": "19727",
        "ko": "-"
    },
    "percentiles4": {
        "total": "21427",
        "ok": "21427",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 535,
    "percentage": 1
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 56122,
    "percentage": 99
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "51.042",
        "ok": "51.042",
        "ko": "-"
    }
}
    },"req_-get--the-list--8bddb": {
        type: "REQUEST",
        name: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
path: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
pathFormatted: "req_-get--the-list--8bddb",
stats: {
    "name": "[GET] The list of available transfers by selected origin, destination, and date is presented.",
    "numberOfRequests": {
        "total": "56657",
        "ok": "31327",
        "ko": "25330"
    },
    "minResponseTime": {
        "total": "1896",
        "ok": "1905",
        "ko": "1896"
    },
    "maxResponseTime": {
        "total": "22429",
        "ok": "22426",
        "ko": "22429"
    },
    "meanResponseTime": {
        "total": "15037",
        "ok": "15049",
        "ko": "15023"
    },
    "standardDeviation": {
        "total": "3447",
        "ok": "3424",
        "ko": "3476"
    },
    "percentiles1": {
        "total": "15537",
        "ok": "15542",
        "ko": "15522"
    },
    "percentiles2": {
        "total": "16991",
        "ok": "16974",
        "ko": "17006"
    },
    "percentiles3": {
        "total": "19848",
        "ok": "19833",
        "ko": "19881"
    },
    "percentiles4": {
        "total": "21458",
        "ok": "21450",
        "ko": "21474"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 59,
    "percentage": 0
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 31268,
    "percentage": 55
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 25330,
    "percentage": 45
},
    "meanNumberOfRequestsPerSecond": {
        "total": "51.042",
        "ok": "28.223",
        "ko": "22.82"
    }
}
    },"req_-post--the-tran-5ac29": {
        type: "REQUEST",
        name: "[POST] The transfer is booked in the system.",
path: "[POST] The transfer is booked in the system.",
pathFormatted: "req_-post--the-tran-5ac29",
stats: {
    "name": "[POST] The transfer is booked in the system.",
    "numberOfRequests": {
        "total": "31327",
        "ok": "31321",
        "ko": "6"
    },
    "minResponseTime": {
        "total": "2995",
        "ok": "2995",
        "ko": "8856"
    },
    "maxResponseTime": {
        "total": "22444",
        "ok": "22444",
        "ko": "21480"
    },
    "meanResponseTime": {
        "total": "15086",
        "ok": "15086",
        "ko": "15524"
    },
    "standardDeviation": {
        "total": "3620",
        "ok": "3620",
        "ko": "4196"
    },
    "percentiles1": {
        "total": "15675",
        "ok": "15674",
        "ko": "15868"
    },
    "percentiles2": {
        "total": "17148",
        "ok": "17148",
        "ko": "18353"
    },
    "percentiles3": {
        "total": "19987",
        "ok": "19982",
        "ko": "20885"
    },
    "percentiles4": {
        "total": "21567",
        "ok": "21568",
        "ko": "21361"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 2,
    "percentage": 0
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 31319,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 6,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "28.223",
        "ok": "28.217",
        "ko": "0.005"
    }
}
    },"req_-get--the-list--4f742": {
        type: "REQUEST",
        name: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
path: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
pathFormatted: "req_-get--the-list--4f742",
stats: {
    "name": "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
    "numberOfRequests": {
        "total": "31327",
        "ok": "31327",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1778",
        "ok": "1778",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "22436",
        "ok": "22436",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "15008",
        "ok": "15008",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3877",
        "ok": "3877",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15686",
        "ok": "15683",
        "ko": "-"
    },
    "percentiles2": {
        "total": "17158",
        "ok": "17157",
        "ko": "-"
    },
    "percentiles3": {
        "total": "20192",
        "ok": "20196",
        "ko": "-"
    },
    "percentiles4": {
        "total": "21613",
        "ok": "21613",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 325,
    "percentage": 1
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 31002,
    "percentage": 99
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "28.223",
        "ok": "28.223",
        "ko": "-"
    }
}
    },"req_-get--one-of-th-c14cc": {
        type: "REQUEST",
        name: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
path: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
pathFormatted: "req_-get--one-of-th-c14cc",
stats: {
    "name": "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
    "numberOfRequests": {
        "total": "31321",
        "ok": "31321",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1108",
        "ok": "1108",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "22435",
        "ok": "22435",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14822",
        "ok": "14822",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4058",
        "ok": "4058",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15576",
        "ok": "15578",
        "ko": "-"
    },
    "percentiles2": {
        "total": "17085",
        "ok": "17106",
        "ko": "-"
    },
    "percentiles3": {
        "total": "19925",
        "ok": "19926",
        "ko": "-"
    },
    "percentiles4": {
        "total": "21399",
        "ok": "21399",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 852,
    "percentage": 3
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 30469,
    "percentage": 97
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "28.217",
        "ok": "28.217",
        "ko": "-"
    }
}
    },"req_-put--any--book-143cf": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer description is updated.",
path: "[PUT] Any (BOOKED) transfer description is updated.",
pathFormatted: "req_-put--any--book-143cf",
stats: {
    "name": "[PUT] Any (BOOKED) transfer description is updated.",
    "numberOfRequests": {
        "total": "31321",
        "ok": "31321",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "266",
        "ok": "266",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "22429",
        "ok": "22429",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14623",
        "ok": "14623",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4342",
        "ok": "4342",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15528",
        "ok": "15516",
        "ko": "-"
    },
    "percentiles2": {
        "total": "17017",
        "ok": "17018",
        "ko": "-"
    },
    "percentiles3": {
        "total": "19738",
        "ok": "19740",
        "ko": "-"
    },
    "percentiles4": {
        "total": "21442",
        "ok": "21442",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 3,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 1428,
    "percentage": 5
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 29890,
    "percentage": 95
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "28.217",
        "ok": "28.217",
        "ko": "-"
    }
}
    },"req_-put--any--book-bb16d": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
path: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
pathFormatted: "req_-put--any--book-bb16d",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
    "numberOfRequests": {
        "total": "31321",
        "ok": "31321",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "22426",
        "ok": "22426",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14436",
        "ok": "14436",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4629",
        "ok": "4629",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15497",
        "ok": "15498",
        "ko": "-"
    },
    "percentiles2": {
        "total": "17052",
        "ok": "17050",
        "ko": "-"
    },
    "percentiles3": {
        "total": "19732",
        "ok": "19733",
        "ko": "-"
    },
    "percentiles4": {
        "total": "21422",
        "ok": "21427",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 137,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 1692,
    "percentage": 5
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 29492,
    "percentage": 94
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "28.217",
        "ok": "28.217",
        "ko": "-"
    }
}
    },"req_-put--any--book-fdf7e": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
path: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
pathFormatted: "req_-put--any--book-fdf7e",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
    "numberOfRequests": {
        "total": "31321",
        "ok": "31321",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "22431",
        "ok": "22431",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14217",
        "ok": "14217",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4902",
        "ok": "4902",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15484",
        "ok": "15485",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16887",
        "ok": "16884",
        "ko": "-"
    },
    "percentiles3": {
        "total": "19607",
        "ok": "19605",
        "ko": "-"
    },
    "percentiles4": {
        "total": "21377",
        "ok": "21377",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 536,
    "percentage": 2
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 1719,
    "percentage": 5
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 29066,
    "percentage": 93
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "28.217",
        "ok": "28.217",
        "ko": "-"
    }
}
    },"req_-get--user-is-r-f03f4": {
        type: "REQUEST",
        name: "[GET] User is retrieved with her/his transfers data.",
path: "[GET] User is retrieved with her/his transfers data.",
pathFormatted: "req_-get--user-is-r-f03f4",
stats: {
    "name": "[GET] User is retrieved with her/his transfers data.",
    "numberOfRequests": {
        "total": "31321",
        "ok": "31321",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "22433",
        "ok": "22433",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14042",
        "ok": "14042",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5204",
        "ok": "5204",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15562",
        "ok": "15559",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16889",
        "ok": "16890",
        "ko": "-"
    },
    "percentiles3": {
        "total": "19418",
        "ok": "19416",
        "ko": "-"
    },
    "percentiles4": {
        "total": "21322",
        "ok": "21323",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 1025,
    "percentage": 3
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 1714,
    "percentage": 5
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 28582,
    "percentage": 91
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "28.217",
        "ok": "28.217",
        "ko": "-"
    }
}
    },"req_-put--user-upda-c8c46": {
        type: "REQUEST",
        name: "[PUT] User updates with her/his own data.",
path: "[PUT] User updates with her/his own data.",
pathFormatted: "req_-put--user-upda-c8c46",
stats: {
    "name": "[PUT] User updates with her/his own data.",
    "numberOfRequests": {
        "total": "31321",
        "ok": "31321",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "22442",
        "ok": "22442",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "13916",
        "ok": "13916",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5566",
        "ok": "5566",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15626",
        "ok": "15626",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16917",
        "ok": "16917",
        "ko": "-"
    },
    "percentiles3": {
        "total": "20114",
        "ok": "20115",
        "ko": "-"
    },
    "percentiles4": {
        "total": "21716",
        "ok": "21716",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 1490,
    "percentage": 5
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 1783,
    "percentage": 6
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 28048,
    "percentage": 90
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "28.217",
        "ok": "28.217",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
