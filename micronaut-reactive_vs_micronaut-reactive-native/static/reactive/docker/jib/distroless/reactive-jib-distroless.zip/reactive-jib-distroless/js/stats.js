var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "489590",
        "ok": "358998",
        "ko": "130592"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "2",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "47125",
        "ok": "47125",
        "ko": "47080"
    },
    "meanResponseTime": {
        "total": "20043",
        "ok": "26025",
        "ko": "3597"
    },
    "standardDeviation": {
        "total": "13248",
        "ok": "8331",
        "ko": "9919"
    },
    "percentiles1": {
        "total": "25369",
        "ok": "26636",
        "ko": "0"
    },
    "percentiles2": {
        "total": "28297",
        "ok": "30268",
        "ko": "1"
    },
    "percentiles3": {
        "total": "37474",
        "ok": "37959",
        "ko": "29119"
    },
    "percentiles4": {
        "total": "43707",
        "ok": "44163",
        "ko": "39583"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 2275,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 8995,
    "percentage": 2
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 347728,
    "percentage": 71
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 130592,
    "percentage": 27
},
    "meanNumberOfRequestsPerSecond": {
        "total": "416.672",
        "ok": "305.53",
        "ko": "111.142"
    }
},
contents: {
"req_-get--the-list--c0b76": {
        type: "REQUEST",
        name: "[GET] The list of available countries is presented.",
path: "[GET] The list of available countries is presented.",
pathFormatted: "req_-get--the-list--c0b76",
stats: {
    "name": "[GET] The list of available countries is presented.",
    "numberOfRequests": {
        "total": "150498",
        "ok": "35966",
        "ko": "114532"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "2117",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "47044",
        "ok": "47044",
        "ko": "23046"
    },
    "meanResponseTime": {
        "total": "6185",
        "ok": "25878",
        "ko": "1"
    },
    "standardDeviation": {
        "total": "11621",
        "ok": "7452",
        "ko": "93"
    },
    "percentiles1": {
        "total": "0",
        "ok": "26771",
        "ko": "0"
    },
    "percentiles2": {
        "total": "1",
        "ok": "29707",
        "ko": "0"
    },
    "percentiles3": {
        "total": "30805",
        "ok": "36954",
        "ko": "1"
    },
    "percentiles4": {
        "total": "37324",
        "ok": "43756",
        "ko": "1"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 384,
    "percentage": 0
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 35582,
    "percentage": 24
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 114532,
    "percentage": 76
},
    "meanNumberOfRequestsPerSecond": {
        "total": "128.083",
        "ok": "30.609",
        "ko": "97.474"
    }
}
    },"req_-get--the-list--3525d": {
        type: "REQUEST",
        name: "[GET] The list of available cities is presented.",
path: "[GET] The list of available cities is presented.",
pathFormatted: "req_-get--the-list--3525d",
stats: {
    "name": "[GET] The list of available cities is presented.",
    "numberOfRequests": {
        "total": "71932",
        "ok": "71932",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2561",
        "ok": "2561",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "47036",
        "ok": "47036",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "28078",
        "ok": "28078",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "6379",
        "ok": "6379",
        "ko": "-"
    },
    "percentiles1": {
        "total": "27394",
        "ok": "27378",
        "ko": "-"
    },
    "percentiles2": {
        "total": "32662",
        "ok": "32662",
        "ko": "-"
    },
    "percentiles3": {
        "total": "38207",
        "ok": "38208",
        "ko": "-"
    },
    "percentiles4": {
        "total": "42578",
        "ok": "42577",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 85,
    "percentage": 0
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 71847,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "61.219",
        "ok": "61.219",
        "ko": "-"
    }
}
    },"req_-get--the-list--11d52": {
        type: "REQUEST",
        name: "[GET] The list of available origins is presented.",
path: "[GET] The list of available origins is presented.",
pathFormatted: "req_-get--the-list--11d52",
stats: {
    "name": "[GET] The list of available origins is presented.",
    "numberOfRequests": {
        "total": "35966",
        "ok": "35966",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "5470",
        "ok": "5470",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "47125",
        "ok": "47125",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "28620",
        "ok": "28620",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "6304",
        "ok": "6304",
        "ko": "-"
    },
    "percentiles1": {
        "total": "27673",
        "ok": "27665",
        "ko": "-"
    },
    "percentiles2": {
        "total": "32694",
        "ok": "32698",
        "ko": "-"
    },
    "percentiles3": {
        "total": "38494",
        "ok": "38494",
        "ko": "-"
    },
    "percentiles4": {
        "total": "43413",
        "ok": "43413",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 35966,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "30.609",
        "ok": "30.609",
        "ko": "-"
    }
}
    },"req_-get--the-list--0dc40": {
        type: "REQUEST",
        name: "[GET] The list of available destinations is presented.",
path: "[GET] The list of available destinations is presented.",
pathFormatted: "req_-get--the-list--0dc40",
stats: {
    "name": "[GET] The list of available destinations is presented.",
    "numberOfRequests": {
        "total": "35966",
        "ok": "35966",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "12442",
        "ok": "12442",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "47086",
        "ok": "47086",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "29218",
        "ok": "29218",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5951",
        "ok": "5951",
        "ko": "-"
    },
    "percentiles1": {
        "total": "27818",
        "ok": "27818",
        "ko": "-"
    },
    "percentiles2": {
        "total": "33262",
        "ok": "33261",
        "ko": "-"
    },
    "percentiles3": {
        "total": "38848",
        "ok": "38847",
        "ko": "-"
    },
    "percentiles4": {
        "total": "45705",
        "ok": "45705",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 35966,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "30.609",
        "ok": "30.609",
        "ko": "-"
    }
}
    },"req_-get--the-list--8bddb": {
        type: "REQUEST",
        name: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
path: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
pathFormatted: "req_-get--the-list--8bddb",
stats: {
    "name": "[GET] The list of available transfers by selected origin, destination, and date is presented.",
    "numberOfRequests": {
        "total": "35966",
        "ok": "19913",
        "ko": "16053"
    },
    "minResponseTime": {
        "total": "5759",
        "ok": "5759",
        "ko": "5923"
    },
    "maxResponseTime": {
        "total": "47080",
        "ok": "47067",
        "ko": "47080"
    },
    "meanResponseTime": {
        "total": "29174",
        "ok": "29115",
        "ko": "29247"
    },
    "standardDeviation": {
        "total": "7015",
        "ok": "6977",
        "ko": "7061"
    },
    "percentiles1": {
        "total": "27827",
        "ok": "27823",
        "ko": "27832"
    },
    "percentiles2": {
        "total": "33184",
        "ok": "33101",
        "ko": "33313"
    },
    "percentiles3": {
        "total": "43391",
        "ok": "43306",
        "ko": "43458"
    },
    "percentiles4": {
        "total": "45997",
        "ok": "45947",
        "ko": "46050"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 19913,
    "percentage": 55
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 16053,
    "percentage": 45
},
    "meanNumberOfRequestsPerSecond": {
        "total": "30.609",
        "ok": "16.947",
        "ko": "13.662"
    }
}
    },"req_-post--the-tran-5ac29": {
        type: "REQUEST",
        name: "[POST] The transfer is booked in the system.",
path: "[POST] The transfer is booked in the system.",
pathFormatted: "req_-post--the-tran-5ac29",
stats: {
    "name": "[POST] The transfer is booked in the system.",
    "numberOfRequests": {
        "total": "19913",
        "ok": "19906",
        "ko": "7"
    },
    "minResponseTime": {
        "total": "3783",
        "ok": "3783",
        "ko": "12848"
    },
    "maxResponseTime": {
        "total": "47077",
        "ok": "47077",
        "ko": "33308"
    },
    "meanResponseTime": {
        "total": "26892",
        "ok": "26893",
        "ko": "25233"
    },
    "standardDeviation": {
        "total": "7412",
        "ok": "7412",
        "ko": "6630"
    },
    "percentiles1": {
        "total": "26556",
        "ok": "26557",
        "ko": "25507"
    },
    "percentiles2": {
        "total": "30317",
        "ok": "30313",
        "ko": "30415"
    },
    "percentiles3": {
        "total": "39471",
        "ok": "39471",
        "ko": "33262"
    },
    "percentiles4": {
        "total": "45718",
        "ok": "45719",
        "ko": "33299"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 19906,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 7,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "16.947",
        "ok": "16.941",
        "ko": "0.006"
    }
}
    },"req_-get--the-list--4f742": {
        type: "REQUEST",
        name: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
path: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
pathFormatted: "req_-get--the-list--4f742",
stats: {
    "name": "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
    "numberOfRequests": {
        "total": "19913",
        "ok": "19913",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2758",
        "ok": "2758",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "47105",
        "ok": "47105",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "25439",
        "ok": "25439",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "7797",
        "ok": "7797",
        "ko": "-"
    },
    "percentiles1": {
        "total": "26020",
        "ok": "26020",
        "ko": "-"
    },
    "percentiles2": {
        "total": "27954",
        "ok": "27953",
        "ko": "-"
    },
    "percentiles3": {
        "total": "38239",
        "ok": "38239",
        "ko": "-"
    },
    "percentiles4": {
        "total": "45709",
        "ok": "45710",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 17,
    "percentage": 0
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 19896,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "16.947",
        "ok": "16.947",
        "ko": "-"
    }
}
    },"req_-get--one-of-th-c14cc": {
        type: "REQUEST",
        name: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
path: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
pathFormatted: "req_-get--one-of-th-c14cc",
stats: {
    "name": "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
    "numberOfRequests": {
        "total": "19906",
        "ok": "19906",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1854",
        "ok": "1854",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "47011",
        "ok": "47011",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "24941",
        "ok": "24941",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "8545",
        "ok": "8545",
        "ko": "-"
    },
    "percentiles1": {
        "total": "26289",
        "ok": "26288",
        "ko": "-"
    },
    "percentiles2": {
        "total": "28706",
        "ok": "28708",
        "ko": "-"
    },
    "percentiles3": {
        "total": "37251",
        "ok": "37246",
        "ko": "-"
    },
    "percentiles4": {
        "total": "45265",
        "ok": "45265",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 285,
    "percentage": 1
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 19621,
    "percentage": 99
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "16.941",
        "ok": "16.941",
        "ko": "-"
    }
}
    },"req_-put--any--book-143cf": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer description is updated.",
path: "[PUT] Any (BOOKED) transfer description is updated.",
pathFormatted: "req_-put--any--book-143cf",
stats: {
    "name": "[PUT] Any (BOOKED) transfer description is updated.",
    "numberOfRequests": {
        "total": "19906",
        "ok": "19906",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "614",
        "ok": "614",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "47016",
        "ok": "47016",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "23822",
        "ok": "23822",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "9219",
        "ok": "9219",
        "ko": "-"
    },
    "percentiles1": {
        "total": "25909",
        "ok": "25909",
        "ko": "-"
    },
    "percentiles2": {
        "total": "28609",
        "ok": "28603",
        "ko": "-"
    },
    "percentiles3": {
        "total": "35273",
        "ok": "35261",
        "ko": "-"
    },
    "percentiles4": {
        "total": "43457",
        "ok": "43458",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 937,
    "percentage": 5
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 18969,
    "percentage": 95
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "16.941",
        "ok": "16.941",
        "ko": "-"
    }
}
    },"req_-put--any--book-bb16d": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
path: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
pathFormatted: "req_-put--any--book-bb16d",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
    "numberOfRequests": {
        "total": "19906",
        "ok": "19906",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "47054",
        "ok": "47054",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "23129",
        "ok": "23129",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "9720",
        "ok": "9720",
        "ko": "-"
    },
    "percentiles1": {
        "total": "25926",
        "ok": "25926",
        "ko": "-"
    },
    "percentiles2": {
        "total": "28144",
        "ok": "28144",
        "ko": "-"
    },
    "percentiles3": {
        "total": "33592",
        "ok": "33592",
        "ko": "-"
    },
    "percentiles4": {
        "total": "43122",
        "ok": "43121",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 29,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 1353,
    "percentage": 7
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 18524,
    "percentage": 93
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "16.941",
        "ok": "16.941",
        "ko": "-"
    }
}
    },"req_-put--any--book-fdf7e": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
path: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
pathFormatted: "req_-put--any--book-fdf7e",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
    "numberOfRequests": {
        "total": "19906",
        "ok": "19906",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "46900",
        "ok": "46900",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "22220",
        "ok": "22220",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "9994",
        "ok": "9994",
        "ko": "-"
    },
    "percentiles1": {
        "total": "25575",
        "ok": "25575",
        "ko": "-"
    },
    "percentiles2": {
        "total": "28066",
        "ok": "28067",
        "ko": "-"
    },
    "percentiles3": {
        "total": "32640",
        "ok": "32640",
        "ko": "-"
    },
    "percentiles4": {
        "total": "37058",
        "ok": "37066",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 243,
    "percentage": 1
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 1811,
    "percentage": 9
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 17852,
    "percentage": 90
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "16.941",
        "ok": "16.941",
        "ko": "-"
    }
}
    },"req_-get--user-is-r-f03f4": {
        type: "REQUEST",
        name: "[GET] User is retrieved with her/his transfers data.",
path: "[GET] User is retrieved with her/his transfers data.",
pathFormatted: "req_-get--user-is-r-f03f4",
stats: {
    "name": "[GET] User is retrieved with her/his transfers data.",
    "numberOfRequests": {
        "total": "19906",
        "ok": "19906",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "38542",
        "ok": "38542",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "20855",
        "ok": "20855",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "10021",
        "ok": "10021",
        "ko": "-"
    },
    "percentiles1": {
        "total": "23854",
        "ok": "23856",
        "ko": "-"
    },
    "percentiles2": {
        "total": "27065",
        "ok": "27067",
        "ko": "-"
    },
    "percentiles3": {
        "total": "31885",
        "ok": "31881",
        "ko": "-"
    },
    "percentiles4": {
        "total": "36394",
        "ok": "36394",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 761,
    "percentage": 4
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 2050,
    "percentage": 10
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 17095,
    "percentage": 86
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "16.941",
        "ok": "16.941",
        "ko": "-"
    }
}
    },"req_-put--user-upda-c8c46": {
        type: "REQUEST",
        name: "[PUT] User updates with her/his own data.",
path: "[PUT] User updates with her/his own data.",
pathFormatted: "req_-put--user-upda-c8c46",
stats: {
    "name": "[PUT] User updates with her/his own data.",
    "numberOfRequests": {
        "total": "19906",
        "ok": "19906",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "38432",
        "ok": "38432",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "20198",
        "ok": "20198",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "10256",
        "ok": "10256",
        "ko": "-"
    },
    "percentiles1": {
        "total": "24075",
        "ok": "24079",
        "ko": "-"
    },
    "percentiles2": {
        "total": "27078",
        "ok": "27078",
        "ko": "-"
    },
    "percentiles3": {
        "total": "31401",
        "ok": "31406",
        "ko": "-"
    },
    "percentiles4": {
        "total": "34988",
        "ok": "34983",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 1242,
    "percentage": 6
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 2073,
    "percentage": 10
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 16591,
    "percentage": 83
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "16.941",
        "ok": "16.941",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
