var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "488076",
        "ok": "357949",
        "ko": "130127"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "2",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "57533",
        "ok": "57533",
        "ko": "57397"
    },
    "meanResponseTime": {
        "total": "19664",
        "ok": "25578",
        "ko": "3398"
    },
    "standardDeviation": {
        "total": "13906",
        "ok": "9928",
        "ko": "9668"
    },
    "percentiles1": {
        "total": "23486",
        "ok": "24616",
        "ko": "0"
    },
    "percentiles2": {
        "total": "27211",
        "ok": "28439",
        "ko": "1"
    },
    "percentiles3": {
        "total": "41730",
        "ok": "43847",
        "ko": "27974"
    },
    "percentiles4": {
        "total": "53793",
        "ok": "54450",
        "ko": "41261"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 2085,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 12546,
    "percentage": 3
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 343318,
    "percentage": 70
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 130127,
    "percentage": 27
},
    "meanNumberOfRequestsPerSecond": {
        "total": "425.895",
        "ok": "312.346",
        "ko": "113.549"
    }
},
contents: {
"req_-get--the-list--c0b76": {
        type: "REQUEST",
        name: "[GET] The list of available countries is presented.",
path: "[GET] The list of available countries is presented.",
pathFormatted: "req_-get--the-list--c0b76",
stats: {
    "name": "[GET] The list of available countries is presented.",
    "numberOfRequests": {
        "total": "150094",
        "ok": "35646",
        "ko": "114448"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "78",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "57041",
        "ok": "57041",
        "ko": "32440"
    },
    "meanResponseTime": {
        "total": "6285",
        "ok": "26464",
        "ko": "1"
    },
    "standardDeviation": {
        "total": "12018",
        "ok": "8611",
        "ko": "96"
    },
    "percentiles1": {
        "total": "0",
        "ok": "25717",
        "ko": "0"
    },
    "percentiles2": {
        "total": "1",
        "ok": "29050",
        "ko": "0"
    },
    "percentiles3": {
        "total": "29891",
        "ok": "41231",
        "ko": "1"
    },
    "percentiles4": {
        "total": "41338",
        "ok": "50345",
        "ko": "1"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 8,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 510,
    "percentage": 0
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 35128,
    "percentage": 23
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 114448,
    "percentage": 76
},
    "meanNumberOfRequestsPerSecond": {
        "total": "130.972",
        "ok": "31.105",
        "ko": "99.867"
    }
}
    },"req_-get--the-list--3525d": {
        type: "REQUEST",
        name: "[GET] The list of available cities is presented.",
path: "[GET] The list of available cities is presented.",
pathFormatted: "req_-get--the-list--3525d",
stats: {
    "name": "[GET] The list of available cities is presented.",
    "numberOfRequests": {
        "total": "71292",
        "ok": "71292",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "641",
        "ok": "641",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "57414",
        "ok": "57414",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "29013",
        "ok": "29013",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "9685",
        "ok": "9685",
        "ko": "-"
    },
    "percentiles1": {
        "total": "25526",
        "ok": "25521",
        "ko": "-"
    },
    "percentiles2": {
        "total": "31110",
        "ok": "31070",
        "ko": "-"
    },
    "percentiles3": {
        "total": "50287",
        "ok": "50288",
        "ko": "-"
    },
    "percentiles4": {
        "total": "55328",
        "ok": "55328",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 240,
    "percentage": 0
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 71052,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "62.209",
        "ok": "62.209",
        "ko": "-"
    }
}
    },"req_-get--the-list--11d52": {
        type: "REQUEST",
        name: "[GET] The list of available origins is presented.",
path: "[GET] The list of available origins is presented.",
pathFormatted: "req_-get--the-list--11d52",
stats: {
    "name": "[GET] The list of available origins is presented.",
    "numberOfRequests": {
        "total": "35646",
        "ok": "35646",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1543",
        "ok": "1543",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "57424",
        "ok": "57424",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "29265",
        "ok": "29265",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "9412",
        "ok": "9412",
        "ko": "-"
    },
    "percentiles1": {
        "total": "25471",
        "ok": "25478",
        "ko": "-"
    },
    "percentiles2": {
        "total": "31907",
        "ok": "31883",
        "ko": "-"
    },
    "percentiles3": {
        "total": "48579",
        "ok": "48586",
        "ko": "-"
    },
    "percentiles4": {
        "total": "53985",
        "ok": "53985",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 19,
    "percentage": 0
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 35627,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "31.105",
        "ok": "31.105",
        "ko": "-"
    }
}
    },"req_-get--the-list--0dc40": {
        type: "REQUEST",
        name: "[GET] The list of available destinations is presented.",
path: "[GET] The list of available destinations is presented.",
pathFormatted: "req_-get--the-list--0dc40",
stats: {
    "name": "[GET] The list of available destinations is presented.",
    "numberOfRequests": {
        "total": "35646",
        "ok": "35646",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "7077",
        "ok": "7077",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "57424",
        "ok": "57424",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "29869",
        "ok": "29869",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "9493",
        "ok": "9493",
        "ko": "-"
    },
    "percentiles1": {
        "total": "26859",
        "ok": "26877",
        "ko": "-"
    },
    "percentiles2": {
        "total": "35739",
        "ok": "35738",
        "ko": "-"
    },
    "percentiles3": {
        "total": "51009",
        "ok": "51009",
        "ko": "-"
    },
    "percentiles4": {
        "total": "55567",
        "ok": "55567",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 35646,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "31.105",
        "ok": "31.105",
        "ko": "-"
    }
}
    },"req_-get--the-list--8bddb": {
        type: "REQUEST",
        name: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
path: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
pathFormatted: "req_-get--the-list--8bddb",
stats: {
    "name": "[GET] The list of available transfers by selected origin, destination, and date is presented.",
    "numberOfRequests": {
        "total": "35646",
        "ok": "19975",
        "ko": "15671"
    },
    "minResponseTime": {
        "total": "4018",
        "ok": "4107",
        "ko": "4018"
    },
    "maxResponseTime": {
        "total": "57397",
        "ok": "57258",
        "ko": "57397"
    },
    "meanResponseTime": {
        "total": "28160",
        "ok": "28127",
        "ko": "28202"
    },
    "standardDeviation": {
        "total": "8710",
        "ok": "8691",
        "ko": "8733"
    },
    "percentiles1": {
        "total": "27096",
        "ok": "27073",
        "ko": "27118"
    },
    "percentiles2": {
        "total": "30368",
        "ok": "30340",
        "ko": "30379"
    },
    "percentiles3": {
        "total": "46781",
        "ok": "46699",
        "ko": "46863"
    },
    "percentiles4": {
        "total": "54889",
        "ok": "54863",
        "ko": "54979"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 19975,
    "percentage": 56
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 15671,
    "percentage": 44
},
    "meanNumberOfRequestsPerSecond": {
        "total": "31.105",
        "ok": "17.43",
        "ko": "13.675"
    }
}
    },"req_-post--the-tran-5ac29": {
        type: "REQUEST",
        name: "[POST] The transfer is booked in the system.",
path: "[POST] The transfer is booked in the system.",
pathFormatted: "req_-post--the-tran-5ac29",
stats: {
    "name": "[POST] The transfer is booked in the system.",
    "numberOfRequests": {
        "total": "19975",
        "ok": "19967",
        "ko": "8"
    },
    "minResponseTime": {
        "total": "2912",
        "ok": "2912",
        "ko": "6404"
    },
    "maxResponseTime": {
        "total": "57533",
        "ok": "57533",
        "ko": "30433"
    },
    "meanResponseTime": {
        "total": "25738",
        "ok": "25739",
        "ko": "22862"
    },
    "standardDeviation": {
        "total": "8717",
        "ok": "8717",
        "ko": "7683"
    },
    "percentiles1": {
        "total": "24674",
        "ok": "24674",
        "ko": "24967"
    },
    "percentiles2": {
        "total": "28495",
        "ok": "28496",
        "ko": "28702"
    },
    "percentiles3": {
        "total": "41792",
        "ok": "41785",
        "ko": "30324"
    },
    "percentiles4": {
        "total": "54561",
        "ok": "54570",
        "ko": "30411"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 1,
    "percentage": 0
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 19966,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 8,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "17.43",
        "ok": "17.423",
        "ko": "0.007"
    }
}
    },"req_-get--the-list--4f742": {
        type: "REQUEST",
        name: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
path: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
pathFormatted: "req_-get--the-list--4f742",
stats: {
    "name": "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
    "numberOfRequests": {
        "total": "19975",
        "ok": "19975",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2437",
        "ok": "2437",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "57407",
        "ok": "57407",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "23992",
        "ok": "23992",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "8541",
        "ok": "8541",
        "ko": "-"
    },
    "percentiles1": {
        "total": "23808",
        "ok": "23807",
        "ko": "-"
    },
    "percentiles2": {
        "total": "27195",
        "ok": "27196",
        "ko": "-"
    },
    "percentiles3": {
        "total": "37925",
        "ok": "37925",
        "ko": "-"
    },
    "percentiles4": {
        "total": "52958",
        "ok": "52962",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 154,
    "percentage": 1
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 19821,
    "percentage": 99
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "17.43",
        "ok": "17.43",
        "ko": "-"
    }
}
    },"req_-get--one-of-th-c14cc": {
        type: "REQUEST",
        name: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
path: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
pathFormatted: "req_-get--one-of-th-c14cc",
stats: {
    "name": "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
    "numberOfRequests": {
        "total": "19967",
        "ok": "19967",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1602",
        "ok": "1602",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "57185",
        "ok": "57185",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "22693",
        "ok": "22693",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "8518",
        "ok": "8518",
        "ko": "-"
    },
    "percentiles1": {
        "total": "23841",
        "ok": "23841",
        "ko": "-"
    },
    "percentiles2": {
        "total": "26014",
        "ok": "26010",
        "ko": "-"
    },
    "percentiles3": {
        "total": "33808",
        "ok": "33754",
        "ko": "-"
    },
    "percentiles4": {
        "total": "49952",
        "ok": "49945",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 648,
    "percentage": 3
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 19319,
    "percentage": 97
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "17.423",
        "ok": "17.423",
        "ko": "-"
    }
}
    },"req_-put--any--book-143cf": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer description is updated.",
path: "[PUT] Any (BOOKED) transfer description is updated.",
pathFormatted: "req_-put--any--book-143cf",
stats: {
    "name": "[PUT] Any (BOOKED) transfer description is updated.",
    "numberOfRequests": {
        "total": "19967",
        "ok": "19967",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "970",
        "ok": "970",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "57209",
        "ok": "57209",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "21501",
        "ok": "21501",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "8662",
        "ok": "8662",
        "ko": "-"
    },
    "percentiles1": {
        "total": "23591",
        "ok": "23592",
        "ko": "-"
    },
    "percentiles2": {
        "total": "25529",
        "ok": "25529",
        "ko": "-"
    },
    "percentiles3": {
        "total": "29156",
        "ok": "29150",
        "ko": "-"
    },
    "percentiles4": {
        "total": "41576",
        "ok": "41556",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 1330,
    "percentage": 7
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 18637,
    "percentage": 93
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "17.423",
        "ok": "17.423",
        "ko": "-"
    }
}
    },"req_-put--any--book-bb16d": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
path: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
pathFormatted: "req_-put--any--book-bb16d",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
    "numberOfRequests": {
        "total": "19967",
        "ok": "19967",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "54059",
        "ok": "54059",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "21085",
        "ok": "21085",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "8952",
        "ok": "8952",
        "ko": "-"
    },
    "percentiles1": {
        "total": "23656",
        "ok": "23659",
        "ko": "-"
    },
    "percentiles2": {
        "total": "25596",
        "ok": "25596",
        "ko": "-"
    },
    "percentiles3": {
        "total": "30225",
        "ok": "30226",
        "ko": "-"
    },
    "percentiles4": {
        "total": "35690",
        "ok": "35689",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 18,
    "percentage": 0
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 1991,
    "percentage": 10
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 17958,
    "percentage": 90
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "17.423",
        "ok": "17.423",
        "ko": "-"
    }
}
    },"req_-put--any--book-fdf7e": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
path: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
pathFormatted: "req_-put--any--book-fdf7e",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
    "numberOfRequests": {
        "total": "19967",
        "ok": "19967",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "37805",
        "ok": "37805",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "20302",
        "ok": "20302",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "9154",
        "ok": "9154",
        "ko": "-"
    },
    "percentiles1": {
        "total": "23294",
        "ok": "23296",
        "ko": "-"
    },
    "percentiles2": {
        "total": "25395",
        "ok": "25394",
        "ko": "-"
    },
    "percentiles3": {
        "total": "30079",
        "ok": "30079",
        "ko": "-"
    },
    "percentiles4": {
        "total": "32144",
        "ok": "32144",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 194,
    "percentage": 1
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 2535,
    "percentage": 13
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 17238,
    "percentage": 86
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "17.423",
        "ok": "17.423",
        "ko": "-"
    }
}
    },"req_-get--user-is-r-f03f4": {
        type: "REQUEST",
        name: "[GET] User is retrieved with her/his transfers data.",
path: "[GET] User is retrieved with her/his transfers data.",
pathFormatted: "req_-get--user-is-r-f03f4",
stats: {
    "name": "[GET] User is retrieved with her/his transfers data.",
    "numberOfRequests": {
        "total": "19967",
        "ok": "19967",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "33747",
        "ok": "33747",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "19474",
        "ok": "19474",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "9323",
        "ok": "9323",
        "ko": "-"
    },
    "percentiles1": {
        "total": "22987",
        "ok": "22983",
        "ko": "-"
    },
    "percentiles2": {
        "total": "24679",
        "ok": "24680",
        "ko": "-"
    },
    "percentiles3": {
        "total": "29547",
        "ok": "29545",
        "ko": "-"
    },
    "percentiles4": {
        "total": "31003",
        "ok": "31003",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 655,
    "percentage": 3
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 2621,
    "percentage": 13
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 16691,
    "percentage": 84
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "17.423",
        "ok": "17.423",
        "ko": "-"
    }
}
    },"req_-put--user-upda-c8c46": {
        type: "REQUEST",
        name: "[PUT] User updates with her/his own data.",
path: "[PUT] User updates with her/his own data.",
pathFormatted: "req_-put--user-upda-c8c46",
stats: {
    "name": "[PUT] User updates with her/his own data.",
    "numberOfRequests": {
        "total": "19967",
        "ok": "19967",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "32570",
        "ok": "32570",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "19195",
        "ok": "19195",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "9849",
        "ok": "9849",
        "ko": "-"
    },
    "percentiles1": {
        "total": "23159",
        "ok": "23159",
        "ko": "-"
    },
    "percentiles2": {
        "total": "25832",
        "ok": "25831",
        "ko": "-"
    },
    "percentiles3": {
        "total": "29051",
        "ok": "29050",
        "ko": "-"
    },
    "percentiles4": {
        "total": "30288",
        "ok": "30288",
        "ko": "-"
    },
    "group1": {
    "name": "t < 300 ms",
    "htmlName": "t < 300 ms",
    "count": 1210,
    "percentage": 6
},
    "group2": {
    "name": "300 ms <= t < 3000 ms",
    "htmlName": "t >= 300 ms <br> t < 3000 ms",
    "count": 2497,
    "percentage": 13
},
    "group3": {
    "name": "t >= 3000 ms",
    "htmlName": "t >= 3000 ms",
    "count": 16260,
    "percentage": 81
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "17.423",
        "ok": "17.423",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
