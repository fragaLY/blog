var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "430673",
        "ok": "289692",
        "ko": "140981"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "3",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "60224",
        "ok": "58903",
        "ko": "60224"
    },
    "meanResponseTime": {
        "total": "21877",
        "ok": "28467",
        "ko": "8336"
    },
    "standardDeviation": {
        "total": "17689",
        "ok": "12491",
        "ko": "19045"
    },
    "percentiles1": {
        "total": "24498",
        "ok": "27822",
        "ko": "0"
    },
    "percentiles2": {
        "total": "35342",
        "ok": "36698",
        "ko": "1"
    },
    "percentiles3": {
        "total": "50977",
        "ok": "50044",
        "ko": "60001"
    },
    "percentiles4": {
        "total": "60001",
        "ok": "51777",
        "ko": "60003"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 7295,
    "percentage": 2
},
    "group2": {
    "name": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 605,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "count": 281792,
    "percentage": 65
},
    "group4": {
    "name": "failed",
    "count": 140981,
    "percentage": 33
},
    "meanNumberOfRequestsPerSecond": {
        "total": "381.127",
        "ok": "256.365",
        "ko": "124.762"
    }
},
contents: {
"req_-get--the-list--c0b76": {
        type: "REQUEST",
        name: "[GET] The list of available countries is presented.",
path: "[GET] The list of available countries is presented.",
pathFormatted: "req_-get--the-list--c0b76",
stats: {
    "name": "[GET] The list of available countries is presented.",
    "numberOfRequests": {
        "total": "150214",
        "ok": "34393",
        "ko": "115821"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "3",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "60187",
        "ok": "57847",
        "ko": "60187"
    },
    "meanResponseTime": {
        "total": "6329",
        "ok": "25403",
        "ko": "665"
    },
    "standardDeviation": {
        "total": "13449",
        "ok": "13614",
        "ko": "6281"
    },
    "percentiles1": {
        "total": "0",
        "ok": "26326",
        "ko": "0"
    },
    "percentiles2": {
        "total": "1",
        "ok": "35638",
        "ko": "0"
    },
    "percentiles3": {
        "total": "38847",
        "ok": "46893",
        "ko": "1"
    },
    "percentiles4": {
        "total": "52105",
        "ok": "51671",
        "ko": "60000"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1869,
    "percentage": 1
},
    "group2": {
    "name": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 100,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "count": 32424,
    "percentage": 22
},
    "group4": {
    "name": "failed",
    "count": 115821,
    "percentage": 77
},
    "meanNumberOfRequestsPerSecond": {
        "total": "132.933",
        "ok": "30.436",
        "ko": "102.496"
    }
}
    },"req_-get--the-list--3525d": {
        type: "REQUEST",
        name: "[GET] The list of available cities is presented.",
path: "[GET] The list of available cities is presented.",
pathFormatted: "req_-get--the-list--3525d",
stats: {
    "name": "[GET] The list of available cities is presented.",
    "numberOfRequests": {
        "total": "66958",
        "ok": "63865",
        "ko": "3093"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "3",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "60224",
        "ok": "57826",
        "ko": "60224"
    },
    "meanResponseTime": {
        "total": "28346",
        "ok": "26877",
        "ko": "58683"
    },
    "standardDeviation": {
        "total": "14143",
        "ok": "12620",
        "ko": "8769"
    },
    "percentiles1": {
        "total": "27370",
        "ok": "26670",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "36746",
        "ok": "35877",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "51999",
        "ok": "47292",
        "ko": "60054"
    },
    "percentiles4": {
        "total": "60002",
        "ok": "51538",
        "ko": "60138"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2696,
    "percentage": 4
},
    "group2": {
    "name": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 162,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "count": 61007,
    "percentage": 91
},
    "group4": {
    "name": "failed",
    "count": 3093,
    "percentage": 5
},
    "meanNumberOfRequestsPerSecond": {
        "total": "59.255",
        "ok": "56.518",
        "ko": "2.737"
    }
}
    },"req_-get--the-list--11d52": {
        type: "REQUEST",
        name: "[GET] The list of available origins is presented.",
path: "[GET] The list of available origins is presented.",
pathFormatted: "req_-get--the-list--11d52",
stats: {
    "name": "[GET] The list of available origins is presented.",
    "numberOfRequests": {
        "total": "32565",
        "ok": "31744",
        "ko": "821"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60207",
        "ok": "57499",
        "ko": "60207"
    },
    "meanResponseTime": {
        "total": "27607",
        "ok": "26769",
        "ko": "60006"
    },
    "standardDeviation": {
        "total": "13566",
        "ok": "12686",
        "ko": "24"
    },
    "percentiles1": {
        "total": "26643",
        "ok": "26335",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "36405",
        "ok": "35795",
        "ko": "60002"
    },
    "percentiles3": {
        "total": "50890",
        "ok": "47398",
        "ko": "60028"
    },
    "percentiles4": {
        "total": "60001",
        "ok": "51228",
        "ko": "60131"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1434,
    "percentage": 4
},
    "group2": {
    "name": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 75,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "count": 30235,
    "percentage": 93
},
    "group4": {
    "name": "failed",
    "count": 821,
    "percentage": 3
},
    "meanNumberOfRequestsPerSecond": {
        "total": "28.819",
        "ok": "28.092",
        "ko": "0.727"
    }
}
    },"req_-get--the-list--0dc40": {
        type: "REQUEST",
        name: "[GET] The list of available destinations is presented.",
path: "[GET] The list of available destinations is presented.",
pathFormatted: "req_-get--the-list--0dc40",
stats: {
    "name": "[GET] The list of available destinations is presented.",
    "numberOfRequests": {
        "total": "30548",
        "ok": "29808",
        "ko": "740"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60148",
        "ok": "53491",
        "ko": "60148"
    },
    "meanResponseTime": {
        "total": "28683",
        "ok": "27905",
        "ko": "60007"
    },
    "standardDeviation": {
        "total": "12813",
        "ok": "11970",
        "ko": "23"
    },
    "percentiles1": {
        "total": "26603",
        "ok": "26498",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "36518",
        "ok": "36091",
        "ko": "60002"
    },
    "percentiles3": {
        "total": "50995",
        "ok": "50017",
        "ko": "60057"
    },
    "percentiles4": {
        "total": "60001",
        "ok": "51889",
        "ko": "60122"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 817,
    "percentage": 3
},
    "group2": {
    "name": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 85,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "count": 28906,
    "percentage": 95
},
    "group4": {
    "name": "failed",
    "count": 740,
    "percentage": 2
},
    "meanNumberOfRequestsPerSecond": {
        "total": "27.034",
        "ok": "26.379",
        "ko": "0.655"
    }
}
    },"req_-get--the-list--8bddb": {
        type: "REQUEST",
        name: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
path: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
pathFormatted: "req_-get--the-list--8bddb",
stats: {
    "name": "[GET] The list of available transfers by selected origin, destination, and date is presented.",
    "numberOfRequests": {
        "total": "29808",
        "ok": "15998",
        "ko": "13810"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "7",
        "ko": "3"
    },
    "maxResponseTime": {
        "total": "60193",
        "ok": "56569",
        "ko": "60193"
    },
    "meanResponseTime": {
        "total": "30324",
        "ok": "28949",
        "ko": "31917"
    },
    "standardDeviation": {
        "total": "12905",
        "ok": "11448",
        "ko": "14244"
    },
    "percentiles1": {
        "total": "28047",
        "ok": "27599",
        "ko": "28625"
    },
    "percentiles2": {
        "total": "38012",
        "ok": "36680",
        "ko": "42425"
    },
    "percentiles3": {
        "total": "52202",
        "ok": "49876",
        "ko": "60001"
    },
    "percentiles4": {
        "total": "60002",
        "ok": "51758",
        "ko": "60003"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 242,
    "percentage": 1
},
    "group2": {
    "name": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 45,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "count": 15711,
    "percentage": 53
},
    "group4": {
    "name": "failed",
    "count": 13810,
    "percentage": 46
},
    "meanNumberOfRequestsPerSecond": {
        "total": "26.379",
        "ok": "14.158",
        "ko": "12.221"
    }
}
    },"req_-post--the-tran-5ac29": {
        type: "REQUEST",
        name: "[POST] The transfer is booked in the system.",
path: "[POST] The transfer is booked in the system.",
pathFormatted: "req_-post--the-tran-5ac29",
stats: {
    "name": "[POST] The transfer is booked in the system.",
    "numberOfRequests": {
        "total": "15998",
        "ok": "15324",
        "ko": "674"
    },
    "minResponseTime": {
        "total": "12",
        "ok": "12",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60222",
        "ok": "56316",
        "ko": "60222"
    },
    "meanResponseTime": {
        "total": "31140",
        "ok": "29870",
        "ko": "60008"
    },
    "standardDeviation": {
        "total": "12462",
        "ok": "11129",
        "ko": "27"
    },
    "percentiles1": {
        "total": "28512",
        "ok": "28218",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "38295",
        "ok": "36560",
        "ko": "60002"
    },
    "percentiles3": {
        "total": "51769",
        "ok": "50094",
        "ko": "60066"
    },
    "percentiles4": {
        "total": "60002",
        "ok": "51698",
        "ko": "60155"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 29,
    "percentage": 0
},
    "group2": {
    "name": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 37,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "count": 15258,
    "percentage": 95
},
    "group4": {
    "name": "failed",
    "count": 674,
    "percentage": 4
},
    "meanNumberOfRequestsPerSecond": {
        "total": "14.158",
        "ok": "13.561",
        "ko": "0.596"
    }
}
    },"req_-get--the-list--4f742": {
        type: "REQUEST",
        name: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
path: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
pathFormatted: "req_-get--the-list--4f742",
stats: {
    "name": "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
    "numberOfRequests": {
        "total": "15998",
        "ok": "15413",
        "ko": "585"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "8",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "60179",
        "ok": "58903",
        "ko": "60179"
    },
    "meanResponseTime": {
        "total": "31002",
        "ok": "29997",
        "ko": "57462"
    },
    "standardDeviation": {
        "total": "11716",
        "ok": "10458",
        "ko": "12047"
    },
    "percentiles1": {
        "total": "28431",
        "ok": "28169",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "37132",
        "ok": "36605",
        "ko": "60002"
    },
    "percentiles3": {
        "total": "51150",
        "ok": "47294",
        "ko": "60049"
    },
    "percentiles4": {
        "total": "60001",
        "ok": "51278",
        "ko": "60143"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 6,
    "percentage": 0
},
    "group2": {
    "name": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 2,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "count": 15405,
    "percentage": 96
},
    "group4": {
    "name": "failed",
    "count": 585,
    "percentage": 4
},
    "meanNumberOfRequestsPerSecond": {
        "total": "14.158",
        "ok": "13.64",
        "ko": "0.518"
    }
}
    },"req_-get--one-of-th-c14cc": {
        type: "REQUEST",
        name: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
path: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
pathFormatted: "req_-get--one-of-th-c14cc",
stats: {
    "name": "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
    "numberOfRequests": {
        "total": "14764",
        "ok": "14199",
        "ko": "565"
    },
    "minResponseTime": {
        "total": "16",
        "ok": "16",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60168",
        "ok": "53444",
        "ko": "60168"
    },
    "meanResponseTime": {
        "total": "32570",
        "ok": "31478",
        "ko": "60005"
    },
    "standardDeviation": {
        "total": "11965",
        "ok": "10850",
        "ko": "19"
    },
    "percentiles1": {
        "total": "29050",
        "ok": "28913",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "43546",
        "ok": "42583",
        "ko": "60002"
    },
    "percentiles3": {
        "total": "51601",
        "ok": "50633",
        "ko": "60032"
    },
    "percentiles4": {
        "total": "60002",
        "ok": "51676",
        "ko": "60112"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 5,
    "percentage": 0
},
    "group2": {
    "name": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "count": 14194,
    "percentage": 96
},
    "group4": {
    "name": "failed",
    "count": 565,
    "percentage": 4
},
    "meanNumberOfRequestsPerSecond": {
        "total": "13.065",
        "ok": "12.565",
        "ko": "0.5"
    }
}
    },"req_-put--any--book-143cf": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer description is updated.",
path: "[PUT] Any (BOOKED) transfer description is updated.",
pathFormatted: "req_-put--any--book-143cf",
stats: {
    "name": "[PUT] Any (BOOKED) transfer description is updated.",
    "numberOfRequests": {
        "total": "14764",
        "ok": "13634",
        "ko": "1130"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "18",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "60179",
        "ok": "57860",
        "ko": "60179"
    },
    "meanResponseTime": {
        "total": "34461",
        "ok": "32448",
        "ko": "58753"
    },
    "standardDeviation": {
        "total": "12866",
        "ok": "10968",
        "ko": "8520"
    },
    "percentiles1": {
        "total": "30213",
        "ok": "29421",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "44776",
        "ok": "43565",
        "ko": "60002"
    },
    "percentiles3": {
        "total": "60001",
        "ok": "50443",
        "ko": "60059"
    },
    "percentiles4": {
        "total": "60002",
        "ok": "51693",
        "ko": "60149"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 5,
    "percentage": 0
},
    "group2": {
    "name": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "count": 13629,
    "percentage": 92
},
    "group4": {
    "name": "failed",
    "count": 1130,
    "percentage": 8
},
    "meanNumberOfRequestsPerSecond": {
        "total": "13.065",
        "ok": "12.065",
        "ko": "1"
    }
}
    },"req_-put--any--book-bb16d": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
path: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
pathFormatted: "req_-put--any--book-bb16d",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
    "numberOfRequests": {
        "total": "14764",
        "ok": "13965",
        "ko": "799"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "31",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "60185",
        "ok": "57876",
        "ko": "60185"
    },
    "meanResponseTime": {
        "total": "33239",
        "ok": "31959",
        "ko": "55603"
    },
    "standardDeviation": {
        "total": "12732",
        "ok": "11278",
        "ko": "15596"
    },
    "percentiles1": {
        "total": "29791",
        "ok": "29330",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "43300",
        "ok": "40272",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "57386",
        "ok": "50995",
        "ko": "60017"
    },
    "percentiles4": {
        "total": "60002",
        "ok": "52439",
        "ko": "60129"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 5,
    "percentage": 0
},
    "group2": {
    "name": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "count": 13960,
    "percentage": 95
},
    "group4": {
    "name": "failed",
    "count": 799,
    "percentage": 5
},
    "meanNumberOfRequestsPerSecond": {
        "total": "13.065",
        "ok": "12.358",
        "ko": "0.707"
    }
}
    },"req_-put--any--book-fdf7e": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
path: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
pathFormatted: "req_-put--any--book-fdf7e",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
    "numberOfRequests": {
        "total": "14764",
        "ok": "13670",
        "ko": "1094"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "15",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "60209",
        "ok": "52989",
        "ko": "60209"
    },
    "meanResponseTime": {
        "total": "33508",
        "ok": "31666",
        "ko": "56522"
    },
    "standardDeviation": {
        "total": "14357",
        "ok": "12695",
        "ko": "13989"
    },
    "percentiles1": {
        "total": "30359",
        "ok": "29413",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "44592",
        "ok": "42396",
        "ko": "60002"
    },
    "percentiles3": {
        "total": "60001",
        "ok": "50989",
        "ko": "60065"
    },
    "percentiles4": {
        "total": "60002",
        "ok": "52452",
        "ko": "60140"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 6,
    "percentage": 0
},
    "group2": {
    "name": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 1,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "count": 13663,
    "percentage": 93
},
    "group4": {
    "name": "failed",
    "count": 1094,
    "percentage": 7
},
    "meanNumberOfRequestsPerSecond": {
        "total": "13.065",
        "ok": "12.097",
        "ko": "0.968"
    }
}
    },"req_-get--user-is-r-f03f4": {
        type: "REQUEST",
        name: "[GET] User is retrieved with her/his transfers data.",
path: "[GET] User is retrieved with her/his transfers data.",
pathFormatted: "req_-get--user-is-r-f03f4",
stats: {
    "name": "[GET] User is retrieved with her/his transfers data.",
    "numberOfRequests": {
        "total": "14764",
        "ok": "13839",
        "ko": "925"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "8",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "60186",
        "ok": "58534",
        "ko": "60186"
    },
    "meanResponseTime": {
        "total": "31804",
        "ok": "30262",
        "ko": "54863"
    },
    "standardDeviation": {
        "total": "14398",
        "ok": "12827",
        "ko": "16720"
    },
    "percentiles1": {
        "total": "29736",
        "ok": "29244",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "42431",
        "ok": "38132",
        "ko": "60002"
    },
    "percentiles3": {
        "total": "60000",
        "ok": "50888",
        "ko": "60052"
    },
    "percentiles4": {
        "total": "60002",
        "ok": "52227",
        "ko": "60130"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 7,
    "percentage": 0
},
    "group2": {
    "name": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 2,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "count": 13830,
    "percentage": 94
},
    "group4": {
    "name": "failed",
    "count": 925,
    "percentage": 6
},
    "meanNumberOfRequestsPerSecond": {
        "total": "13.065",
        "ok": "12.247",
        "ko": "0.819"
    }
}
    },"req_-put--user-upda-c8c46": {
        type: "REQUEST",
        name: "[PUT] User updates with her/his own data.",
path: "[PUT] User updates with her/his own data.",
pathFormatted: "req_-put--user-upda-c8c46",
stats: {
    "name": "[PUT] User updates with her/his own data.",
    "numberOfRequests": {
        "total": "14764",
        "ok": "13840",
        "ko": "924"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "7",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "60220",
        "ok": "53335",
        "ko": "60220"
    },
    "meanResponseTime": {
        "total": "30841",
        "ok": "29222",
        "ko": "55097"
    },
    "standardDeviation": {
        "total": "15376",
        "ok": "13869",
        "ko": "16399"
    },
    "percentiles1": {
        "total": "30162",
        "ok": "29476",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "42389",
        "ok": "37246",
        "ko": "60002"
    },
    "percentiles3": {
        "total": "60000",
        "ok": "50105",
        "ko": "60015"
    },
    "percentiles4": {
        "total": "60002",
        "ok": "52220",
        "ko": "60130"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 174,
    "percentage": 1
},
    "group2": {
    "name": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 96,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "count": 13570,
    "percentage": 92
},
    "group4": {
    "name": "failed",
    "count": 924,
    "percentage": 6
},
    "meanNumberOfRequestsPerSecond": {
        "total": "13.065",
        "ok": "12.248",
        "ko": "0.818"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
