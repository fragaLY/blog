var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "480736",
        "ok": "342782",
        "ko": "137954"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "2",
        "ko": "1"
    },
    "maxResponseTime": {
        "total": "60224",
        "ok": "59819",
        "ko": "60224"
    },
    "meanResponseTime": {
        "total": "15103",
        "ok": "18506",
        "ko": "6649"
    },
    "standardDeviation": {
        "total": "11790",
        "ok": "8536",
        "ko": "14252"
    },
    "percentiles1": {
        "total": "15592",
        "ok": "17505",
        "ko": "2003"
    },
    "percentiles2": {
        "total": "21968",
        "ok": "23748",
        "ko": "2007"
    },
    "percentiles3": {
        "total": "32175",
        "ok": "30843",
        "ko": "60000"
    },
    "percentiles4": {
        "total": "60001",
        "ok": "41592",
        "ko": "60002"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 12336,
    "percentage": 3
},
    "group2": {
    "name": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 1421,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "count": 329025,
    "percentage": 68
},
    "group4": {
    "name": "failed",
    "count": 137954,
    "percentage": 29
},
    "meanNumberOfRequestsPerSecond": {
        "total": "414.785",
        "ok": "295.757",
        "ko": "119.028"
    }
},
contents: {
"req_-get--the-list--c0b76": {
        type: "REQUEST",
        name: "[GET] The list of available countries is presented.",
path: "[GET] The list of available countries is presented.",
pathFormatted: "req_-get--the-list--c0b76",
stats: {
    "name": "[GET] The list of available countries is presented.",
    "numberOfRequests": {
        "total": "150618",
        "ok": "37164",
        "ko": "113454"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "2"
    },
    "maxResponseTime": {
        "total": "60148",
        "ok": "59819",
        "ko": "60148"
    },
    "meanResponseTime": {
        "total": "6789",
        "ok": "21472",
        "ko": "1980"
    },
    "standardDeviation": {
        "total": "10619",
        "ok": "10659",
        "ko": "4327"
    },
    "percentiles1": {
        "total": "2004",
        "ok": "21568",
        "ko": "2003"
    },
    "percentiles2": {
        "total": "2055",
        "ok": "28025",
        "ko": "2005"
    },
    "percentiles3": {
        "total": "29997",
        "ok": "40207",
        "ko": "2025"
    },
    "percentiles4": {
        "total": "42535",
        "ok": "45560",
        "ko": "2209"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2581,
    "percentage": 2
},
    "group2": {
    "name": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 190,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "count": 34393,
    "percentage": 23
},
    "group4": {
    "name": "failed",
    "count": 113454,
    "percentage": 75
},
    "meanNumberOfRequestsPerSecond": {
        "total": "129.955",
        "ok": "32.066",
        "ko": "97.89"
    }
}
    },"req_-get--the-list--3525d": {
        type: "REQUEST",
        name: "[GET] The list of available cities is presented.",
path: "[GET] The list of available cities is presented.",
pathFormatted: "req_-get--the-list--3525d",
stats: {
    "name": "[GET] The list of available cities is presented.",
    "numberOfRequests": {
        "total": "74030",
        "ok": "73067",
        "ko": "963"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "4"
    },
    "maxResponseTime": {
        "total": "60183",
        "ok": "49037",
        "ko": "60183"
    },
    "meanResponseTime": {
        "total": "17735",
        "ok": "17252",
        "ko": "54359"
    },
    "standardDeviation": {
        "total": "9264",
        "ok": "8066",
        "ko": "17374"
    },
    "percentiles1": {
        "total": "16766",
        "ok": "16749",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "22025",
        "ok": "21851",
        "ko": "60002"
    },
    "percentiles3": {
        "total": "31316",
        "ok": "29855",
        "ko": "60004"
    },
    "percentiles4": {
        "total": "60000",
        "ok": "35365",
        "ko": "60090"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 4086,
    "percentage": 6
},
    "group2": {
    "name": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 312,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "count": 68669,
    "percentage": 93
},
    "group4": {
    "name": "failed",
    "count": 963,
    "percentage": 1
},
    "meanNumberOfRequestsPerSecond": {
        "total": "63.874",
        "ok": "63.043",
        "ko": "0.831"
    }
}
    },"req_-get--the-list--11d52": {
        type: "REQUEST",
        name: "[GET] The list of available origins is presented.",
path: "[GET] The list of available origins is presented.",
pathFormatted: "req_-get--the-list--11d52",
stats: {
    "name": "[GET] The list of available origins is presented.",
    "numberOfRequests": {
        "total": "36866",
        "ok": "36564",
        "ko": "302"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60180",
        "ok": "49649",
        "ko": "60180"
    },
    "meanResponseTime": {
        "total": "16869",
        "ok": "16513",
        "ko": "60006"
    },
    "standardDeviation": {
        "total": "8390",
        "ok": "7448",
        "ko": "21"
    },
    "percentiles1": {
        "total": "16491",
        "ok": "16449",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "19870",
        "ok": "19695",
        "ko": "60002"
    },
    "percentiles3": {
        "total": "29472",
        "ok": "29396",
        "ko": "60038"
    },
    "percentiles4": {
        "total": "41527",
        "ok": "31448",
        "ko": "60111"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2128,
    "percentage": 6
},
    "group2": {
    "name": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 135,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "count": 34301,
    "percentage": 93
},
    "group4": {
    "name": "failed",
    "count": 302,
    "percentage": 1
},
    "meanNumberOfRequestsPerSecond": {
        "total": "31.808",
        "ok": "31.548",
        "ko": "0.261"
    }
}
    },"req_-get--the-list--0dc40": {
        type: "REQUEST",
        name: "[GET] The list of available destinations is presented.",
path: "[GET] The list of available destinations is presented.",
pathFormatted: "req_-get--the-list--0dc40",
stats: {
    "name": "[GET] The list of available destinations is presented.",
    "numberOfRequests": {
        "total": "35991",
        "ok": "34683",
        "ko": "1308"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60223",
        "ok": "49218",
        "ko": "60223"
    },
    "meanResponseTime": {
        "total": "19459",
        "ok": "17930",
        "ko": "60007"
    },
    "standardDeviation": {
        "total": "12442",
        "ok": "9813",
        "ko": "23"
    },
    "percentiles1": {
        "total": "17006",
        "ok": "16772",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "24144",
        "ok": "22702",
        "ko": "60002"
    },
    "percentiles3": {
        "total": "42227",
        "ok": "39810",
        "ko": "60041"
    },
    "percentiles4": {
        "total": "60002",
        "ok": "42430",
        "ko": "60133"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1509,
    "percentage": 4
},
    "group2": {
    "name": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 158,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "count": 33016,
    "percentage": 92
},
    "group4": {
    "name": "failed",
    "count": 1308,
    "percentage": 4
},
    "meanNumberOfRequestsPerSecond": {
        "total": "31.053",
        "ok": "29.925",
        "ko": "1.129"
    }
}
    },"req_-get--the-list--8bddb": {
        type: "REQUEST",
        name: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
path: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
pathFormatted: "req_-get--the-list--8bddb",
stats: {
    "name": "[GET] The list of available transfers by selected origin, destination, and date is presented.",
    "numberOfRequests": {
        "total": "34683",
        "ok": "18972",
        "ko": "15711"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "4",
        "ko": "3"
    },
    "maxResponseTime": {
        "total": "60180",
        "ok": "49039",
        "ko": "60180"
    },
    "meanResponseTime": {
        "total": "18108",
        "ok": "17205",
        "ko": "19199"
    },
    "standardDeviation": {
        "total": "10657",
        "ok": "8813",
        "ko": "12440"
    },
    "percentiles1": {
        "total": "16300",
        "ok": "16209",
        "ko": "16422"
    },
    "percentiles2": {
        "total": "22079",
        "ok": "21595",
        "ko": "22918"
    },
    "percentiles3": {
        "total": "37793",
        "ok": "35331",
        "ko": "42432"
    },
    "percentiles4": {
        "total": "60001",
        "ok": "41922",
        "ko": "60002"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 601,
    "percentage": 2
},
    "group2": {
    "name": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 104,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "count": 18267,
    "percentage": 53
},
    "group4": {
    "name": "failed",
    "count": 15711,
    "percentage": 45
},
    "meanNumberOfRequestsPerSecond": {
        "total": "29.925",
        "ok": "16.369",
        "ko": "13.556"
    }
}
    },"req_-post--the-tran-5ac29": {
        type: "REQUEST",
        name: "[POST] The transfer is booked in the system.",
path: "[POST] The transfer is booked in the system.",
pathFormatted: "req_-post--the-tran-5ac29",
stats: {
    "name": "[POST] The transfer is booked in the system.",
    "numberOfRequests": {
        "total": "18972",
        "ok": "18681",
        "ko": "291"
    },
    "minResponseTime": {
        "total": "14",
        "ok": "14",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60143",
        "ok": "46887",
        "ko": "60143"
    },
    "meanResponseTime": {
        "total": "18428",
        "ok": "17781",
        "ko": "60007"
    },
    "standardDeviation": {
        "total": "8436",
        "ok": "6703",
        "ko": "22"
    },
    "percentiles1": {
        "total": "17045",
        "ok": "17012",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "21386",
        "ok": "21046",
        "ko": "60002"
    },
    "percentiles3": {
        "total": "29596",
        "ok": "29237",
        "ko": "60047"
    },
    "percentiles4": {
        "total": "60001",
        "ok": "41234",
        "ko": "60122"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 355,
    "percentage": 2
},
    "group2": {
    "name": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 96,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "count": 18230,
    "percentage": 96
},
    "group4": {
    "name": "failed",
    "count": 291,
    "percentage": 2
},
    "meanNumberOfRequestsPerSecond": {
        "total": "16.369",
        "ok": "16.118",
        "ko": "0.251"
    }
}
    },"req_-get--the-list--4f742": {
        type: "REQUEST",
        name: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
path: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
pathFormatted: "req_-get--the-list--4f742",
stats: {
    "name": "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
    "numberOfRequests": {
        "total": "18972",
        "ok": "18619",
        "ko": "353"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "7",
        "ko": "3"
    },
    "maxResponseTime": {
        "total": "60171",
        "ok": "43438",
        "ko": "60171"
    },
    "meanResponseTime": {
        "total": "19675",
        "ok": "19246",
        "ko": "42320"
    },
    "standardDeviation": {
        "total": "8597",
        "ok": "7182",
        "ko": "27002"
    },
    "percentiles1": {
        "total": "18074",
        "ok": "17991",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "23950",
        "ok": "23824",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "29561",
        "ok": "29392",
        "ko": "60004"
    },
    "percentiles4": {
        "total": "60001",
        "ok": "41358",
        "ko": "60104"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 244,
    "percentage": 1
},
    "group2": {
    "name": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 98,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "count": 18277,
    "percentage": 96
},
    "group4": {
    "name": "failed",
    "count": 353,
    "percentage": 2
},
    "meanNumberOfRequestsPerSecond": {
        "total": "16.369",
        "ok": "16.065",
        "ko": "0.305"
    }
}
    },"req_-get--one-of-th-c14cc": {
        type: "REQUEST",
        name: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
path: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
pathFormatted: "req_-get--one-of-th-c14cc",
stats: {
    "name": "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
    "numberOfRequests": {
        "total": "18434",
        "ok": "18230",
        "ko": "204"
    },
    "minResponseTime": {
        "total": "8",
        "ok": "8",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60135",
        "ok": "42529",
        "ko": "60135"
    },
    "meanResponseTime": {
        "total": "18965",
        "ok": "18506",
        "ko": "60004"
    },
    "standardDeviation": {
        "total": "8597",
        "ok": "7462",
        "ko": "16"
    },
    "percentiles1": {
        "total": "16976",
        "ok": "16918",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "24415",
        "ok": "23547",
        "ko": "60002"
    },
    "percentiles3": {
        "total": "29757",
        "ok": "29709",
        "ko": "60011"
    },
    "percentiles4": {
        "total": "60000",
        "ok": "37745",
        "ko": "60089"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 142,
    "percentage": 1
},
    "group2": {
    "name": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 73,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "count": 18015,
    "percentage": 98
},
    "group4": {
    "name": "failed",
    "count": 204,
    "percentage": 1
},
    "meanNumberOfRequestsPerSecond": {
        "total": "15.905",
        "ok": "15.729",
        "ko": "0.176"
    }
}
    },"req_-put--any--book-143cf": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer description is updated.",
path: "[PUT] Any (BOOKED) transfer description is updated.",
pathFormatted: "req_-put--any--book-143cf",
stats: {
    "name": "[PUT] Any (BOOKED) transfer description is updated.",
    "numberOfRequests": {
        "total": "18434",
        "ok": "18191",
        "ko": "243"
    },
    "minResponseTime": {
        "total": "4",
        "ok": "137",
        "ko": "4"
    },
    "maxResponseTime": {
        "total": "60193",
        "ok": "43439",
        "ko": "60193"
    },
    "meanResponseTime": {
        "total": "20345",
        "ok": "20029",
        "ko": "43956"
    },
    "standardDeviation": {
        "total": "8408",
        "ok": "7406",
        "ko": "26294"
    },
    "percentiles1": {
        "total": "19860",
        "ok": "19773",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "27159",
        "ok": "26877",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "29682",
        "ok": "29592",
        "ko": "60061"
    },
    "percentiles4": {
        "total": "43133",
        "ok": "37213",
        "ko": "60135"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 34,
    "percentage": 0
},
    "group2": {
    "name": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 48,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "count": 18109,
    "percentage": 98
},
    "group4": {
    "name": "failed",
    "count": 243,
    "percentage": 1
},
    "meanNumberOfRequestsPerSecond": {
        "total": "15.905",
        "ok": "15.695",
        "ko": "0.21"
    }
}
    },"req_-put--any--book-bb16d": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
path: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
pathFormatted: "req_-put--any--book-bb16d",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
    "numberOfRequests": {
        "total": "18434",
        "ok": "17320",
        "ko": "1114"
    },
    "minResponseTime": {
        "total": "5",
        "ok": "13",
        "ko": "5"
    },
    "maxResponseTime": {
        "total": "60173",
        "ok": "49074",
        "ko": "60173"
    },
    "meanResponseTime": {
        "total": "22945",
        "ok": "20891",
        "ko": "54877"
    },
    "standardDeviation": {
        "total": "11652",
        "ok": "7548",
        "ko": "16603"
    },
    "percentiles1": {
        "total": "22388",
        "ok": "22119",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "27470",
        "ok": "27322",
        "ko": "60002"
    },
    "percentiles3": {
        "total": "60000",
        "ok": "29516",
        "ko": "60005"
    },
    "percentiles4": {
        "total": "60002",
        "ok": "36649",
        "ko": "60084"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 34,
    "percentage": 0
},
    "group2": {
    "name": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 39,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "count": 17247,
    "percentage": 94
},
    "group4": {
    "name": "failed",
    "count": 1114,
    "percentage": 6
},
    "meanNumberOfRequestsPerSecond": {
        "total": "15.905",
        "ok": "14.944",
        "ko": "0.961"
    }
}
    },"req_-put--any--book-fdf7e": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
path: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
pathFormatted: "req_-put--any--book-fdf7e",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
    "numberOfRequests": {
        "total": "18434",
        "ok": "16569",
        "ko": "1865"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "14",
        "ko": "1"
    },
    "maxResponseTime": {
        "total": "60193",
        "ok": "49598",
        "ko": "60193"
    },
    "meanResponseTime": {
        "total": "22031",
        "ok": "20312",
        "ko": "37303"
    },
    "standardDeviation": {
        "total": "12850",
        "ok": "7900",
        "ko": "28604"
    },
    "percentiles1": {
        "total": "21028",
        "ok": "20839",
        "ko": "60000"
    },
    "percentiles2": {
        "total": "28678",
        "ok": "28357",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "60000",
        "ok": "29617",
        "ko": "60020"
    },
    "percentiles4": {
        "total": "60002",
        "ok": "36593",
        "ko": "60105"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 77,
    "percentage": 0
},
    "group2": {
    "name": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 21,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "count": 16471,
    "percentage": 89
},
    "group4": {
    "name": "failed",
    "count": 1865,
    "percentage": 10
},
    "meanNumberOfRequestsPerSecond": {
        "total": "15.905",
        "ok": "14.296",
        "ko": "1.609"
    }
}
    },"req_-get--user-is-r-f03f4": {
        type: "REQUEST",
        name: "[GET] User is retrieved with her/his transfers data.",
path: "[GET] User is retrieved with her/his transfers data.",
pathFormatted: "req_-get--user-is-r-f03f4",
stats: {
    "name": "[GET] User is retrieved with her/his transfers data.",
    "numberOfRequests": {
        "total": "18434",
        "ok": "17179",
        "ko": "1255"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "3",
        "ko": "2"
    },
    "maxResponseTime": {
        "total": "60224",
        "ok": "49026",
        "ko": "60224"
    },
    "meanResponseTime": {
        "total": "19486",
        "ok": "19067",
        "ko": "25218"
    },
    "standardDeviation": {
        "total": "11194",
        "ok": "8373",
        "ko": "29078"
    },
    "percentiles1": {
        "total": "18115",
        "ok": "18265",
        "ko": "2006"
    },
    "percentiles2": {
        "total": "25903",
        "ok": "25509",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "34555",
        "ok": "30322",
        "ko": "60003"
    },
    "percentiles4": {
        "total": "60001",
        "ok": "41764",
        "ko": "60111"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 166,
    "percentage": 1
},
    "group2": {
    "name": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 44,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "count": 16969,
    "percentage": 92
},
    "group4": {
    "name": "failed",
    "count": 1255,
    "percentage": 7
},
    "meanNumberOfRequestsPerSecond": {
        "total": "15.905",
        "ok": "14.822",
        "ko": "1.083"
    }
}
    },"req_-put--user-upda-c8c46": {
        type: "REQUEST",
        name: "[PUT] User updates with her/his own data.",
path: "[PUT] User updates with her/his own data.",
pathFormatted: "req_-put--user-upda-c8c46",
stats: {
    "name": "[PUT] User updates with her/his own data.",
    "numberOfRequests": {
        "total": "18434",
        "ok": "17543",
        "ko": "891"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "6",
        "ko": "2"
    },
    "maxResponseTime": {
        "total": "60201",
        "ok": "43478",
        "ko": "60201"
    },
    "meanResponseTime": {
        "total": "18399",
        "ok": "17943",
        "ko": "27380"
    },
    "standardDeviation": {
        "total": "10713",
        "ok": "8488",
        "ko": "29521"
    },
    "percentiles1": {
        "total": "16991",
        "ok": "16997",
        "ko": "2005"
    },
    "percentiles2": {
        "total": "24459",
        "ok": "24150",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "32769",
        "ok": "32364",
        "ko": "60003"
    },
    "percentiles4": {
        "total": "60001",
        "ok": "41135",
        "ko": "60095"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 379,
    "percentage": 2
},
    "group2": {
    "name": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 103,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "count": 17061,
    "percentage": 93
},
    "group4": {
    "name": "failed",
    "count": 891,
    "percentage": 5
},
    "meanNumberOfRequestsPerSecond": {
        "total": "15.905",
        "ok": "15.136",
        "ko": "0.769"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
