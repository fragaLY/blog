var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "826311",
        "ok": "716252",
        "ko": "110059"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "1",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "21107",
        "ok": "21107",
        "ko": "20739"
    },
    "meanResponseTime": {
        "total": "9621",
        "ok": "10625",
        "ko": "3090"
    },
    "standardDeviation": {
        "total": "4726",
        "ok": "3744",
        "ko": "5216"
    },
    "percentiles1": {
        "total": "11499",
        "ok": "11664",
        "ko": "0"
    },
    "percentiles2": {
        "total": "12404",
        "ok": "12490",
        "ko": "6241"
    },
    "percentiles3": {
        "total": "14111",
        "ok": "14353",
        "ko": "12746"
    },
    "percentiles4": {
        "total": "19619",
        "ok": "19656",
        "ko": "15065"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 22227,
    "percentage": 3
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 3030,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 690995,
    "percentage": 84
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 110059,
    "percentage": 13
},
    "meanNumberOfRequestsPerSecond": {
        "total": "753.933",
        "ok": "653.515",
        "ko": "100.419"
    }
},
contents: {
"req_-get--the-list--c0b76": {
        type: "REQUEST",
        name: "[GET] The list of available countries is presented.",
path: "[GET] The list of available countries is presented.",
pathFormatted: "req_-get--the-list--c0b76",
stats: {
    "name": "[GET] The list of available countries is presented.",
    "numberOfRequests": {
        "total": "149951",
        "ok": "71434",
        "ko": "78517"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "1",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "21107",
        "ok": "21107",
        "ko": "1001"
    },
    "meanResponseTime": {
        "total": "4995",
        "ok": "10484",
        "ko": "2"
    },
    "standardDeviation": {
        "total": "5917",
        "ok": "3993",
        "ko": "20"
    },
    "percentiles1": {
        "total": "1",
        "ok": "11690",
        "ko": "0"
    },
    "percentiles2": {
        "total": "11626",
        "ok": "12527",
        "ko": "0"
    },
    "percentiles3": {
        "total": "13272",
        "ok": "14488",
        "ko": "1"
    },
    "percentiles4": {
        "total": "18514",
        "ok": "19838",
        "ko": "28"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 3132,
    "percentage": 2
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 297,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 68005,
    "percentage": 45
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 78517,
    "percentage": 52
},
    "meanNumberOfRequestsPerSecond": {
        "total": "136.817",
        "ok": "65.177",
        "ko": "71.64"
    }
}
    },"req_-get--the-list--3525d": {
        type: "REQUEST",
        name: "[GET] The list of available cities is presented.",
path: "[GET] The list of available cities is presented.",
pathFormatted: "req_-get--the-list--3525d",
stats: {
    "name": "[GET] The list of available cities is presented.",
    "numberOfRequests": {
        "total": "142868",
        "ok": "142868",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "20721",
        "ok": "20721",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10638",
        "ok": "10638",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3762",
        "ok": "3762",
        "ko": "-"
    },
    "percentiles1": {
        "total": "11647",
        "ok": "11647",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12493",
        "ok": "12493",
        "ko": "-"
    },
    "percentiles3": {
        "total": "14552",
        "ok": "14551",
        "ko": "-"
    },
    "percentiles4": {
        "total": "19643",
        "ok": "19643",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 5084,
    "percentage": 4
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 498,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 137286,
    "percentage": 96
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "130.354",
        "ok": "130.354",
        "ko": "-"
    }
}
    },"req_-get--the-list--11d52": {
        type: "REQUEST",
        name: "[GET] The list of available origins is presented.",
path: "[GET] The list of available origins is presented.",
pathFormatted: "req_-get--the-list--11d52",
stats: {
    "name": "[GET] The list of available origins is presented.",
    "numberOfRequests": {
        "total": "71434",
        "ok": "71434",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "20734",
        "ok": "20734",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10644",
        "ok": "10644",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3796",
        "ok": "3796",
        "ko": "-"
    },
    "percentiles1": {
        "total": "11648",
        "ok": "11648",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12497",
        "ok": "12497",
        "ko": "-"
    },
    "percentiles3": {
        "total": "14602",
        "ok": "14600",
        "ko": "-"
    },
    "percentiles4": {
        "total": "19744",
        "ok": "19744",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2638,
    "percentage": 4
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 228,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 68568,
    "percentage": 96
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "65.177",
        "ok": "65.177",
        "ko": "-"
    }
}
    },"req_-get--the-list--0dc40": {
        type: "REQUEST",
        name: "[GET] The list of available destinations is presented.",
path: "[GET] The list of available destinations is presented.",
pathFormatted: "req_-get--the-list--0dc40",
stats: {
    "name": "[GET] The list of available destinations is presented.",
    "numberOfRequests": {
        "total": "71434",
        "ok": "71434",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "20692",
        "ok": "20692",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10751",
        "ok": "10751",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3546",
        "ok": "3546",
        "ko": "-"
    },
    "percentiles1": {
        "total": "11618",
        "ok": "11618",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12478",
        "ok": "12478",
        "ko": "-"
    },
    "percentiles3": {
        "total": "14367",
        "ok": "14368",
        "ko": "-"
    },
    "percentiles4": {
        "total": "19654",
        "ok": "19654",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1948,
    "percentage": 3
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 275,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 69211,
    "percentage": 97
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "65.177",
        "ok": "65.177",
        "ko": "-"
    }
}
    },"req_-get--the-list--8bddb": {
        type: "REQUEST",
        name: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
path: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
pathFormatted: "req_-get--the-list--8bddb",
stats: {
    "name": "[GET] The list of available transfers by selected origin, destination, and date is presented.",
    "numberOfRequests": {
        "total": "71434",
        "ok": "39907",
        "ko": "31527"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "4",
        "ko": "3"
    },
    "maxResponseTime": {
        "total": "20739",
        "ok": "20645",
        "ko": "20739"
    },
    "meanResponseTime": {
        "total": "10802",
        "ok": "10820",
        "ko": "10778"
    },
    "standardDeviation": {
        "total": "3477",
        "ok": "3477",
        "ko": "3478"
    },
    "percentiles1": {
        "total": "11660",
        "ok": "11664",
        "ko": "11660"
    },
    "percentiles2": {
        "total": "12500",
        "ok": "12504",
        "ko": "12495"
    },
    "percentiles3": {
        "total": "14252",
        "ok": "14283",
        "ko": "14204"
    },
    "percentiles4": {
        "total": "19719",
        "ok": "19797",
        "ko": "19662"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 830,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 176,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 38901,
    "percentage": 54
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 31527,
    "percentage": 44
},
    "meanNumberOfRequestsPerSecond": {
        "total": "65.177",
        "ok": "36.411",
        "ko": "28.766"
    }
}
    },"req_-post--the-tran-5ac29": {
        type: "REQUEST",
        name: "[POST] The transfer is booked in the system.",
path: "[POST] The transfer is booked in the system.",
pathFormatted: "req_-post--the-tran-5ac29",
stats: {
    "name": "[POST] The transfer is booked in the system.",
    "numberOfRequests": {
        "total": "39907",
        "ok": "39896",
        "ko": "11"
    },
    "minResponseTime": {
        "total": "4",
        "ok": "4",
        "ko": "4456"
    },
    "maxResponseTime": {
        "total": "20755",
        "ok": "20755",
        "ko": "12499"
    },
    "meanResponseTime": {
        "total": "10821",
        "ok": "10821",
        "ko": "9516"
    },
    "standardDeviation": {
        "total": "3459",
        "ok": "3459",
        "ko": "3434"
    },
    "percentiles1": {
        "total": "11689",
        "ok": "11690",
        "ko": "11439"
    },
    "percentiles2": {
        "total": "12512",
        "ok": "12513",
        "ko": "12434"
    },
    "percentiles3": {
        "total": "14237",
        "ok": "14238",
        "ko": "12477"
    },
    "percentiles4": {
        "total": "19754",
        "ok": "19754",
        "ko": "12495"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 642,
    "percentage": 2
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 115,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 39139,
    "percentage": 98
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 11,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "36.411",
        "ok": "36.401",
        "ko": "0.01"
    }
}
    },"req_-get--the-list--4f742": {
        type: "REQUEST",
        name: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
path: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
pathFormatted: "req_-get--the-list--4f742",
stats: {
    "name": "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
    "numberOfRequests": {
        "total": "39907",
        "ok": "39903",
        "ko": "4"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "22",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "20747",
        "ok": "20747",
        "ko": "0"
    },
    "meanResponseTime": {
        "total": "10781",
        "ok": "10783",
        "ko": "0"
    },
    "standardDeviation": {
        "total": "3459",
        "ok": "3457",
        "ko": "0"
    },
    "percentiles1": {
        "total": "11709",
        "ok": "11709",
        "ko": "0"
    },
    "percentiles2": {
        "total": "12515",
        "ok": "12516",
        "ko": "0"
    },
    "percentiles3": {
        "total": "14211",
        "ok": "14211",
        "ko": "0"
    },
    "percentiles4": {
        "total": "19661",
        "ok": "19660",
        "ko": "0"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 512,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 134,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 39257,
    "percentage": 98
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 4,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "36.411",
        "ok": "36.408",
        "ko": "0.004"
    }
}
    },"req_-get--one-of-th-c14cc": {
        type: "REQUEST",
        name: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
path: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
pathFormatted: "req_-get--one-of-th-c14cc",
stats: {
    "name": "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
    "numberOfRequests": {
        "total": "39896",
        "ok": "39896",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "44",
        "ok": "44",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "20735",
        "ok": "20735",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10738",
        "ok": "10738",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3533",
        "ok": "3533",
        "ko": "-"
    },
    "percentiles1": {
        "total": "11692",
        "ok": "11692",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12485",
        "ok": "12485",
        "ko": "-"
    },
    "percentiles3": {
        "total": "14272",
        "ok": "14272",
        "ko": "-"
    },
    "percentiles4": {
        "total": "19637",
        "ok": "19637",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 393,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 166,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 39337,
    "percentage": 99
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "36.401",
        "ok": "36.401",
        "ko": "-"
    }
}
    },"req_-put--any--book-143cf": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer description is updated.",
path: "[PUT] Any (BOOKED) transfer description is updated.",
pathFormatted: "req_-put--any--book-143cf",
stats: {
    "name": "[PUT] Any (BOOKED) transfer description is updated.",
    "numberOfRequests": {
        "total": "39896",
        "ok": "39896",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "20755",
        "ok": "20755",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10650",
        "ok": "10650",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3640",
        "ok": "3640",
        "ko": "-"
    },
    "percentiles1": {
        "total": "11665",
        "ok": "11669",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12466",
        "ok": "12467",
        "ko": "-"
    },
    "percentiles3": {
        "total": "14296",
        "ok": "14295",
        "ko": "-"
    },
    "percentiles4": {
        "total": "19612",
        "ok": "19613",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 617,
    "percentage": 2
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 289,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 38990,
    "percentage": 98
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "36.401",
        "ok": "36.401",
        "ko": "-"
    }
}
    },"req_-put--any--book-bb16d": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
path: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
pathFormatted: "req_-put--any--book-bb16d",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
    "numberOfRequests": {
        "total": "39896",
        "ok": "39896",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "20750",
        "ok": "20750",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10567",
        "ok": "10567",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3752",
        "ok": "3752",
        "ko": "-"
    },
    "percentiles1": {
        "total": "11643",
        "ok": "11643",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12430",
        "ok": "12428",
        "ko": "-"
    },
    "percentiles3": {
        "total": "14336",
        "ok": "14360",
        "ko": "-"
    },
    "percentiles4": {
        "total": "19694",
        "ok": "19692",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 984,
    "percentage": 2
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 228,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 38684,
    "percentage": 97
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "36.401",
        "ok": "36.401",
        "ko": "-"
    }
}
    },"req_-put--any--book-fdf7e": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
path: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
pathFormatted: "req_-put--any--book-fdf7e",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
    "numberOfRequests": {
        "total": "39896",
        "ok": "39896",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "20705",
        "ok": "20705",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10472",
        "ok": "10472",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3864",
        "ok": "3864",
        "ko": "-"
    },
    "percentiles1": {
        "total": "11630",
        "ok": "11630",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12428",
        "ok": "12428",
        "ko": "-"
    },
    "percentiles3": {
        "total": "14191",
        "ok": "14191",
        "ko": "-"
    },
    "percentiles4": {
        "total": "19627",
        "ok": "19627",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1335,
    "percentage": 3
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 215,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 38346,
    "percentage": 96
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "36.401",
        "ok": "36.401",
        "ko": "-"
    }
}
    },"req_-get--user-is-r-f03f4": {
        type: "REQUEST",
        name: "[GET] User is retrieved with her/his transfers data.",
path: "[GET] User is retrieved with her/his transfers data.",
pathFormatted: "req_-get--user-is-r-f03f4",
stats: {
    "name": "[GET] User is retrieved with her/his transfers data.",
    "numberOfRequests": {
        "total": "39896",
        "ok": "39896",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "20660",
        "ok": "20660",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10380",
        "ok": "10380",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3978",
        "ok": "3978",
        "ko": "-"
    },
    "percentiles1": {
        "total": "11623",
        "ok": "11623",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12461",
        "ok": "12461",
        "ko": "-"
    },
    "percentiles3": {
        "total": "14128",
        "ok": "14130",
        "ko": "-"
    },
    "percentiles4": {
        "total": "19610",
        "ok": "19609",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1797,
    "percentage": 5
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 225,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 37874,
    "percentage": 95
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "36.401",
        "ok": "36.401",
        "ko": "-"
    }
}
    },"req_-put--user-upda-c8c46": {
        type: "REQUEST",
        name: "[PUT] User updates with her/his own data.",
path: "[PUT] User updates with her/his own data.",
pathFormatted: "req_-put--user-upda-c8c46",
stats: {
    "name": "[PUT] User updates with her/his own data.",
    "numberOfRequests": {
        "total": "39896",
        "ok": "39896",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "20759",
        "ok": "20759",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10336",
        "ok": "10336",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4149",
        "ok": "4149",
        "ko": "-"
    },
    "percentiles1": {
        "total": "11655",
        "ok": "11655",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12512",
        "ok": "12512",
        "ko": "-"
    },
    "percentiles3": {
        "total": "14289",
        "ok": "14294",
        "ko": "-"
    },
    "percentiles4": {
        "total": "19642",
        "ok": "19642",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2315,
    "percentage": 6
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 184,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 37397,
    "percentage": 94
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "36.401",
        "ok": "36.401",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
