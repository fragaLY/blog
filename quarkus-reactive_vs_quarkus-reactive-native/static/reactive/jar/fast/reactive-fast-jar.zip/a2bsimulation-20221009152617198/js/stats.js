var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "828711",
        "ok": "718773",
        "ko": "109938"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "1",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "17001",
        "ok": "17001",
        "ko": "16701"
    },
    "meanResponseTime": {
        "total": "9706",
        "ok": "10710",
        "ko": "3139"
    },
    "standardDeviation": {
        "total": "4378",
        "ok": "3224",
        "ko": "5172"
    },
    "percentiles1": {
        "total": "11620",
        "ok": "11745",
        "ko": "0"
    },
    "percentiles2": {
        "total": "12306",
        "ok": "12366",
        "ko": "7957"
    },
    "percentiles3": {
        "total": "13686",
        "ok": "13743",
        "ko": "12543"
    },
    "percentiles4": {
        "total": "15774",
        "ok": "15809",
        "ko": "14037"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 16111,
    "percentage": 2
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 903,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 701759,
    "percentage": 85
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 109938,
    "percentage": 13
},
    "meanNumberOfRequestsPerSecond": {
        "total": "755.434",
        "ok": "655.217",
        "ko": "100.217"
    }
},
contents: {
"req_-get--the-list--c0b76": {
        type: "REQUEST",
        name: "[GET] The list of available countries is presented.",
path: "[GET] The list of available countries is presented.",
pathFormatted: "req_-get--the-list--c0b76",
stats: {
    "name": "[GET] The list of available countries is presented.",
    "numberOfRequests": {
        "total": "149980",
        "ok": "71667",
        "ko": "78313"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "1",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "17001",
        "ok": "17001",
        "ko": "1001"
    },
    "meanResponseTime": {
        "total": "5029",
        "ok": "10522",
        "ko": "1"
    },
    "standardDeviation": {
        "total": "5777",
        "ok": "3471",
        "ko": "13"
    },
    "percentiles1": {
        "total": "1",
        "ok": "11742",
        "ko": "0"
    },
    "percentiles2": {
        "total": "11691",
        "ok": "12369",
        "ko": "0"
    },
    "percentiles3": {
        "total": "12878",
        "ok": "13745",
        "ko": "1"
    },
    "percentiles4": {
        "total": "14774",
        "ok": "15797",
        "ko": "24"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2257,
    "percentage": 2
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 78,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 69332,
    "percentage": 46
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 78313,
    "percentage": 52
},
    "meanNumberOfRequestsPerSecond": {
        "total": "136.718",
        "ok": "65.33",
        "ko": "71.388"
    }
}
    },"req_-get--the-list--3525d": {
        type: "REQUEST",
        name: "[GET] The list of available cities is presented.",
path: "[GET] The list of available cities is presented.",
pathFormatted: "req_-get--the-list--3525d",
stats: {
    "name": "[GET] The list of available cities is presented.",
    "numberOfRequests": {
        "total": "143334",
        "ok": "143334",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16715",
        "ok": "16715",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10705",
        "ok": "10705",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3226",
        "ok": "3226",
        "ko": "-"
    },
    "percentiles1": {
        "total": "11734",
        "ok": "11734",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12369",
        "ok": "12369",
        "ko": "-"
    },
    "percentiles3": {
        "total": "13727",
        "ok": "13726",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15825",
        "ok": "15825",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 3498,
    "percentage": 2
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 34,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 139802,
    "percentage": 98
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "130.66",
        "ok": "130.66",
        "ko": "-"
    }
}
    },"req_-get--the-list--11d52": {
        type: "REQUEST",
        name: "[GET] The list of available origins is presented.",
path: "[GET] The list of available origins is presented.",
pathFormatted: "req_-get--the-list--11d52",
stats: {
    "name": "[GET] The list of available origins is presented.",
    "numberOfRequests": {
        "total": "71667",
        "ok": "71667",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16719",
        "ok": "16719",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10707",
        "ok": "10707",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3236",
        "ok": "3236",
        "ko": "-"
    },
    "percentiles1": {
        "total": "11732",
        "ok": "11732",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12366",
        "ok": "12366",
        "ko": "-"
    },
    "percentiles3": {
        "total": "13737",
        "ok": "13737",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15788",
        "ok": "15788",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1829,
    "percentage": 3
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 15,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 69823,
    "percentage": 97
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "65.33",
        "ok": "65.33",
        "ko": "-"
    }
}
    },"req_-get--the-list--0dc40": {
        type: "REQUEST",
        name: "[GET] The list of available destinations is presented.",
path: "[GET] The list of available destinations is presented.",
pathFormatted: "req_-get--the-list--0dc40",
stats: {
    "name": "[GET] The list of available destinations is presented.",
    "numberOfRequests": {
        "total": "71667",
        "ok": "71667",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16718",
        "ok": "16718",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10847",
        "ok": "10847",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "2997",
        "ok": "2997",
        "ko": "-"
    },
    "percentiles1": {
        "total": "11746",
        "ok": "11746",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12367",
        "ok": "12367",
        "ko": "-"
    },
    "percentiles3": {
        "total": "13745",
        "ok": "13745",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15795",
        "ok": "15795",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1210,
    "percentage": 2
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 11,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 70446,
    "percentage": 98
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "65.33",
        "ok": "65.33",
        "ko": "-"
    }
}
    },"req_-get--the-list--8bddb": {
        type: "REQUEST",
        name: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
path: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
pathFormatted: "req_-get--the-list--8bddb",
stats: {
    "name": "[GET] The list of available transfers by selected origin, destination, and date is presented.",
    "numberOfRequests": {
        "total": "71667",
        "ok": "40057",
        "ko": "31610"
    },
    "minResponseTime": {
        "total": "4",
        "ok": "5",
        "ko": "4"
    },
    "maxResponseTime": {
        "total": "16720",
        "ok": "16720",
        "ko": "16701"
    },
    "meanResponseTime": {
        "total": "10921",
        "ok": "10928",
        "ko": "10911"
    },
    "standardDeviation": {
        "total": "2863",
        "ok": "2858",
        "ko": "2868"
    },
    "percentiles1": {
        "total": "11761",
        "ok": "11762",
        "ko": "11759"
    },
    "percentiles2": {
        "total": "12367",
        "ok": "12367",
        "ko": "12367"
    },
    "percentiles3": {
        "total": "13760",
        "ok": "13760",
        "ko": "13760"
    },
    "percentiles4": {
        "total": "15858",
        "ok": "15892",
        "ko": "15824"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 464,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 3,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 39590,
    "percentage": 55
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 31610,
    "percentage": 44
},
    "meanNumberOfRequestsPerSecond": {
        "total": "65.33",
        "ok": "36.515",
        "ko": "28.815"
    }
}
    },"req_-post--the-tran-5ac29": {
        type: "REQUEST",
        name: "[POST] The transfer is booked in the system.",
path: "[POST] The transfer is booked in the system.",
pathFormatted: "req_-post--the-tran-5ac29",
stats: {
    "name": "[POST] The transfer is booked in the system.",
    "numberOfRequests": {
        "total": "40057",
        "ok": "40047",
        "ko": "10"
    },
    "minResponseTime": {
        "total": "89",
        "ok": "89",
        "ko": "3281"
    },
    "maxResponseTime": {
        "total": "16713",
        "ok": "16713",
        "ko": "13332"
    },
    "meanResponseTime": {
        "total": "10910",
        "ok": "10910",
        "ko": "10254"
    },
    "standardDeviation": {
        "total": "2833",
        "ok": "2833",
        "ko": "2936"
    },
    "percentiles1": {
        "total": "11749",
        "ok": "11749",
        "ko": "11422"
    },
    "percentiles2": {
        "total": "12354",
        "ok": "12354",
        "ko": "12025"
    },
    "percentiles3": {
        "total": "13716",
        "ok": "13716",
        "ko": "12884"
    },
    "percentiles4": {
        "total": "15785",
        "ok": "15785",
        "ko": "13242"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 238,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 5,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 39804,
    "percentage": 99
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 10,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "36.515",
        "ok": "36.506",
        "ko": "0.009"
    }
}
    },"req_-get--the-list--4f742": {
        type: "REQUEST",
        name: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
path: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
pathFormatted: "req_-get--the-list--4f742",
stats: {
    "name": "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
    "numberOfRequests": {
        "total": "40057",
        "ok": "40052",
        "ko": "5"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "454",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "16716",
        "ok": "16716",
        "ko": "0"
    },
    "meanResponseTime": {
        "total": "10882",
        "ok": "10884",
        "ko": "0"
    },
    "standardDeviation": {
        "total": "2879",
        "ok": "2877",
        "ko": "0"
    },
    "percentiles1": {
        "total": "11755",
        "ok": "11755",
        "ko": "0"
    },
    "percentiles2": {
        "total": "12359",
        "ok": "12359",
        "ko": "0"
    },
    "percentiles3": {
        "total": "13705",
        "ok": "13706",
        "ko": "0"
    },
    "percentiles4": {
        "total": "15805",
        "ok": "15805",
        "ko": "0"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 87,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 6,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 39959,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 5,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "36.515",
        "ok": "36.51",
        "ko": "0.005"
    }
}
    },"req_-get--one-of-th-c14cc": {
        type: "REQUEST",
        name: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
path: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
pathFormatted: "req_-get--one-of-th-c14cc",
stats: {
    "name": "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
    "numberOfRequests": {
        "total": "40047",
        "ok": "40047",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "477",
        "ok": "477",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16688",
        "ok": "16688",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10838",
        "ok": "10838",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "2969",
        "ok": "2969",
        "ko": "-"
    },
    "percentiles1": {
        "total": "11752",
        "ok": "11752",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12359",
        "ok": "12361",
        "ko": "-"
    },
    "percentiles3": {
        "total": "13738",
        "ok": "13738",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15795",
        "ok": "15795",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 8,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 25,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 40014,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "36.506",
        "ok": "36.506",
        "ko": "-"
    }
}
    },"req_-put--any--book-143cf": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer description is updated.",
path: "[PUT] Any (BOOKED) transfer description is updated.",
pathFormatted: "req_-put--any--book-143cf",
stats: {
    "name": "[PUT] Any (BOOKED) transfer description is updated.",
    "numberOfRequests": {
        "total": "40047",
        "ok": "40047",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16716",
        "ok": "16716",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10776",
        "ok": "10776",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3133",
        "ok": "3133",
        "ko": "-"
    },
    "percentiles1": {
        "total": "11764",
        "ok": "11764",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12373",
        "ok": "12373",
        "ko": "-"
    },
    "percentiles3": {
        "total": "13764",
        "ok": "13767",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15838",
        "ok": "15838",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 363,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 133,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 39551,
    "percentage": 99
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "36.506",
        "ok": "36.506",
        "ko": "-"
    }
}
    },"req_-put--any--book-bb16d": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
path: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
pathFormatted: "req_-put--any--book-bb16d",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
    "numberOfRequests": {
        "total": "40047",
        "ok": "40047",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16779",
        "ok": "16779",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10692",
        "ok": "10692",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3292",
        "ok": "3292",
        "ko": "-"
    },
    "percentiles1": {
        "total": "11752",
        "ok": "11751",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12380",
        "ok": "12380",
        "ko": "-"
    },
    "percentiles3": {
        "total": "13791",
        "ok": "13791",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15822",
        "ok": "15821",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 807,
    "percentage": 2
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 163,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 39077,
    "percentage": 98
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "36.506",
        "ok": "36.506",
        "ko": "-"
    }
}
    },"req_-put--any--book-fdf7e": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
path: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
pathFormatted: "req_-put--any--book-fdf7e",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
    "numberOfRequests": {
        "total": "40047",
        "ok": "40047",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16763",
        "ok": "16763",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10601",
        "ok": "10601",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3443",
        "ok": "3443",
        "ko": "-"
    },
    "percentiles1": {
        "total": "11752",
        "ok": "11752",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12366",
        "ok": "12372",
        "ko": "-"
    },
    "percentiles3": {
        "total": "13768",
        "ok": "13768",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15834",
        "ok": "15833",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1311,
    "percentage": 3
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 142,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 38594,
    "percentage": 96
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "36.506",
        "ok": "36.506",
        "ko": "-"
    }
}
    },"req_-get--user-is-r-f03f4": {
        type: "REQUEST",
        name: "[GET] User is retrieved with her/his transfers data.",
path: "[GET] User is retrieved with her/his transfers data.",
pathFormatted: "req_-get--user-is-r-f03f4",
stats: {
    "name": "[GET] User is retrieved with her/his transfers data.",
    "numberOfRequests": {
        "total": "40047",
        "ok": "40047",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16699",
        "ok": "16699",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10494",
        "ok": "10494",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3586",
        "ok": "3586",
        "ko": "-"
    },
    "percentiles1": {
        "total": "11732",
        "ok": "11732",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12357",
        "ok": "12356",
        "ko": "-"
    },
    "percentiles3": {
        "total": "13749",
        "ok": "13752",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15790",
        "ok": "15790",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1775,
    "percentage": 4
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 150,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 38122,
    "percentage": 95
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "36.506",
        "ok": "36.506",
        "ko": "-"
    }
}
    },"req_-put--user-upda-c8c46": {
        type: "REQUEST",
        name: "[PUT] User updates with her/his own data.",
path: "[PUT] User updates with her/his own data.",
pathFormatted: "req_-put--user-upda-c8c46",
stats: {
    "name": "[PUT] User updates with her/his own data.",
    "numberOfRequests": {
        "total": "40047",
        "ok": "40047",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "16714",
        "ok": "16714",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10392",
        "ok": "10392",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3732",
        "ok": "3732",
        "ko": "-"
    },
    "percentiles1": {
        "total": "11737",
        "ok": "11737",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12353",
        "ok": "12354",
        "ko": "-"
    },
    "percentiles3": {
        "total": "13724",
        "ok": "13724",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15779",
        "ok": "15780",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2264,
    "percentage": 6
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 138,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 37645,
    "percentage": 94
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "36.506",
        "ok": "36.506",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
