var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "609675",
        "ok": "486400",
        "ko": "123275"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "1",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "29037",
        "ok": "29037",
        "ko": "28832"
    },
    "meanResponseTime": {
        "total": "14901",
        "ok": "17853",
        "ko": "3254"
    },
    "standardDeviation": {
        "total": "8211",
        "ok": "5287",
        "ko": "7287"
    },
    "percentiles1": {
        "total": "18049",
        "ok": "18602",
        "ko": "0"
    },
    "percentiles2": {
        "total": "19908",
        "ok": "20259",
        "ko": "1"
    },
    "percentiles3": {
        "total": "24206",
        "ok": "24636",
        "ko": "20434"
    },
    "percentiles4": {
        "total": "27546",
        "ok": "27765",
        "ko": "24353"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 9588,
    "percentage": 2
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 3124,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 473688,
    "percentage": 78
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 123275,
    "percentage": 20
},
    "meanNumberOfRequestsPerSecond": {
        "total": "540.492",
        "ok": "431.206",
        "ko": "109.286"
    }
},
contents: {
"req_-get--the-list--c0b76": {
        type: "REQUEST",
        name: "[GET] The list of available countries is presented.",
path: "[GET] The list of available countries is presented.",
pathFormatted: "req_-get--the-list--c0b76",
stats: {
    "name": "[GET] The list of available countries is presented.",
    "numberOfRequests": {
        "total": "150331",
        "ok": "48570",
        "ko": "101761"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "4",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "28933",
        "ok": "28933",
        "ko": "475"
    },
    "meanResponseTime": {
        "total": "5675",
        "ok": "17563",
        "ko": "1"
    },
    "standardDeviation": {
        "total": "8721",
        "ok": "5160",
        "ko": "12"
    },
    "percentiles1": {
        "total": "0",
        "ok": "18525",
        "ko": "0"
    },
    "percentiles2": {
        "total": "17200",
        "ok": "20013",
        "ko": "0"
    },
    "percentiles3": {
        "total": "20966",
        "ok": "23031",
        "ko": "1"
    },
    "percentiles4": {
        "total": "24473",
        "ok": "26431",
        "ko": "1"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 640,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 618,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 47312,
    "percentage": 31
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 101761,
    "percentage": 68
},
    "meanNumberOfRequestsPerSecond": {
        "total": "133.272",
        "ok": "43.059",
        "ko": "90.214"
    }
}
    },"req_-get--the-list--3525d": {
        type: "REQUEST",
        name: "[GET] The list of available cities is presented.",
path: "[GET] The list of available cities is presented.",
pathFormatted: "req_-get--the-list--3525d",
stats: {
    "name": "[GET] The list of available cities is presented.",
    "numberOfRequests": {
        "total": "97140",
        "ok": "97140",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "28867",
        "ok": "28867",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "18592",
        "ok": "18592",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4766",
        "ok": "4766",
        "ko": "-"
    },
    "percentiles1": {
        "total": "18764",
        "ok": "18772",
        "ko": "-"
    },
    "percentiles2": {
        "total": "20653",
        "ok": "20650",
        "ko": "-"
    },
    "percentiles3": {
        "total": "25029",
        "ok": "25029",
        "ko": "-"
    },
    "percentiles4": {
        "total": "28250",
        "ok": "28250",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 479,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 769,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 95892,
    "percentage": 99
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "86.117",
        "ok": "86.117",
        "ko": "-"
    }
}
    },"req_-get--the-list--11d52": {
        type: "REQUEST",
        name: "[GET] The list of available origins is presented.",
path: "[GET] The list of available origins is presented.",
pathFormatted: "req_-get--the-list--11d52",
stats: {
    "name": "[GET] The list of available origins is presented.",
    "numberOfRequests": {
        "total": "48570",
        "ok": "48570",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "43",
        "ok": "43",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "28867",
        "ok": "28867",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "18755",
        "ok": "18755",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4808",
        "ok": "4808",
        "ko": "-"
    },
    "percentiles1": {
        "total": "18883",
        "ok": "18885",
        "ko": "-"
    },
    "percentiles2": {
        "total": "20977",
        "ok": "20956",
        "ko": "-"
    },
    "percentiles3": {
        "total": "25163",
        "ok": "25162",
        "ko": "-"
    },
    "percentiles4": {
        "total": "28050",
        "ok": "28050",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 186,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 488,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 47896,
    "percentage": 99
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "43.059",
        "ok": "43.059",
        "ko": "-"
    }
}
    },"req_-get--the-list--0dc40": {
        type: "REQUEST",
        name: "[GET] The list of available destinations is presented.",
path: "[GET] The list of available destinations is presented.",
pathFormatted: "req_-get--the-list--0dc40",
stats: {
    "name": "[GET] The list of available destinations is presented.",
    "numberOfRequests": {
        "total": "48570",
        "ok": "48570",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "795",
        "ok": "795",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "28844",
        "ok": "28844",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "18928",
        "ok": "18928",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4191",
        "ok": "4191",
        "ko": "-"
    },
    "percentiles1": {
        "total": "18898",
        "ok": "18896",
        "ko": "-"
    },
    "percentiles2": {
        "total": "21116",
        "ok": "21116",
        "ko": "-"
    },
    "percentiles3": {
        "total": "24909",
        "ok": "24909",
        "ko": "-"
    },
    "percentiles4": {
        "total": "27778",
        "ok": "27778",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 87,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 48482,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "43.059",
        "ok": "43.059",
        "ko": "-"
    }
}
    },"req_-get--the-list--8bddb": {
        type: "REQUEST",
        name: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
path: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
pathFormatted: "req_-get--the-list--8bddb",
stats: {
    "name": "[GET] The list of available transfers by selected origin, destination, and date is presented.",
    "numberOfRequests": {
        "total": "48570",
        "ok": "27067",
        "ko": "21503"
    },
    "minResponseTime": {
        "total": "1514",
        "ok": "1572",
        "ko": "1514"
    },
    "maxResponseTime": {
        "total": "28843",
        "ok": "28843",
        "ko": "28832"
    },
    "meanResponseTime": {
        "total": "18629",
        "ok": "18618",
        "ko": "18644"
    },
    "standardDeviation": {
        "total": "4177",
        "ok": "4178",
        "ko": "4175"
    },
    "percentiles1": {
        "total": "18755",
        "ok": "18748",
        "ko": "18760"
    },
    "percentiles2": {
        "total": "20801",
        "ok": "20786",
        "ko": "20820"
    },
    "percentiles3": {
        "total": "24544",
        "ok": "24504",
        "ko": "24592"
    },
    "percentiles4": {
        "total": "27636",
        "ok": "27625",
        "ko": "27677"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 27067,
    "percentage": 56
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 21503,
    "percentage": 44
},
    "meanNumberOfRequestsPerSecond": {
        "total": "43.059",
        "ok": "23.996",
        "ko": "19.063"
    }
}
    },"req_-post--the-tran-5ac29": {
        type: "REQUEST",
        name: "[POST] The transfer is booked in the system.",
path: "[POST] The transfer is booked in the system.",
pathFormatted: "req_-post--the-tran-5ac29",
stats: {
    "name": "[POST] The transfer is booked in the system.",
    "numberOfRequests": {
        "total": "27067",
        "ok": "27060",
        "ko": "7"
    },
    "minResponseTime": {
        "total": "2900",
        "ok": "2900",
        "ko": "17292"
    },
    "maxResponseTime": {
        "total": "28974",
        "ok": "28974",
        "ko": "20944"
    },
    "meanResponseTime": {
        "total": "18115",
        "ok": "18115",
        "ko": "19115"
    },
    "standardDeviation": {
        "total": "4444",
        "ok": "4445",
        "ko": "1258"
    },
    "percentiles1": {
        "total": "18531",
        "ok": "18528",
        "ko": "18673"
    },
    "percentiles2": {
        "total": "20219",
        "ok": "20214",
        "ko": "20169"
    },
    "percentiles3": {
        "total": "24194",
        "ok": "24192",
        "ko": "20871"
    },
    "percentiles4": {
        "total": "26926",
        "ok": "26927",
        "ko": "20929"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 27060,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 7,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "23.996",
        "ok": "23.989",
        "ko": "0.006"
    }
}
    },"req_-get--the-list--4f742": {
        type: "REQUEST",
        name: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
path: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
pathFormatted: "req_-get--the-list--4f742",
stats: {
    "name": "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
    "numberOfRequests": {
        "total": "27067",
        "ok": "27063",
        "ko": "4"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "1506",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "28836",
        "ok": "28836",
        "ko": "1"
    },
    "meanResponseTime": {
        "total": "17805",
        "ok": "17808",
        "ko": "0"
    },
    "standardDeviation": {
        "total": "4694",
        "ok": "4690",
        "ko": "0"
    },
    "percentiles1": {
        "total": "18526",
        "ok": "18527",
        "ko": "0"
    },
    "percentiles2": {
        "total": "20019",
        "ok": "20020",
        "ko": "0"
    },
    "percentiles3": {
        "total": "23633",
        "ok": "23632",
        "ko": "1"
    },
    "percentiles4": {
        "total": "25917",
        "ok": "25917",
        "ko": "1"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 27063,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 4,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "23.996",
        "ok": "23.992",
        "ko": "0.004"
    }
}
    },"req_-get--one-of-th-c14cc": {
        type: "REQUEST",
        name: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
path: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
pathFormatted: "req_-get--one-of-th-c14cc",
stats: {
    "name": "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
    "numberOfRequests": {
        "total": "27060",
        "ok": "27060",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "337",
        "ok": "337",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "28851",
        "ok": "28851",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "17738",
        "ok": "17738",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5076",
        "ok": "5076",
        "ko": "-"
    },
    "percentiles1": {
        "total": "18684",
        "ok": "18685",
        "ko": "-"
    },
    "percentiles2": {
        "total": "20165",
        "ok": "20165",
        "ko": "-"
    },
    "percentiles3": {
        "total": "23111",
        "ok": "23116",
        "ko": "-"
    },
    "percentiles4": {
        "total": "25798",
        "ok": "25798",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 50,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 119,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 26891,
    "percentage": 99
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "23.989",
        "ok": "23.989",
        "ko": "-"
    }
}
    },"req_-put--any--book-143cf": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer description is updated.",
path: "[PUT] Any (BOOKED) transfer description is updated.",
pathFormatted: "req_-put--any--book-143cf",
stats: {
    "name": "[PUT] Any (BOOKED) transfer description is updated.",
    "numberOfRequests": {
        "total": "27060",
        "ok": "27060",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "28997",
        "ok": "28997",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "17493",
        "ok": "17493",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5649",
        "ok": "5649",
        "ko": "-"
    },
    "percentiles1": {
        "total": "18612",
        "ok": "18611",
        "ko": "-"
    },
    "percentiles2": {
        "total": "20084",
        "ok": "20084",
        "ko": "-"
    },
    "percentiles3": {
        "total": "24111",
        "ok": "24119",
        "ko": "-"
    },
    "percentiles4": {
        "total": "28034",
        "ok": "28034",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 665,
    "percentage": 2
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 244,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 26151,
    "percentage": 97
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "23.989",
        "ok": "23.989",
        "ko": "-"
    }
}
    },"req_-put--any--book-bb16d": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
path: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
pathFormatted: "req_-put--any--book-bb16d",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
    "numberOfRequests": {
        "total": "27060",
        "ok": "27060",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "29022",
        "ok": "29022",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "17096",
        "ok": "17096",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5998",
        "ok": "5998",
        "ko": "-"
    },
    "percentiles1": {
        "total": "18482",
        "ok": "18482",
        "ko": "-"
    },
    "percentiles2": {
        "total": "19926",
        "ok": "19926",
        "ko": "-"
    },
    "percentiles3": {
        "total": "23608",
        "ok": "23612",
        "ko": "-"
    },
    "percentiles4": {
        "total": "28012",
        "ok": "28013",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1179,
    "percentage": 4
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 217,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 25664,
    "percentage": 95
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "23.989",
        "ok": "23.989",
        "ko": "-"
    }
}
    },"req_-put--any--book-fdf7e": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
path: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
pathFormatted: "req_-put--any--book-fdf7e",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
    "numberOfRequests": {
        "total": "27060",
        "ok": "27060",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "29037",
        "ok": "29037",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "16565",
        "ok": "16565",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "6290",
        "ok": "6290",
        "ko": "-"
    },
    "percentiles1": {
        "total": "18103",
        "ok": "18102",
        "ko": "-"
    },
    "percentiles2": {
        "total": "19714",
        "ok": "19714",
        "ko": "-"
    },
    "percentiles3": {
        "total": "22672",
        "ok": "22677",
        "ko": "-"
    },
    "percentiles4": {
        "total": "27671",
        "ok": "27665",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1668,
    "percentage": 6
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 225,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 25167,
    "percentage": 93
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "23.989",
        "ok": "23.989",
        "ko": "-"
    }
}
    },"req_-get--user-is-r-f03f4": {
        type: "REQUEST",
        name: "[GET] User is retrieved with her/his transfers data.",
path: "[GET] User is retrieved with her/his transfers data.",
pathFormatted: "req_-get--user-is-r-f03f4",
stats: {
    "name": "[GET] User is retrieved with her/his transfers data.",
    "numberOfRequests": {
        "total": "27060",
        "ok": "27060",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "28842",
        "ok": "28842",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "15989",
        "ok": "15989",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "6570",
        "ok": "6570",
        "ko": "-"
    },
    "percentiles1": {
        "total": "17882",
        "ok": "17883",
        "ko": "-"
    },
    "percentiles2": {
        "total": "19419",
        "ok": "19419",
        "ko": "-"
    },
    "percentiles3": {
        "total": "22136",
        "ok": "22129",
        "ko": "-"
    },
    "percentiles4": {
        "total": "25903",
        "ok": "25899",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2164,
    "percentage": 8
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 192,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 24704,
    "percentage": 91
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "23.989",
        "ok": "23.989",
        "ko": "-"
    }
}
    },"req_-put--user-upda-c8c46": {
        type: "REQUEST",
        name: "[PUT] User updates with her/his own data.",
path: "[PUT] User updates with her/his own data.",
pathFormatted: "req_-put--user-upda-c8c46",
stats: {
    "name": "[PUT] User updates with her/his own data.",
    "numberOfRequests": {
        "total": "27060",
        "ok": "27060",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "28986",
        "ok": "28986",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "15583",
        "ok": "15583",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "6868",
        "ok": "6868",
        "ko": "-"
    },
    "percentiles1": {
        "total": "17944",
        "ok": "17944",
        "ko": "-"
    },
    "percentiles2": {
        "total": "19297",
        "ok": "19297",
        "ko": "-"
    },
    "percentiles3": {
        "total": "21912",
        "ok": "21912",
        "ko": "-"
    },
    "percentiles4": {
        "total": "25606",
        "ok": "25600",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2556,
    "percentage": 9
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 165,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 24339,
    "percentage": 90
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "23.989",
        "ok": "23.989",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
