var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "473991",
        "ok": "343384",
        "ko": "130607"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "1",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "62138",
        "ok": "59974",
        "ko": "62138"
    },
    "meanResponseTime": {
        "total": "13708",
        "ok": "17456",
        "ko": "3853"
    },
    "standardDeviation": {
        "total": "10589",
        "ok": "9064",
        "ko": "7544"
    },
    "percentiles1": {
        "total": "15070",
        "ok": "16746",
        "ko": "2003"
    },
    "percentiles2": {
        "total": "19145",
        "ok": "20524",
        "ko": "2005"
    },
    "percentiles3": {
        "total": "33060",
        "ok": "35505",
        "ko": "19408"
    },
    "percentiles4": {
        "total": "45807",
        "ok": "46180",
        "ko": "37745"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 8327,
    "percentage": 2
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 1655,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 333402,
    "percentage": 70
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 130607,
    "percentage": 28
},
    "meanNumberOfRequestsPerSecond": {
        "total": "428.563",
        "ok": "310.474",
        "ko": "118.09"
    }
},
contents: {
"req_-get--the-list--c0b76": {
        type: "REQUEST",
        name: "[GET] The list of available countries is presented.",
path: "[GET] The list of available countries is presented.",
pathFormatted: "req_-get--the-list--c0b76",
stats: {
    "name": "[GET] The list of available countries is presented.",
    "numberOfRequests": {
        "total": "149659",
        "ok": "34353",
        "ko": "115306"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "2",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "62138",
        "ok": "59875",
        "ko": "62138"
    },
    "meanResponseTime": {
        "total": "5603",
        "ok": "18335",
        "ko": "1810"
    },
    "standardDeviation": {
        "total": "9485",
        "ok": "11119",
        "ko": "4153"
    },
    "percentiles1": {
        "total": "2003",
        "ok": "16649",
        "ko": "2002"
    },
    "percentiles2": {
        "total": "2048",
        "ok": "22564",
        "ko": "2004"
    },
    "percentiles3": {
        "total": "25281",
        "ok": "39883",
        "ko": "2044"
    },
    "percentiles4": {
        "total": "42035",
        "ok": "54566",
        "ko": "3258"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1572,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 190,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 32591,
    "percentage": 22
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 115306,
    "percentage": 77
},
    "meanNumberOfRequestsPerSecond": {
        "total": "135.316",
        "ok": "31.061",
        "ko": "104.255"
    }
}
    },"req_-get--the-list--3525d": {
        type: "REQUEST",
        name: "[GET] The list of available cities is presented.",
path: "[GET] The list of available cities is presented.",
pathFormatted: "req_-get--the-list--3525d",
stats: {
    "name": "[GET] The list of available cities is presented.",
    "numberOfRequests": {
        "total": "68694",
        "ok": "68659",
        "ko": "35"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "1970"
    },
    "maxResponseTime": {
        "total": "60003",
        "ok": "59843",
        "ko": "60003"
    },
    "meanResponseTime": {
        "total": "17849",
        "ok": "17832",
        "ko": "50137"
    },
    "standardDeviation": {
        "total": "9530",
        "ok": "9492",
        "ko": "21686"
    },
    "percentiles1": {
        "total": "16903",
        "ok": "16902",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "20683",
        "ok": "20683",
        "ko": "60002"
    },
    "percentiles3": {
        "total": "37097",
        "ok": "37006",
        "ko": "60002"
    },
    "percentiles4": {
        "total": "46548",
        "ok": "46495",
        "ko": "60003"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2099,
    "percentage": 3
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 331,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 66229,
    "percentage": 96
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 35,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "62.11",
        "ok": "62.079",
        "ko": "0.032"
    }
}
    },"req_-get--the-list--11d52": {
        type: "REQUEST",
        name: "[GET] The list of available origins is presented.",
path: "[GET] The list of available origins is presented.",
pathFormatted: "req_-get--the-list--11d52",
stats: {
    "name": "[GET] The list of available origins is presented.",
    "numberOfRequests": {
        "total": "34341",
        "ok": "34335",
        "ko": "6"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "60001"
    },
    "maxResponseTime": {
        "total": "60004",
        "ok": "58642",
        "ko": "60004"
    },
    "meanResponseTime": {
        "total": "17107",
        "ok": "17099",
        "ko": "60002"
    },
    "standardDeviation": {
        "total": "9250",
        "ok": "9233",
        "ko": "1"
    },
    "percentiles1": {
        "total": "16643",
        "ok": "16642",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "20321",
        "ok": "20319",
        "ko": "60002"
    },
    "percentiles3": {
        "total": "36998",
        "ok": "36980",
        "ko": "60004"
    },
    "percentiles4": {
        "total": "47029",
        "ok": "46934",
        "ko": "60004"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1162,
    "percentage": 3
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 141,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 33032,
    "percentage": 96
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 6,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "31.05",
        "ok": "31.044",
        "ko": "0.005"
    }
}
    },"req_-get--the-list--0dc40": {
        type: "REQUEST",
        name: "[GET] The list of available destinations is presented.",
path: "[GET] The list of available destinations is presented.",
pathFormatted: "req_-get--the-list--0dc40",
stats: {
    "name": "[GET] The list of available destinations is presented.",
    "numberOfRequests": {
        "total": "34318",
        "ok": "34305",
        "ko": "13"
    },
    "minResponseTime": {
        "total": "4",
        "ok": "4",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60002",
        "ok": "59810",
        "ko": "60002"
    },
    "meanResponseTime": {
        "total": "19161",
        "ok": "19146",
        "ko": "60001"
    },
    "standardDeviation": {
        "total": "9646",
        "ok": "9615",
        "ko": "1"
    },
    "percentiles1": {
        "total": "18034",
        "ok": "18032",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "22055",
        "ok": "22024",
        "ko": "60002"
    },
    "percentiles3": {
        "total": "38159",
        "ok": "38112",
        "ko": "60002"
    },
    "percentiles4": {
        "total": "47636",
        "ok": "47523",
        "ko": "60002"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 530,
    "percentage": 2
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 173,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 33602,
    "percentage": 98
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 13,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "31.029",
        "ok": "31.017",
        "ko": "0.012"
    }
}
    },"req_-get--the-list--8bddb": {
        type: "REQUEST",
        name: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
path: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
pathFormatted: "req_-get--the-list--8bddb",
stats: {
    "name": "[GET] The list of available transfers by selected origin, destination, and date is presented.",
    "numberOfRequests": {
        "total": "34305",
        "ok": "19091",
        "ko": "15214"
    },
    "minResponseTime": {
        "total": "11",
        "ok": "11",
        "ko": "31"
    },
    "maxResponseTime": {
        "total": "60001",
        "ok": "59773",
        "ko": "60001"
    },
    "meanResponseTime": {
        "total": "19478",
        "ok": "19769",
        "ko": "19111"
    },
    "standardDeviation": {
        "total": "9209",
        "ok": "9381",
        "ko": "8974"
    },
    "percentiles1": {
        "total": "18670",
        "ok": "18724",
        "ko": "18503"
    },
    "percentiles2": {
        "total": "22743",
        "ok": "23801",
        "ko": "21782"
    },
    "percentiles3": {
        "total": "38506",
        "ok": "39013",
        "ko": "36978"
    },
    "percentiles4": {
        "total": "46727",
        "ok": "47007",
        "ko": "46437"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 85,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 88,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 18918,
    "percentage": 55
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 15214,
    "percentage": 44
},
    "meanNumberOfRequestsPerSecond": {
        "total": "31.017",
        "ok": "17.261",
        "ko": "13.756"
    }
}
    },"req_-post--the-tran-5ac29": {
        type: "REQUEST",
        name: "[POST] The transfer is booked in the system.",
path: "[POST] The transfer is booked in the system.",
pathFormatted: "req_-post--the-tran-5ac29",
stats: {
    "name": "[POST] The transfer is booked in the system.",
    "numberOfRequests": {
        "total": "19091",
        "ok": "19088",
        "ko": "3"
    },
    "minResponseTime": {
        "total": "12",
        "ok": "12",
        "ko": "18033"
    },
    "maxResponseTime": {
        "total": "60000",
        "ok": "54679",
        "ko": "60000"
    },
    "meanResponseTime": {
        "total": "17850",
        "ok": "17847",
        "ko": "35456"
    },
    "standardDeviation": {
        "total": "7356",
        "ok": "7350",
        "ko": "17858"
    },
    "percentiles1": {
        "total": "17701",
        "ok": "17701",
        "ko": "28335"
    },
    "percentiles2": {
        "total": "20646",
        "ok": "20645",
        "ko": "44168"
    },
    "percentiles3": {
        "total": "31167",
        "ok": "31162",
        "ko": "56833"
    },
    "percentiles4": {
        "total": "38068",
        "ok": "38060",
        "ko": "59367"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 8,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 35,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 19045,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 3,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "17.261",
        "ok": "17.259",
        "ko": "0.003"
    }
}
    },"req_-get--the-list--4f742": {
        type: "REQUEST",
        name: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
path: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
pathFormatted: "req_-get--the-list--4f742",
stats: {
    "name": "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
    "numberOfRequests": {
        "total": "19091",
        "ok": "19083",
        "ko": "8"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "4",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "60003",
        "ok": "59974",
        "ko": "60003"
    },
    "meanResponseTime": {
        "total": "19079",
        "ok": "19068",
        "ko": "45273"
    },
    "standardDeviation": {
        "total": "9249",
        "ok": "9221",
        "ko": "25518"
    },
    "percentiles1": {
        "total": "17549",
        "ok": "17574",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "21738",
        "ok": "21727",
        "ko": "60002"
    },
    "percentiles3": {
        "total": "37561",
        "ok": "37532",
        "ko": "60003"
    },
    "percentiles4": {
        "total": "48203",
        "ok": "48079",
        "ko": "60003"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 127,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 38,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 18918,
    "percentage": 99
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 8,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "17.261",
        "ok": "17.254",
        "ko": "0.007"
    }
}
    },"req_-get--one-of-th-c14cc": {
        type: "REQUEST",
        name: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
path: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
pathFormatted: "req_-get--one-of-th-c14cc",
stats: {
    "name": "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
    "numberOfRequests": {
        "total": "19082",
        "ok": "19081",
        "ko": "1"
    },
    "minResponseTime": {
        "total": "7",
        "ok": "7",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60000",
        "ok": "57558",
        "ko": "60000"
    },
    "meanResponseTime": {
        "total": "16257",
        "ok": "16255",
        "ko": "60000"
    },
    "standardDeviation": {
        "total": "6913",
        "ok": "6906",
        "ko": "0"
    },
    "percentiles1": {
        "total": "16649",
        "ok": "16649",
        "ko": "60000"
    },
    "percentiles2": {
        "total": "19253",
        "ok": "19252",
        "ko": "60000"
    },
    "percentiles3": {
        "total": "29127",
        "ok": "29122",
        "ko": "60000"
    },
    "percentiles4": {
        "total": "35698",
        "ok": "35673",
        "ko": "60000"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 229,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 102,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 18750,
    "percentage": 98
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 1,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "17.253",
        "ok": "17.252",
        "ko": "0.001"
    }
}
    },"req_-put--any--book-143cf": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer description is updated.",
path: "[PUT] Any (BOOKED) transfer description is updated.",
pathFormatted: "req_-put--any--book-143cf",
stats: {
    "name": "[PUT] Any (BOOKED) transfer description is updated.",
    "numberOfRequests": {
        "total": "19082",
        "ok": "19080",
        "ko": "2"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "2005"
    },
    "maxResponseTime": {
        "total": "60003",
        "ok": "55389",
        "ko": "60003"
    },
    "meanResponseTime": {
        "total": "16385",
        "ok": "16383",
        "ko": "31004"
    },
    "standardDeviation": {
        "total": "7388",
        "ok": "7381",
        "ko": "28999"
    },
    "percentiles1": {
        "total": "16455",
        "ok": "16455",
        "ko": "31004"
    },
    "percentiles2": {
        "total": "19631",
        "ok": "19632",
        "ko": "45504"
    },
    "percentiles3": {
        "total": "30264",
        "ok": "30260",
        "ko": "57103"
    },
    "percentiles4": {
        "total": "35853",
        "ok": "35846",
        "ko": "59423"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 305,
    "percentage": 2
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 129,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 18646,
    "percentage": 98
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 2,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "17.253",
        "ok": "17.251",
        "ko": "0.002"
    }
}
    },"req_-put--any--book-bb16d": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
path: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
pathFormatted: "req_-put--any--book-bb16d",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
    "numberOfRequests": {
        "total": "19082",
        "ok": "19079",
        "ko": "3"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "2002"
    },
    "maxResponseTime": {
        "total": "60000",
        "ok": "54245",
        "ko": "60000"
    },
    "meanResponseTime": {
        "total": "15674",
        "ok": "15673",
        "ko": "21389"
    },
    "standardDeviation": {
        "total": "7615",
        "ok": "7607",
        "ko": "27302"
    },
    "percentiles1": {
        "total": "16153",
        "ok": "16153",
        "ko": "2166"
    },
    "percentiles2": {
        "total": "19133",
        "ok": "19135",
        "ko": "31083"
    },
    "percentiles3": {
        "total": "29379",
        "ok": "29373",
        "ko": "54217"
    },
    "percentiles4": {
        "total": "37000",
        "ok": "36945",
        "ko": "58843"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 451,
    "percentage": 2
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 132,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 18496,
    "percentage": 97
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 3,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "17.253",
        "ok": "17.25",
        "ko": "0.003"
    }
}
    },"req_-put--any--book-fdf7e": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
path: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
pathFormatted: "req_-put--any--book-fdf7e",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
    "numberOfRequests": {
        "total": "19082",
        "ok": "19079",
        "ko": "3"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "2002"
    },
    "maxResponseTime": {
        "total": "55626",
        "ok": "55626",
        "ko": "2003"
    },
    "meanResponseTime": {
        "total": "15655",
        "ok": "15658",
        "ko": "2003"
    },
    "standardDeviation": {
        "total": "7428",
        "ok": "7427",
        "ko": "0"
    },
    "percentiles1": {
        "total": "16009",
        "ok": "16008",
        "ko": "2003"
    },
    "percentiles2": {
        "total": "18806",
        "ok": "18807",
        "ko": "2003"
    },
    "percentiles3": {
        "total": "29574",
        "ok": "29573",
        "ko": "2003"
    },
    "percentiles4": {
        "total": "36558",
        "ok": "36555",
        "ko": "2003"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 406,
    "percentage": 2
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 77,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 18596,
    "percentage": 97
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 3,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "17.253",
        "ok": "17.25",
        "ko": "0.003"
    }
}
    },"req_-get--user-is-r-f03f4": {
        type: "REQUEST",
        name: "[GET] User is retrieved with her/his transfers data.",
path: "[GET] User is retrieved with her/his transfers data.",
pathFormatted: "req_-get--user-is-r-f03f4",
stats: {
    "name": "[GET] User is retrieved with her/his transfers data.",
    "numberOfRequests": {
        "total": "19082",
        "ok": "19076",
        "ko": "6"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "2004"
    },
    "maxResponseTime": {
        "total": "60005",
        "ok": "58917",
        "ko": "60005"
    },
    "meanResponseTime": {
        "total": "15847",
        "ok": "15842",
        "ko": "31004"
    },
    "standardDeviation": {
        "total": "8145",
        "ok": "8125",
        "ko": "28999"
    },
    "percentiles1": {
        "total": "15906",
        "ok": "15906",
        "ko": "31003"
    },
    "percentiles2": {
        "total": "19389",
        "ok": "19391",
        "ko": "60002"
    },
    "percentiles3": {
        "total": "30657",
        "ok": "30648",
        "ko": "60005"
    },
    "percentiles4": {
        "total": "36951",
        "ok": "36947",
        "ko": "60005"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 508,
    "percentage": 3
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 33,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 18535,
    "percentage": 97
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 6,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "17.253",
        "ok": "17.248",
        "ko": "0.005"
    }
}
    },"req_-put--user-upda-c8c46": {
        type: "REQUEST",
        name: "[PUT] User updates with her/his own data.",
path: "[PUT] User updates with her/his own data.",
pathFormatted: "req_-put--user-upda-c8c46",
stats: {
    "name": "[PUT] User updates with her/his own data.",
    "numberOfRequests": {
        "total": "19082",
        "ok": "19075",
        "ko": "7"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "2002"
    },
    "maxResponseTime": {
        "total": "60001",
        "ok": "55557",
        "ko": "60001"
    },
    "meanResponseTime": {
        "total": "15278",
        "ok": "15280",
        "ko": "10463"
    },
    "standardDeviation": {
        "total": "8490",
        "ok": "8483",
        "ko": "20228"
    },
    "percentiles1": {
        "total": "15483",
        "ok": "15485",
        "ko": "2004"
    },
    "percentiles2": {
        "total": "19356",
        "ok": "19358",
        "ko": "2615"
    },
    "percentiles3": {
        "total": "30053",
        "ok": "30042",
        "ko": "42954"
    },
    "percentiles4": {
        "total": "37740",
        "ok": "37725",
        "ko": "56592"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 845,
    "percentage": 4
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 186,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 18044,
    "percentage": 95
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 7,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "17.253",
        "ok": "17.247",
        "ko": "0.006"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
