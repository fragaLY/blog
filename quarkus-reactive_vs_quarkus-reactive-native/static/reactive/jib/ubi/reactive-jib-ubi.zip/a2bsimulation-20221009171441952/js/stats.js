var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "661502",
        "ok": "541142",
        "ko": "120360"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "1",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "25433",
        "ok": "25433",
        "ko": "25323"
    },
    "meanResponseTime": {
        "total": "13305",
        "ok": "15551",
        "ko": "3207"
    },
    "standardDeviation": {
        "total": "6797",
        "ok": "4341",
        "ko": "6676"
    },
    "percentiles1": {
        "total": "15997",
        "ok": "16243",
        "ko": "0"
    },
    "percentiles2": {
        "total": "16970",
        "ok": "17260",
        "ko": "1"
    },
    "percentiles3": {
        "total": "20170",
        "ok": "20465",
        "ko": "17617"
    },
    "percentiles4": {
        "total": "24458",
        "ok": "24539",
        "ko": "22804"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 9543,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 1025,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 530574,
    "percentage": 80
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 120360,
    "percentage": 18
},
    "meanNumberOfRequestsPerSecond": {
        "total": "593.275",
        "ok": "485.329",
        "ko": "107.946"
    }
},
contents: {
"req_-get--the-list--c0b76": {
        type: "REQUEST",
        name: "[GET] The list of available countries is presented.",
path: "[GET] The list of available countries is presented.",
pathFormatted: "req_-get--the-list--c0b76",
stats: {
    "name": "[GET] The list of available countries is presented.",
    "numberOfRequests": {
        "total": "150559",
        "ok": "53867",
        "ko": "96692"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "4",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "25406",
        "ok": "25406",
        "ko": "1001"
    },
    "meanResponseTime": {
        "total": "5503",
        "ok": "15380",
        "ko": "1"
    },
    "standardDeviation": {
        "total": "7831",
        "ok": "4418",
        "ko": "15"
    },
    "percentiles1": {
        "total": "0",
        "ok": "16248",
        "ko": "0"
    },
    "percentiles2": {
        "total": "15611",
        "ok": "17203",
        "ko": "0"
    },
    "percentiles3": {
        "total": "18181",
        "ok": "20201",
        "ko": "1"
    },
    "percentiles4": {
        "total": "21881",
        "ok": "24325",
        "ko": "2"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1003,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 153,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 52711,
    "percentage": 35
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 96692,
    "percentage": 64
},
    "meanNumberOfRequestsPerSecond": {
        "total": "135.03",
        "ok": "48.311",
        "ko": "86.719"
    }
}
    },"req_-get--the-list--3525d": {
        type: "REQUEST",
        name: "[GET] The list of available cities is presented.",
path: "[GET] The list of available cities is presented.",
pathFormatted: "req_-get--the-list--3525d",
stats: {
    "name": "[GET] The list of available cities is presented.",
    "numberOfRequests": {
        "total": "107734",
        "ok": "107734",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "25358",
        "ok": "25358",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "15918",
        "ok": "15918",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3943",
        "ok": "3943",
        "ko": "-"
    },
    "percentiles1": {
        "total": "16316",
        "ok": "16318",
        "ko": "-"
    },
    "percentiles2": {
        "total": "17469",
        "ok": "17465",
        "ko": "-"
    },
    "percentiles3": {
        "total": "20452",
        "ok": "20452",
        "ko": "-"
    },
    "percentiles4": {
        "total": "24636",
        "ok": "24636",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 968,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 209,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 106557,
    "percentage": 99
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "96.622",
        "ok": "96.622",
        "ko": "-"
    }
}
    },"req_-get--the-list--11d52": {
        type: "REQUEST",
        name: "[GET] The list of available origins is presented.",
path: "[GET] The list of available origins is presented.",
pathFormatted: "req_-get--the-list--11d52",
stats: {
    "name": "[GET] The list of available origins is presented.",
    "numberOfRequests": {
        "total": "53867",
        "ok": "53867",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "37",
        "ok": "37",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "25319",
        "ok": "25319",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "15923",
        "ok": "15923",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3851",
        "ok": "3851",
        "ko": "-"
    },
    "percentiles1": {
        "total": "16345",
        "ok": "16347",
        "ko": "-"
    },
    "percentiles2": {
        "total": "17530",
        "ok": "17531",
        "ko": "-"
    },
    "percentiles3": {
        "total": "20182",
        "ok": "20182",
        "ko": "-"
    },
    "percentiles4": {
        "total": "23884",
        "ok": "23884",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 528,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 118,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 53221,
    "percentage": 99
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "48.311",
        "ok": "48.311",
        "ko": "-"
    }
}
    },"req_-get--the-list--0dc40": {
        type: "REQUEST",
        name: "[GET] The list of available destinations is presented.",
path: "[GET] The list of available destinations is presented.",
pathFormatted: "req_-get--the-list--0dc40",
stats: {
    "name": "[GET] The list of available destinations is presented.",
    "numberOfRequests": {
        "total": "53867",
        "ok": "53867",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "296",
        "ok": "296",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "25321",
        "ok": "25321",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "16366",
        "ok": "16366",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3714",
        "ok": "3714",
        "ko": "-"
    },
    "percentiles1": {
        "total": "16421",
        "ok": "16416",
        "ko": "-"
    },
    "percentiles2": {
        "total": "17679",
        "ok": "17684",
        "ko": "-"
    },
    "percentiles3": {
        "total": "23278",
        "ok": "23279",
        "ko": "-"
    },
    "percentiles4": {
        "total": "24845",
        "ok": "24845",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 34,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 34,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 53799,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "48.311",
        "ok": "48.311",
        "ko": "-"
    }
}
    },"req_-get--the-list--8bddb": {
        type: "REQUEST",
        name: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
path: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
pathFormatted: "req_-get--the-list--8bddb",
stats: {
    "name": "[GET] The list of available transfers by selected origin, destination, and date is presented.",
    "numberOfRequests": {
        "total": "53867",
        "ok": "30204",
        "ko": "23663"
    },
    "minResponseTime": {
        "total": "1826",
        "ok": "1826",
        "ko": "2049"
    },
    "maxResponseTime": {
        "total": "25352",
        "ok": "25352",
        "ko": "25323"
    },
    "meanResponseTime": {
        "total": "16296",
        "ok": "16291",
        "ko": "16303"
    },
    "standardDeviation": {
        "total": "3619",
        "ok": "3611",
        "ko": "3629"
    },
    "percentiles1": {
        "total": "16416",
        "ok": "16417",
        "ko": "16408"
    },
    "percentiles2": {
        "total": "17649",
        "ok": "17646",
        "ko": "17662"
    },
    "percentiles3": {
        "total": "22814",
        "ok": "22789",
        "ko": "22837"
    },
    "percentiles4": {
        "total": "24856",
        "ok": "24844",
        "ko": "24866"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 30204,
    "percentage": 56
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 23663,
    "percentage": 44
},
    "meanNumberOfRequestsPerSecond": {
        "total": "48.311",
        "ok": "27.089",
        "ko": "21.222"
    }
}
    },"req_-post--the-tran-5ac29": {
        type: "REQUEST",
        name: "[POST] The transfer is booked in the system.",
path: "[POST] The transfer is booked in the system.",
pathFormatted: "req_-post--the-tran-5ac29",
stats: {
    "name": "[POST] The transfer is booked in the system.",
    "numberOfRequests": {
        "total": "30204",
        "ok": "30200",
        "ko": "4"
    },
    "minResponseTime": {
        "total": "3028",
        "ok": "3028",
        "ko": "5965"
    },
    "maxResponseTime": {
        "total": "25400",
        "ok": "25400",
        "ko": "18135"
    },
    "meanResponseTime": {
        "total": "16052",
        "ok": "16052",
        "ko": "14010"
    },
    "standardDeviation": {
        "total": "3705",
        "ok": "3705",
        "ko": "4729"
    },
    "percentiles1": {
        "total": "16324",
        "ok": "16327",
        "ko": "15971"
    },
    "percentiles2": {
        "total": "17505",
        "ok": "17504",
        "ko": "16589"
    },
    "percentiles3": {
        "total": "21477",
        "ok": "21478",
        "ko": "17826"
    },
    "percentiles4": {
        "total": "24725",
        "ok": "24726",
        "ko": "18073"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 30200,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 4,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "27.089",
        "ok": "27.085",
        "ko": "0.004"
    }
}
    },"req_-get--the-list--4f742": {
        type: "REQUEST",
        name: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
path: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
pathFormatted: "req_-get--the-list--4f742",
stats: {
    "name": "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
    "numberOfRequests": {
        "total": "30204",
        "ok": "30203",
        "ko": "1"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "2648",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "25338",
        "ok": "25338",
        "ko": "0"
    },
    "meanResponseTime": {
        "total": "15794",
        "ok": "15795",
        "ko": "0"
    },
    "standardDeviation": {
        "total": "3848",
        "ok": "3847",
        "ko": "0"
    },
    "percentiles1": {
        "total": "16272",
        "ok": "16270",
        "ko": "0"
    },
    "percentiles2": {
        "total": "17270",
        "ok": "17272",
        "ko": "0"
    },
    "percentiles3": {
        "total": "20668",
        "ok": "20668",
        "ko": "0"
    },
    "percentiles4": {
        "total": "24583",
        "ok": "24585",
        "ko": "0"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 30203,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 1,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "27.089",
        "ok": "27.088",
        "ko": "0.001"
    }
}
    },"req_-get--one-of-th-c14cc": {
        type: "REQUEST",
        name: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
path: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
pathFormatted: "req_-get--one-of-th-c14cc",
stats: {
    "name": "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
    "numberOfRequests": {
        "total": "30200",
        "ok": "30200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "427",
        "ok": "427",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "25349",
        "ok": "25349",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "15579",
        "ok": "15579",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4095",
        "ok": "4095",
        "ko": "-"
    },
    "percentiles1": {
        "total": "16266",
        "ok": "16268",
        "ko": "-"
    },
    "percentiles2": {
        "total": "17186",
        "ok": "17186",
        "ko": "-"
    },
    "percentiles3": {
        "total": "20326",
        "ok": "20324",
        "ko": "-"
    },
    "percentiles4": {
        "total": "24570",
        "ok": "24568",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 12,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 22,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 30166,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "27.085",
        "ok": "27.085",
        "ko": "-"
    }
}
    },"req_-put--any--book-143cf": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer description is updated.",
path: "[PUT] Any (BOOKED) transfer description is updated.",
pathFormatted: "req_-put--any--book-143cf",
stats: {
    "name": "[PUT] Any (BOOKED) transfer description is updated.",
    "numberOfRequests": {
        "total": "30200",
        "ok": "30200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "25363",
        "ok": "25363",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "15268",
        "ok": "15268",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4471",
        "ok": "4471",
        "ko": "-"
    },
    "percentiles1": {
        "total": "16190",
        "ok": "16190",
        "ko": "-"
    },
    "percentiles2": {
        "total": "17089",
        "ok": "17089",
        "ko": "-"
    },
    "percentiles3": {
        "total": "20191",
        "ok": "20192",
        "ko": "-"
    },
    "percentiles4": {
        "total": "24377",
        "ok": "24375",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 451,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 92,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 29657,
    "percentage": 98
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "27.085",
        "ok": "27.085",
        "ko": "-"
    }
}
    },"req_-put--any--book-bb16d": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
path: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
pathFormatted: "req_-put--any--book-bb16d",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
    "numberOfRequests": {
        "total": "30200",
        "ok": "30200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "25433",
        "ok": "25433",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14980",
        "ok": "14980",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4803",
        "ok": "4803",
        "ko": "-"
    },
    "percentiles1": {
        "total": "16140",
        "ok": "16137",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16974",
        "ok": "16974",
        "ko": "-"
    },
    "percentiles3": {
        "total": "20112",
        "ok": "20112",
        "ko": "-"
    },
    "percentiles4": {
        "total": "24231",
        "ok": "24231",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 937,
    "percentage": 3
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 97,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 29166,
    "percentage": 97
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "27.085",
        "ok": "27.085",
        "ko": "-"
    }
}
    },"req_-put--any--book-fdf7e": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
path: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
pathFormatted: "req_-put--any--book-fdf7e",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
    "numberOfRequests": {
        "total": "30200",
        "ok": "30200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "25360",
        "ok": "25360",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14634",
        "ok": "14634",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5107",
        "ok": "5107",
        "ko": "-"
    },
    "percentiles1": {
        "total": "16073",
        "ok": "16073",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16869",
        "ok": "16875",
        "ko": "-"
    },
    "percentiles3": {
        "total": "19936",
        "ok": "19936",
        "ko": "-"
    },
    "percentiles4": {
        "total": "24021",
        "ok": "24024",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1408,
    "percentage": 5
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 104,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 28688,
    "percentage": 95
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "27.085",
        "ok": "27.085",
        "ko": "-"
    }
}
    },"req_-get--user-is-r-f03f4": {
        type: "REQUEST",
        name: "[GET] User is retrieved with her/his transfers data.",
path: "[GET] User is retrieved with her/his transfers data.",
pathFormatted: "req_-get--user-is-r-f03f4",
stats: {
    "name": "[GET] User is retrieved with her/his transfers data.",
    "numberOfRequests": {
        "total": "30200",
        "ok": "30200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "25292",
        "ok": "25292",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14264",
        "ok": "14264",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5377",
        "ok": "5377",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15978",
        "ok": "15978",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16772",
        "ok": "16772",
        "ko": "-"
    },
    "percentiles3": {
        "total": "19691",
        "ok": "19691",
        "ko": "-"
    },
    "percentiles4": {
        "total": "23826",
        "ok": "23825",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1861,
    "percentage": 6
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 112,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 28227,
    "percentage": 93
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "27.085",
        "ok": "27.085",
        "ko": "-"
    }
}
    },"req_-put--user-upda-c8c46": {
        type: "REQUEST",
        name: "[PUT] User updates with her/his own data.",
path: "[PUT] User updates with her/his own data.",
pathFormatted: "req_-put--user-upda-c8c46",
stats: {
    "name": "[PUT] User updates with her/his own data.",
    "numberOfRequests": {
        "total": "30200",
        "ok": "30200",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "25319",
        "ok": "25319",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "13976",
        "ok": "13976",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5627",
        "ok": "5627",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15992",
        "ok": "15992",
        "ko": "-"
    },
    "percentiles2": {
        "total": "16748",
        "ok": "16748",
        "ko": "-"
    },
    "percentiles3": {
        "total": "19370",
        "ok": "19369",
        "ko": "-"
    },
    "percentiles4": {
        "total": "22799",
        "ok": "22798",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2341,
    "percentage": 8
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 84,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 27775,
    "percentage": 92
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "27.085",
        "ok": "27.085",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
