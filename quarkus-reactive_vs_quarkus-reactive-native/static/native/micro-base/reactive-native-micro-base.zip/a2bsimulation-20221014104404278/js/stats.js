var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "570959",
        "ok": "445872",
        "ko": "125087"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "1",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "36338",
        "ok": "36338",
        "ko": "36323"
    },
    "meanResponseTime": {
        "total": "15984",
        "ok": "19561",
        "ko": "3237"
    },
    "standardDeviation": {
        "total": "9537",
        "ok": "6406",
        "ko": "7794"
    },
    "percentiles1": {
        "total": "20080",
        "ok": "20804",
        "ko": "0"
    },
    "percentiles2": {
        "total": "22116",
        "ok": "22387",
        "ko": "1"
    },
    "percentiles3": {
        "total": "25637",
        "ok": "27644",
        "ko": "22312"
    },
    "percentiles4": {
        "total": "34768",
        "ok": "35173",
        "ko": "27578"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 9071,
    "percentage": 2
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 993,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 435808,
    "percentage": 76
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 125087,
    "percentage": 22
},
    "meanNumberOfRequestsPerSecond": {
        "total": "507.971",
        "ok": "396.683",
        "ko": "111.287"
    }
},
contents: {
"req_-get--the-list--c0b76": {
        type: "REQUEST",
        name: "[GET] The list of available countries is presented.",
path: "[GET] The list of available countries is presented.",
pathFormatted: "req_-get--the-list--c0b76",
stats: {
    "name": "[GET] The list of available countries is presented.",
    "numberOfRequests": {
        "total": "149924",
        "ok": "44459",
        "ko": "105465"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "3",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "36335",
        "ok": "36335",
        "ko": "446"
    },
    "meanResponseTime": {
        "total": "5629",
        "ok": "18982",
        "ko": "1"
    },
    "standardDeviation": {
        "total": "9328",
        "ok": "6321",
        "ko": "11"
    },
    "percentiles1": {
        "total": "0",
        "ok": "20522",
        "ko": "0"
    },
    "percentiles2": {
        "total": "13879",
        "ok": "22253",
        "ko": "0"
    },
    "percentiles3": {
        "total": "22600",
        "ok": "24677",
        "ko": "1"
    },
    "percentiles4": {
        "total": "26761",
        "ok": "33829",
        "ko": "1"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1102,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 71,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 43286,
    "percentage": 29
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 105465,
    "percentage": 70
},
    "meanNumberOfRequestsPerSecond": {
        "total": "133.384",
        "ok": "39.554",
        "ko": "93.83"
    }
}
    },"req_-get--the-list--3525d": {
        type: "REQUEST",
        name: "[GET] The list of available cities is presented.",
path: "[GET] The list of available cities is presented.",
pathFormatted: "req_-get--the-list--3525d",
stats: {
    "name": "[GET] The list of available cities is presented.",
    "numberOfRequests": {
        "total": "88918",
        "ok": "88918",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "36317",
        "ok": "36317",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "20358",
        "ok": "20358",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "6059",
        "ok": "6059",
        "ko": "-"
    },
    "percentiles1": {
        "total": "21266",
        "ok": "21261",
        "ko": "-"
    },
    "percentiles2": {
        "total": "22478",
        "ok": "22475",
        "ko": "-"
    },
    "percentiles3": {
        "total": "30847",
        "ok": "30846",
        "ko": "-"
    },
    "percentiles4": {
        "total": "35578",
        "ok": "35578",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1161,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 124,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 87633,
    "percentage": 99
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "79.109",
        "ok": "79.109",
        "ko": "-"
    }
}
    },"req_-get--the-list--11d52": {
        type: "REQUEST",
        name: "[GET] The list of available origins is presented.",
path: "[GET] The list of available origins is presented.",
pathFormatted: "req_-get--the-list--11d52",
stats: {
    "name": "[GET] The list of available origins is presented.",
    "numberOfRequests": {
        "total": "44459",
        "ok": "44459",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "8",
        "ok": "8",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "36331",
        "ok": "36331",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "20612",
        "ok": "20612",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "6261",
        "ok": "6261",
        "ko": "-"
    },
    "percentiles1": {
        "total": "21413",
        "ok": "21413",
        "ko": "-"
    },
    "percentiles2": {
        "total": "22541",
        "ok": "22542",
        "ko": "-"
    },
    "percentiles3": {
        "total": "32744",
        "ok": "32777",
        "ko": "-"
    },
    "percentiles4": {
        "total": "35997",
        "ok": "35997",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 658,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 59,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 43742,
    "percentage": 98
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "39.554",
        "ok": "39.554",
        "ko": "-"
    }
}
    },"req_-get--the-list--0dc40": {
        type: "REQUEST",
        name: "[GET] The list of available destinations is presented.",
path: "[GET] The list of available destinations is presented.",
pathFormatted: "req_-get--the-list--0dc40",
stats: {
    "name": "[GET] The list of available destinations is presented.",
    "numberOfRequests": {
        "total": "44459",
        "ok": "44459",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "380",
        "ok": "380",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "36319",
        "ok": "36319",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "20946",
        "ok": "20946",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5619",
        "ok": "5619",
        "ko": "-"
    },
    "percentiles1": {
        "total": "21443",
        "ok": "21443",
        "ko": "-"
    },
    "percentiles2": {
        "total": "22681",
        "ok": "22704",
        "ko": "-"
    },
    "percentiles3": {
        "total": "31388",
        "ok": "31388",
        "ko": "-"
    },
    "percentiles4": {
        "total": "35633",
        "ok": "35633",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 86,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 44,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 44329,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "39.554",
        "ok": "39.554",
        "ko": "-"
    }
}
    },"req_-get--the-list--8bddb": {
        type: "REQUEST",
        name: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
path: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
pathFormatted: "req_-get--the-list--8bddb",
stats: {
    "name": "[GET] The list of available transfers by selected origin, destination, and date is presented.",
    "numberOfRequests": {
        "total": "44459",
        "ok": "24847",
        "ko": "19612"
    },
    "minResponseTime": {
        "total": "1298",
        "ok": "1744",
        "ko": "1298"
    },
    "maxResponseTime": {
        "total": "36323",
        "ok": "36303",
        "ko": "36323"
    },
    "meanResponseTime": {
        "total": "20639",
        "ok": "20642",
        "ko": "20634"
    },
    "standardDeviation": {
        "total": "5375",
        "ok": "5412",
        "ko": "5326"
    },
    "percentiles1": {
        "total": "21333",
        "ok": "21340",
        "ko": "21330"
    },
    "percentiles2": {
        "total": "22603",
        "ok": "22612",
        "ko": "22591"
    },
    "percentiles3": {
        "total": "29230",
        "ok": "29250",
        "ko": "29175"
    },
    "percentiles4": {
        "total": "35560",
        "ok": "35592",
        "ko": "35364"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 24847,
    "percentage": 56
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 19612,
    "percentage": 44
},
    "meanNumberOfRequestsPerSecond": {
        "total": "39.554",
        "ok": "22.106",
        "ko": "17.448"
    }
}
    },"req_-post--the-tran-5ac29": {
        type: "REQUEST",
        name: "[POST] The transfer is booked in the system.",
path: "[POST] The transfer is booked in the system.",
pathFormatted: "req_-post--the-tran-5ac29",
stats: {
    "name": "[POST] The transfer is booked in the system.",
    "numberOfRequests": {
        "total": "24847",
        "ok": "24841",
        "ko": "6"
    },
    "minResponseTime": {
        "total": "2516",
        "ok": "2516",
        "ko": "11660"
    },
    "maxResponseTime": {
        "total": "36325",
        "ok": "36325",
        "ko": "33806"
    },
    "meanResponseTime": {
        "total": "20169",
        "ok": "20169",
        "ko": "21273"
    },
    "standardDeviation": {
        "total": "5466",
        "ok": "5465",
        "ko": "6794"
    },
    "percentiles1": {
        "total": "20845",
        "ok": "20842",
        "ko": "21738"
    },
    "percentiles2": {
        "total": "22492",
        "ok": "22493",
        "ko": "22301"
    },
    "percentiles3": {
        "total": "27627",
        "ok": "27642",
        "ko": "30975"
    },
    "percentiles4": {
        "total": "35179",
        "ok": "35179",
        "ko": "33240"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 24841,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 6,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "22.106",
        "ok": "22.101",
        "ko": "0.005"
    }
}
    },"req_-get--the-list--4f742": {
        type: "REQUEST",
        name: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
path: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
pathFormatted: "req_-get--the-list--4f742",
stats: {
    "name": "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
    "numberOfRequests": {
        "total": "24847",
        "ok": "24843",
        "ko": "4"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "1922",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "36328",
        "ok": "36328",
        "ko": "1"
    },
    "meanResponseTime": {
        "total": "19807",
        "ok": "19810",
        "ko": "0"
    },
    "standardDeviation": {
        "total": "5645",
        "ok": "5640",
        "ko": "0"
    },
    "percentiles1": {
        "total": "20877",
        "ok": "20874",
        "ko": "0"
    },
    "percentiles2": {
        "total": "22393",
        "ok": "22390",
        "ko": "0"
    },
    "percentiles3": {
        "total": "25617",
        "ok": "25617",
        "ko": "1"
    },
    "percentiles4": {
        "total": "34472",
        "ok": "34442",
        "ko": "1"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 24843,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 4,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "22.106",
        "ok": "22.102",
        "ko": "0.004"
    }
}
    },"req_-get--one-of-th-c14cc": {
        type: "REQUEST",
        name: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
path: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
pathFormatted: "req_-get--one-of-th-c14cc",
stats: {
    "name": "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
    "numberOfRequests": {
        "total": "24841",
        "ok": "24841",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "382",
        "ok": "382",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "36324",
        "ok": "36324",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "19473",
        "ok": "19473",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5967",
        "ok": "5967",
        "ko": "-"
    },
    "percentiles1": {
        "total": "21150",
        "ok": "21150",
        "ko": "-"
    },
    "percentiles2": {
        "total": "22287",
        "ok": "22288",
        "ko": "-"
    },
    "percentiles3": {
        "total": "24710",
        "ok": "24710",
        "ko": "-"
    },
    "percentiles4": {
        "total": "34188",
        "ok": "34188",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 26,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 41,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 24774,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "22.101",
        "ok": "22.101",
        "ko": "-"
    }
}
    },"req_-put--any--book-143cf": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer description is updated.",
path: "[PUT] Any (BOOKED) transfer description is updated.",
pathFormatted: "req_-put--any--book-143cf",
stats: {
    "name": "[PUT] Any (BOOKED) transfer description is updated.",
    "numberOfRequests": {
        "total": "24841",
        "ok": "24841",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "36305",
        "ok": "36305",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "18965",
        "ok": "18965",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "6400",
        "ok": "6400",
        "ko": "-"
    },
    "percentiles1": {
        "total": "20777",
        "ok": "20777",
        "ko": "-"
    },
    "percentiles2": {
        "total": "22199",
        "ok": "22198",
        "ko": "-"
    },
    "percentiles3": {
        "total": "24445",
        "ok": "24447",
        "ko": "-"
    },
    "percentiles4": {
        "total": "33091",
        "ok": "33091",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 341,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 101,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 24399,
    "percentage": 98
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "22.101",
        "ok": "22.101",
        "ko": "-"
    }
}
    },"req_-put--any--book-bb16d": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
path: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
pathFormatted: "req_-put--any--book-bb16d",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
    "numberOfRequests": {
        "total": "24841",
        "ok": "24841",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "36338",
        "ok": "36338",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "18484",
        "ok": "18484",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "6768",
        "ok": "6768",
        "ko": "-"
    },
    "percentiles1": {
        "total": "20504",
        "ok": "20505",
        "ko": "-"
    },
    "percentiles2": {
        "total": "22132",
        "ok": "22136",
        "ko": "-"
    },
    "percentiles3": {
        "total": "24176",
        "ok": "24176",
        "ko": "-"
    },
    "percentiles4": {
        "total": "32835",
        "ok": "32834",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 664,
    "percentage": 3
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 95,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 24082,
    "percentage": 97
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "22.101",
        "ok": "22.101",
        "ko": "-"
    }
}
    },"req_-put--any--book-fdf7e": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
path: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
pathFormatted: "req_-put--any--book-fdf7e",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
    "numberOfRequests": {
        "total": "24841",
        "ok": "24841",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "36315",
        "ok": "36315",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "17908",
        "ok": "17908",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "7119",
        "ok": "7119",
        "ko": "-"
    },
    "percentiles1": {
        "total": "20128",
        "ok": "20130",
        "ko": "-"
    },
    "percentiles2": {
        "total": "21978",
        "ok": "21978",
        "ko": "-"
    },
    "percentiles3": {
        "total": "23884",
        "ok": "23884",
        "ko": "-"
    },
    "percentiles4": {
        "total": "31689",
        "ok": "31711",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1123,
    "percentage": 5
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 169,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 23549,
    "percentage": 95
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "22.101",
        "ok": "22.101",
        "ko": "-"
    }
}
    },"req_-get--user-is-r-f03f4": {
        type: "REQUEST",
        name: "[GET] User is retrieved with her/his transfers data.",
path: "[GET] User is retrieved with her/his transfers data.",
pathFormatted: "req_-get--user-is-r-f03f4",
stats: {
    "name": "[GET] User is retrieved with her/his transfers data.",
    "numberOfRequests": {
        "total": "24841",
        "ok": "24841",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "36304",
        "ok": "36304",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "17394",
        "ok": "17394",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "7463",
        "ok": "7463",
        "ko": "-"
    },
    "percentiles1": {
        "total": "19907",
        "ok": "19907",
        "ko": "-"
    },
    "percentiles2": {
        "total": "21896",
        "ok": "21896",
        "ko": "-"
    },
    "percentiles3": {
        "total": "23656",
        "ok": "23656",
        "ko": "-"
    },
    "percentiles4": {
        "total": "31145",
        "ok": "31149",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1693,
    "percentage": 7
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 140,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 23008,
    "percentage": 93
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "22.101",
        "ok": "22.101",
        "ko": "-"
    }
}
    },"req_-put--user-upda-c8c46": {
        type: "REQUEST",
        name: "[PUT] User updates with her/his own data.",
path: "[PUT] User updates with her/his own data.",
pathFormatted: "req_-put--user-upda-c8c46",
stats: {
    "name": "[PUT] User updates with her/his own data.",
    "numberOfRequests": {
        "total": "24841",
        "ok": "24841",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "36327",
        "ok": "36327",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "17019",
        "ok": "17019",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "7877",
        "ok": "7877",
        "ko": "-"
    },
    "percentiles1": {
        "total": "19944",
        "ok": "19945",
        "ko": "-"
    },
    "percentiles2": {
        "total": "21971",
        "ok": "21971",
        "ko": "-"
    },
    "percentiles3": {
        "total": "23640",
        "ok": "23634",
        "ko": "-"
    },
    "percentiles4": {
        "total": "31127",
        "ok": "31133",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2217,
    "percentage": 9
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 149,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 22475,
    "percentage": 90
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "22.101",
        "ok": "22.101",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
