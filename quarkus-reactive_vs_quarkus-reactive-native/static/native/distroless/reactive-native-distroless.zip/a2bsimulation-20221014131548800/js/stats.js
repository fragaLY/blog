var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "546371",
        "ok": "419297",
        "ko": "127074"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "1",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "39009",
        "ok": "39009",
        "ko": "37550"
    },
    "meanResponseTime": {
        "total": "17281",
        "ok": "21516",
        "ko": "3304"
    },
    "standardDeviation": {
        "total": "10498",
        "ok": "6764",
        "ko": "8265"
    },
    "percentiles1": {
        "total": "21345",
        "ok": "22388",
        "ko": "0"
    },
    "percentiles2": {
        "total": "24020",
        "ok": "24852",
        "ko": "1"
    },
    "percentiles3": {
        "total": "30156",
        "ok": "31153",
        "ko": "24445"
    },
    "percentiles4": {
        "total": "35098",
        "ok": "35378",
        "ko": "29658"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 9666,
    "percentage": 2
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 874,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 408757,
    "percentage": 75
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 127074,
    "percentage": 23
},
    "meanNumberOfRequestsPerSecond": {
        "total": "473.458",
        "ok": "363.342",
        "ko": "110.116"
    }
},
contents: {
"req_-get--the-list--c0b76": {
        type: "REQUEST",
        name: "[GET] The list of available countries is presented.",
path: "[GET] The list of available countries is presented.",
pathFormatted: "req_-get--the-list--c0b76",
stats: {
    "name": "[GET] The list of available countries is presented.",
    "numberOfRequests": {
        "total": "150446",
        "ok": "41781",
        "ko": "108665"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "2",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "39009",
        "ok": "39009",
        "ko": "329"
    },
    "meanResponseTime": {
        "total": "5838",
        "ok": "21019",
        "ko": "0"
    },
    "standardDeviation": {
        "total": "10095",
        "ok": "6917",
        "ko": "5"
    },
    "percentiles1": {
        "total": "0",
        "ok": "22100",
        "ko": "0"
    },
    "percentiles2": {
        "total": "10430",
        "ok": "24023",
        "ko": "0"
    },
    "percentiles3": {
        "total": "25591",
        "ok": "31149",
        "ko": "1"
    },
    "percentiles4": {
        "total": "32286",
        "ok": "35560",
        "ko": "1"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 888,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 134,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 40759,
    "percentage": 27
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 108665,
    "percentage": 72
},
    "meanNumberOfRequestsPerSecond": {
        "total": "130.369",
        "ok": "36.205",
        "ko": "94.164"
    }
}
    },"req_-get--the-list--3525d": {
        type: "REQUEST",
        name: "[GET] The list of available cities is presented.",
path: "[GET] The list of available cities is presented.",
pathFormatted: "req_-get--the-list--3525d",
stats: {
    "name": "[GET] The list of available cities is presented.",
    "numberOfRequests": {
        "total": "83562",
        "ok": "83562",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "37846",
        "ok": "37846",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "22373",
        "ok": "22373",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "6133",
        "ok": "6133",
        "ko": "-"
    },
    "percentiles1": {
        "total": "22687",
        "ok": "22685",
        "ko": "-"
    },
    "percentiles2": {
        "total": "25230",
        "ok": "25225",
        "ko": "-"
    },
    "percentiles3": {
        "total": "31651",
        "ok": "31656",
        "ko": "-"
    },
    "percentiles4": {
        "total": "35580",
        "ok": "35580",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 787,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 238,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 82537,
    "percentage": 99
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "72.411",
        "ok": "72.411",
        "ko": "-"
    }
}
    },"req_-get--the-list--11d52": {
        type: "REQUEST",
        name: "[GET] The list of available origins is presented.",
path: "[GET] The list of available origins is presented.",
pathFormatted: "req_-get--the-list--11d52",
stats: {
    "name": "[GET] The list of available origins is presented.",
    "numberOfRequests": {
        "total": "41781",
        "ok": "41781",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "37843",
        "ok": "37843",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "22509",
        "ok": "22509",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "6152",
        "ok": "6152",
        "ko": "-"
    },
    "percentiles1": {
        "total": "22777",
        "ok": "22779",
        "ko": "-"
    },
    "percentiles2": {
        "total": "25375",
        "ok": "25374",
        "ko": "-"
    },
    "percentiles3": {
        "total": "32176",
        "ok": "32176",
        "ko": "-"
    },
    "percentiles4": {
        "total": "35733",
        "ok": "35733",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 471,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 103,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 41207,
    "percentage": 99
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "36.205",
        "ok": "36.205",
        "ko": "-"
    }
}
    },"req_-get--the-list--0dc40": {
        type: "REQUEST",
        name: "[GET] The list of available destinations is presented.",
path: "[GET] The list of available destinations is presented.",
pathFormatted: "req_-get--the-list--0dc40",
stats: {
    "name": "[GET] The list of available destinations is presented.",
    "numberOfRequests": {
        "total": "41781",
        "ok": "41781",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "339",
        "ok": "339",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "37861",
        "ok": "37861",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "23062",
        "ok": "23062",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5565",
        "ok": "5565",
        "ko": "-"
    },
    "percentiles1": {
        "total": "23226",
        "ok": "23247",
        "ko": "-"
    },
    "percentiles2": {
        "total": "26268",
        "ok": "26276",
        "ko": "-"
    },
    "percentiles3": {
        "total": "31619",
        "ok": "31619",
        "ko": "-"
    },
    "percentiles4": {
        "total": "35315",
        "ok": "35321",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 8,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 30,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 41743,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "36.205",
        "ok": "36.205",
        "ko": "-"
    }
}
    },"req_-get--the-list--8bddb": {
        type: "REQUEST",
        name: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
path: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
pathFormatted: "req_-get--the-list--8bddb",
stats: {
    "name": "[GET] The list of available transfers by selected origin, destination, and date is presented.",
    "numberOfRequests": {
        "total": "41781",
        "ok": "23382",
        "ko": "18399"
    },
    "minResponseTime": {
        "total": "1776",
        "ok": "1960",
        "ko": "1776"
    },
    "maxResponseTime": {
        "total": "37815",
        "ok": "37815",
        "ko": "37550"
    },
    "meanResponseTime": {
        "total": "22821",
        "ok": "22827",
        "ko": "22813"
    },
    "standardDeviation": {
        "total": "5176",
        "ok": "5190",
        "ko": "5158"
    },
    "percentiles1": {
        "total": "23055",
        "ok": "23046",
        "ko": "23057"
    },
    "percentiles2": {
        "total": "25785",
        "ok": "25789",
        "ko": "25785"
    },
    "percentiles3": {
        "total": "31022",
        "ok": "31112",
        "ko": "30789"
    },
    "percentiles4": {
        "total": "35049",
        "ok": "35045",
        "ko": "35033"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 23382,
    "percentage": 56
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 18399,
    "percentage": 44
},
    "meanNumberOfRequestsPerSecond": {
        "total": "36.205",
        "ok": "20.262",
        "ko": "15.944"
    }
}
    },"req_-post--the-tran-5ac29": {
        type: "REQUEST",
        name: "[POST] The transfer is booked in the system.",
path: "[POST] The transfer is booked in the system.",
pathFormatted: "req_-post--the-tran-5ac29",
stats: {
    "name": "[POST] The transfer is booked in the system.",
    "numberOfRequests": {
        "total": "23382",
        "ok": "23376",
        "ko": "6"
    },
    "minResponseTime": {
        "total": "2606",
        "ok": "2606",
        "ko": "13984"
    },
    "maxResponseTime": {
        "total": "38323",
        "ok": "38323",
        "ko": "27448"
    },
    "meanResponseTime": {
        "total": "22089",
        "ok": "22089",
        "ko": "23105"
    },
    "standardDeviation": {
        "total": "5160",
        "ok": "5161",
        "ko": "4261"
    },
    "percentiles1": {
        "total": "22450",
        "ok": "22451",
        "ko": "24490"
    },
    "percentiles2": {
        "total": "24838",
        "ok": "24839",
        "ko": "24769"
    },
    "percentiles3": {
        "total": "30196",
        "ok": "30182",
        "ko": "26781"
    },
    "percentiles4": {
        "total": "34490",
        "ok": "34490",
        "ko": "27315"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 23376,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 6,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "20.262",
        "ok": "20.256",
        "ko": "0.005"
    }
}
    },"req_-get--the-list--4f742": {
        type: "REQUEST",
        name: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
path: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
pathFormatted: "req_-get--the-list--4f742",
stats: {
    "name": "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
    "numberOfRequests": {
        "total": "23382",
        "ok": "23378",
        "ko": "4"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "4078",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "37852",
        "ok": "37852",
        "ko": "1"
    },
    "meanResponseTime": {
        "total": "21720",
        "ok": "21724",
        "ko": "1"
    },
    "standardDeviation": {
        "total": "5560",
        "ok": "5553",
        "ko": "1"
    },
    "percentiles1": {
        "total": "22154",
        "ok": "22159",
        "ko": "1"
    },
    "percentiles2": {
        "total": "24456",
        "ok": "24456",
        "ko": "1"
    },
    "percentiles3": {
        "total": "30326",
        "ok": "30326",
        "ko": "1"
    },
    "percentiles4": {
        "total": "35115",
        "ok": "35113",
        "ko": "1"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 23378,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 4,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "20.262",
        "ok": "20.258",
        "ko": "0.003"
    }
}
    },"req_-get--one-of-th-c14cc": {
        type: "REQUEST",
        name: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
path: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
pathFormatted: "req_-get--one-of-th-c14cc",
stats: {
    "name": "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
    "numberOfRequests": {
        "total": "23376",
        "ok": "23376",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1340",
        "ok": "1340",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "37816",
        "ok": "37816",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "21550",
        "ok": "21550",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "6326",
        "ok": "6326",
        "ko": "-"
    },
    "percentiles1": {
        "total": "22297",
        "ok": "22298",
        "ko": "-"
    },
    "percentiles2": {
        "total": "24564",
        "ok": "24564",
        "ko": "-"
    },
    "percentiles3": {
        "total": "31267",
        "ok": "31273",
        "ko": "-"
    },
    "percentiles4": {
        "total": "35852",
        "ok": "35866",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 23376,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "20.256",
        "ok": "20.256",
        "ko": "-"
    }
}
    },"req_-put--any--book-143cf": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer description is updated.",
path: "[PUT] Any (BOOKED) transfer description is updated.",
pathFormatted: "req_-put--any--book-143cf",
stats: {
    "name": "[PUT] Any (BOOKED) transfer description is updated.",
    "numberOfRequests": {
        "total": "23376",
        "ok": "23376",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "38420",
        "ok": "38420",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "21082",
        "ok": "21082",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "7154",
        "ok": "7154",
        "ko": "-"
    },
    "percentiles1": {
        "total": "22196",
        "ok": "22190",
        "ko": "-"
    },
    "percentiles2": {
        "total": "24538",
        "ok": "24538",
        "ko": "-"
    },
    "percentiles3": {
        "total": "31575",
        "ok": "31587",
        "ko": "-"
    },
    "percentiles4": {
        "total": "35705",
        "ok": "35708",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 352,
    "percentage": 2
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 85,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 22939,
    "percentage": 98
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "20.256",
        "ok": "20.256",
        "ko": "-"
    }
}
    },"req_-put--any--book-bb16d": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
path: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
pathFormatted: "req_-put--any--book-bb16d",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
    "numberOfRequests": {
        "total": "23376",
        "ok": "23376",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "38599",
        "ok": "38599",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "20442",
        "ok": "20442",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "7700",
        "ok": "7700",
        "ko": "-"
    },
    "percentiles1": {
        "total": "21977",
        "ok": "21966",
        "ko": "-"
    },
    "percentiles2": {
        "total": "24324",
        "ok": "24322",
        "ko": "-"
    },
    "percentiles3": {
        "total": "31181",
        "ok": "31179",
        "ko": "-"
    },
    "percentiles4": {
        "total": "35700",
        "ok": "35701",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 887,
    "percentage": 4
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 91,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 22398,
    "percentage": 96
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "20.256",
        "ok": "20.256",
        "ko": "-"
    }
}
    },"req_-put--any--book-fdf7e": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
path: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
pathFormatted: "req_-put--any--book-fdf7e",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
    "numberOfRequests": {
        "total": "23376",
        "ok": "23376",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "38299",
        "ok": "38299",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "19671",
        "ok": "19671",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "8019",
        "ok": "8019",
        "ko": "-"
    },
    "percentiles1": {
        "total": "21748",
        "ok": "21754",
        "ko": "-"
    },
    "percentiles2": {
        "total": "23994",
        "ok": "23995",
        "ko": "-"
    },
    "percentiles3": {
        "total": "29522",
        "ok": "29520",
        "ko": "-"
    },
    "percentiles4": {
        "total": "35194",
        "ok": "35194",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1563,
    "percentage": 7
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 77,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 21736,
    "percentage": 93
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "20.256",
        "ok": "20.256",
        "ko": "-"
    }
}
    },"req_-get--user-is-r-f03f4": {
        type: "REQUEST",
        name: "[GET] User is retrieved with her/his transfers data.",
path: "[GET] User is retrieved with her/his transfers data.",
pathFormatted: "req_-get--user-is-r-f03f4",
stats: {
    "name": "[GET] User is retrieved with her/his transfers data.",
    "numberOfRequests": {
        "total": "23376",
        "ok": "23376",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "37391",
        "ok": "37391",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "18957",
        "ok": "18957",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "8360",
        "ok": "8360",
        "ko": "-"
    },
    "percentiles1": {
        "total": "21058",
        "ok": "21057",
        "ko": "-"
    },
    "percentiles2": {
        "total": "23586",
        "ok": "23588",
        "ko": "-"
    },
    "percentiles3": {
        "total": "29427",
        "ok": "29423",
        "ko": "-"
    },
    "percentiles4": {
        "total": "34513",
        "ok": "34525",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2132,
    "percentage": 9
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 75,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 21169,
    "percentage": 91
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "20.256",
        "ok": "20.256",
        "ko": "-"
    }
}
    },"req_-put--user-upda-c8c46": {
        type: "REQUEST",
        name: "[PUT] User updates with her/his own data.",
path: "[PUT] User updates with her/his own data.",
pathFormatted: "req_-put--user-upda-c8c46",
stats: {
    "name": "[PUT] User updates with her/his own data.",
    "numberOfRequests": {
        "total": "23376",
        "ok": "23376",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "38347",
        "ok": "38347",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "18595",
        "ok": "18595",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "8811",
        "ok": "8811",
        "ko": "-"
    },
    "percentiles1": {
        "total": "21257",
        "ok": "21257",
        "ko": "-"
    },
    "percentiles2": {
        "total": "23394",
        "ok": "23392",
        "ko": "-"
    },
    "percentiles3": {
        "total": "30028",
        "ok": "30028",
        "ko": "-"
    },
    "percentiles4": {
        "total": "34994",
        "ok": "34994",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2578,
    "percentage": 11
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 41,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 20757,
    "percentage": 89
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "20.256",
        "ok": "20.256",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
