var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "523534",
        "ok": "395079",
        "ko": "128455"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "1",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "44925",
        "ok": "44925",
        "ko": "44694"
    },
    "meanResponseTime": {
        "total": "18485",
        "ok": "23382",
        "ko": "3425"
    },
    "standardDeviation": {
        "total": "12016",
        "ok": "8202",
        "ko": "9002"
    },
    "percentiles1": {
        "total": "22244",
        "ok": "23496",
        "ko": "0"
    },
    "percentiles2": {
        "total": "25396",
        "ok": "27051",
        "ko": "1"
    },
    "percentiles3": {
        "total": "35777",
        "ok": "37152",
        "ko": "25739"
    },
    "percentiles4": {
        "total": "42880",
        "ok": "43262",
        "ko": "35965"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 7337,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 936,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 386806,
    "percentage": 74
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 128455,
    "percentage": 25
},
    "meanNumberOfRequestsPerSecond": {
        "total": "448.231",
        "ok": "338.253",
        "ko": "109.979"
    }
},
contents: {
"req_-get--the-list--c0b76": {
        type: "REQUEST",
        name: "[GET] The list of available countries is presented.",
path: "[GET] The list of available countries is presented.",
pathFormatted: "req_-get--the-list--c0b76",
stats: {
    "name": "[GET] The list of available countries is presented.",
    "numberOfRequests": {
        "total": "150466",
        "ok": "39388",
        "ko": "111078"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "3",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "44805",
        "ok": "44805",
        "ko": "279"
    },
    "meanResponseTime": {
        "total": "5919",
        "ok": "22611",
        "ko": "0"
    },
    "standardDeviation": {
        "total": "10674",
        "ok": "7603",
        "ko": "5"
    },
    "percentiles1": {
        "total": "0",
        "ok": "22941",
        "ko": "0"
    },
    "percentiles2": {
        "total": "5477",
        "ok": "25629",
        "ko": "0"
    },
    "percentiles3": {
        "total": "27821",
        "ok": "33441",
        "ko": "1"
    },
    "percentiles4": {
        "total": "35642",
        "ok": "43281",
        "ko": "1"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 431,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 28,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 38929,
    "percentage": 26
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 111078,
    "percentage": 74
},
    "meanNumberOfRequestsPerSecond": {
        "total": "128.824",
        "ok": "33.723",
        "ko": "95.101"
    }
}
    },"req_-get--the-list--3525d": {
        type: "REQUEST",
        name: "[GET] The list of available cities is presented.",
path: "[GET] The list of available cities is presented.",
pathFormatted: "req_-get--the-list--3525d",
stats: {
    "name": "[GET] The list of available cities is presented.",
    "numberOfRequests": {
        "total": "78776",
        "ok": "78776",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "44640",
        "ok": "44640",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "24395",
        "ok": "24395",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "7001",
        "ok": "7001",
        "ko": "-"
    },
    "percentiles1": {
        "total": "23665",
        "ok": "23620",
        "ko": "-"
    },
    "percentiles2": {
        "total": "28142",
        "ok": "28145",
        "ko": "-"
    },
    "percentiles3": {
        "total": "37069",
        "ok": "37068",
        "ko": "-"
    },
    "percentiles4": {
        "total": "43193",
        "ok": "43193",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 202,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 27,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 78547,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "67.445",
        "ok": "67.445",
        "ko": "-"
    }
}
    },"req_-get--the-list--11d52": {
        type: "REQUEST",
        name: "[GET] The list of available origins is presented.",
path: "[GET] The list of available origins is presented.",
pathFormatted: "req_-get--the-list--11d52",
stats: {
    "name": "[GET] The list of available origins is presented.",
    "numberOfRequests": {
        "total": "39388",
        "ok": "39388",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "44666",
        "ok": "44666",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "24766",
        "ok": "24766",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "7014",
        "ok": "7014",
        "ko": "-"
    },
    "percentiles1": {
        "total": "23848",
        "ok": "23850",
        "ko": "-"
    },
    "percentiles2": {
        "total": "27759",
        "ok": "27744",
        "ko": "-"
    },
    "percentiles3": {
        "total": "37855",
        "ok": "37855",
        "ko": "-"
    },
    "percentiles4": {
        "total": "42724",
        "ok": "42724",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 38,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 14,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 39336,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "33.723",
        "ok": "33.723",
        "ko": "-"
    }
}
    },"req_-get--the-list--0dc40": {
        type: "REQUEST",
        name: "[GET] The list of available destinations is presented.",
path: "[GET] The list of available destinations is presented.",
pathFormatted: "req_-get--the-list--0dc40",
stats: {
    "name": "[GET] The list of available destinations is presented.",
    "numberOfRequests": {
        "total": "39388",
        "ok": "39388",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2399",
        "ok": "2399",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "44703",
        "ok": "44703",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "25553",
        "ok": "25553",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "6566",
        "ok": "6566",
        "ko": "-"
    },
    "percentiles1": {
        "total": "24448",
        "ok": "24458",
        "ko": "-"
    },
    "percentiles2": {
        "total": "30142",
        "ok": "30144",
        "ko": "-"
    },
    "percentiles3": {
        "total": "37233",
        "ok": "37234",
        "ko": "-"
    },
    "percentiles4": {
        "total": "43837",
        "ok": "43821",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 39388,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "33.723",
        "ok": "33.723",
        "ko": "-"
    }
}
    },"req_-get--the-list--8bddb": {
        type: "REQUEST",
        name: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
path: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
pathFormatted: "req_-get--the-list--8bddb",
stats: {
    "name": "[GET] The list of available transfers by selected origin, destination, and date is presented.",
    "numberOfRequests": {
        "total": "39388",
        "ok": "22019",
        "ko": "17369"
    },
    "minResponseTime": {
        "total": "5084",
        "ok": "5286",
        "ko": "5084"
    },
    "maxResponseTime": {
        "total": "44694",
        "ok": "44625",
        "ko": "44694"
    },
    "meanResponseTime": {
        "total": "25257",
        "ok": "25204",
        "ko": "25324"
    },
    "standardDeviation": {
        "total": "6713",
        "ok": "6740",
        "ko": "6679"
    },
    "percentiles1": {
        "total": "24304",
        "ok": "24268",
        "ko": "24349"
    },
    "percentiles2": {
        "total": "29635",
        "ok": "29619",
        "ko": "29626"
    },
    "percentiles3": {
        "total": "37819",
        "ok": "37788",
        "ko": "37841"
    },
    "percentiles4": {
        "total": "43208",
        "ok": "43195",
        "ko": "43235"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 22019,
    "percentage": 56
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 17369,
    "percentage": 44
},
    "meanNumberOfRequestsPerSecond": {
        "total": "33.723",
        "ok": "18.852",
        "ko": "14.871"
    }
}
    },"req_-post--the-tran-5ac29": {
        type: "REQUEST",
        name: "[POST] The transfer is booked in the system.",
path: "[POST] The transfer is booked in the system.",
pathFormatted: "req_-post--the-tran-5ac29",
stats: {
    "name": "[POST] The transfer is booked in the system.",
    "numberOfRequests": {
        "total": "22019",
        "ok": "22015",
        "ko": "4"
    },
    "minResponseTime": {
        "total": "3787",
        "ok": "3787",
        "ko": "23075"
    },
    "maxResponseTime": {
        "total": "44910",
        "ok": "44910",
        "ko": "29188"
    },
    "meanResponseTime": {
        "total": "24285",
        "ok": "24285",
        "ko": "26052"
    },
    "standardDeviation": {
        "total": "7246",
        "ok": "7246",
        "ko": "2440"
    },
    "percentiles1": {
        "total": "23655",
        "ok": "23654",
        "ko": "25972"
    },
    "percentiles2": {
        "total": "27680",
        "ok": "27681",
        "ko": "27975"
    },
    "percentiles3": {
        "total": "37262",
        "ok": "37263",
        "ko": "28945"
    },
    "percentiles4": {
        "total": "44255",
        "ok": "44255",
        "ko": "29139"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 22015,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 4,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "18.852",
        "ok": "18.848",
        "ko": "0.003"
    }
}
    },"req_-get--the-list--4f742": {
        type: "REQUEST",
        name: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
path: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
pathFormatted: "req_-get--the-list--4f742",
stats: {
    "name": "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
    "numberOfRequests": {
        "total": "22019",
        "ok": "22015",
        "ko": "4"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "2252",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "44689",
        "ok": "44689",
        "ko": "0"
    },
    "meanResponseTime": {
        "total": "23750",
        "ok": "23755",
        "ko": "0"
    },
    "standardDeviation": {
        "total": "7593",
        "ok": "7586",
        "ko": "0"
    },
    "percentiles1": {
        "total": "23567",
        "ok": "23568",
        "ko": "0"
    },
    "percentiles2": {
        "total": "26790",
        "ok": "26798",
        "ko": "0"
    },
    "percentiles3": {
        "total": "36584",
        "ok": "36585",
        "ko": "0"
    },
    "percentiles4": {
        "total": "44124",
        "ok": "44124",
        "ko": "0"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 22015,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 4,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "18.852",
        "ok": "18.848",
        "ko": "0.003"
    }
}
    },"req_-get--one-of-th-c14cc": {
        type: "REQUEST",
        name: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
path: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
pathFormatted: "req_-get--one-of-th-c14cc",
stats: {
    "name": "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
    "numberOfRequests": {
        "total": "22015",
        "ok": "22015",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "502",
        "ok": "502",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "44704",
        "ok": "44704",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "23540",
        "ok": "23540",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "8391",
        "ok": "8391",
        "ko": "-"
    },
    "percentiles1": {
        "total": "23578",
        "ok": "23578",
        "ko": "-"
    },
    "percentiles2": {
        "total": "26300",
        "ok": "26303",
        "ko": "-"
    },
    "percentiles3": {
        "total": "37848",
        "ok": "37848",
        "ko": "-"
    },
    "percentiles4": {
        "total": "43241",
        "ok": "43243",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 3,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 34,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 21978,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "18.848",
        "ok": "18.848",
        "ko": "-"
    }
}
    },"req_-put--any--book-143cf": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer description is updated.",
path: "[PUT] Any (BOOKED) transfer description is updated.",
pathFormatted: "req_-put--any--book-143cf",
stats: {
    "name": "[PUT] Any (BOOKED) transfer description is updated.",
    "numberOfRequests": {
        "total": "22015",
        "ok": "22015",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "44864",
        "ok": "44864",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "22649",
        "ok": "22649",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "8966",
        "ok": "8966",
        "ko": "-"
    },
    "percentiles1": {
        "total": "23338",
        "ok": "23339",
        "ko": "-"
    },
    "percentiles2": {
        "total": "26190",
        "ok": "26186",
        "ko": "-"
    },
    "percentiles3": {
        "total": "37385",
        "ok": "37385",
        "ko": "-"
    },
    "percentiles4": {
        "total": "43169",
        "ok": "43170",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 444,
    "percentage": 2
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 193,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 21378,
    "percentage": 97
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "18.848",
        "ok": "18.848",
        "ko": "-"
    }
}
    },"req_-put--any--book-bb16d": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
path: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
pathFormatted: "req_-put--any--book-bb16d",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
    "numberOfRequests": {
        "total": "22015",
        "ok": "22015",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "44893",
        "ok": "44893",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "21948",
        "ok": "21948",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "9353",
        "ok": "9353",
        "ko": "-"
    },
    "percentiles1": {
        "total": "23502",
        "ok": "23502",
        "ko": "-"
    },
    "percentiles2": {
        "total": "25902",
        "ok": "25900",
        "ko": "-"
    },
    "percentiles3": {
        "total": "36883",
        "ok": "36886",
        "ko": "-"
    },
    "percentiles4": {
        "total": "40554",
        "ok": "40551",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 938,
    "percentage": 4
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 173,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 20904,
    "percentage": 95
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "18.848",
        "ok": "18.848",
        "ko": "-"
    }
}
    },"req_-put--any--book-fdf7e": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
path: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
pathFormatted: "req_-put--any--book-fdf7e",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
    "numberOfRequests": {
        "total": "22015",
        "ok": "22015",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "44775",
        "ok": "44775",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "21019",
        "ok": "21019",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "9775",
        "ok": "9775",
        "ko": "-"
    },
    "percentiles1": {
        "total": "22677",
        "ok": "22677",
        "ko": "-"
    },
    "percentiles2": {
        "total": "25417",
        "ok": "25419",
        "ko": "-"
    },
    "percentiles3": {
        "total": "35670",
        "ok": "35679",
        "ko": "-"
    },
    "percentiles4": {
        "total": "40398",
        "ok": "40397",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1349,
    "percentage": 6
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 133,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 20533,
    "percentage": 93
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "18.848",
        "ok": "18.848",
        "ko": "-"
    }
}
    },"req_-get--user-is-r-f03f4": {
        type: "REQUEST",
        name: "[GET] User is retrieved with her/his transfers data.",
path: "[GET] User is retrieved with her/his transfers data.",
pathFormatted: "req_-get--user-is-r-f03f4",
stats: {
    "name": "[GET] User is retrieved with her/his transfers data.",
    "numberOfRequests": {
        "total": "22015",
        "ok": "22015",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "44677",
        "ok": "44677",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "20160",
        "ok": "20160",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "10402",
        "ok": "10402",
        "ko": "-"
    },
    "percentiles1": {
        "total": "21978",
        "ok": "21978",
        "ko": "-"
    },
    "percentiles2": {
        "total": "25004",
        "ok": "25005",
        "ko": "-"
    },
    "percentiles3": {
        "total": "36778",
        "ok": "36763",
        "ko": "-"
    },
    "percentiles4": {
        "total": "44251",
        "ok": "44251",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1741,
    "percentage": 8
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 143,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 20131,
    "percentage": 91
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "18.848",
        "ok": "18.848",
        "ko": "-"
    }
}
    },"req_-put--user-upda-c8c46": {
        type: "REQUEST",
        name: "[PUT] User updates with her/his own data.",
path: "[PUT] User updates with her/his own data.",
pathFormatted: "req_-put--user-upda-c8c46",
stats: {
    "name": "[PUT] User updates with her/his own data.",
    "numberOfRequests": {
        "total": "22015",
        "ok": "22015",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "44925",
        "ok": "44925",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "19273",
        "ok": "19273",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "10460",
        "ok": "10460",
        "ko": "-"
    },
    "percentiles1": {
        "total": "21807",
        "ok": "21806",
        "ko": "-"
    },
    "percentiles2": {
        "total": "24307",
        "ok": "24306",
        "ko": "-"
    },
    "percentiles3": {
        "total": "33559",
        "ok": "33563",
        "ko": "-"
    },
    "percentiles4": {
        "total": "44120",
        "ok": "44120",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2191,
    "percentage": 10
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 191,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 19633,
    "percentage": 89
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "18.848",
        "ok": "18.848",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
