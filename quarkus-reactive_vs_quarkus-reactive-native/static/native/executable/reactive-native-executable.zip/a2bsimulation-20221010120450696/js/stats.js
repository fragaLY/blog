var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "768017",
        "ok": "654382",
        "ko": "113635"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "1",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "21016",
        "ok": "21016",
        "ko": "20948"
    },
    "meanResponseTime": {
        "total": "10682",
        "ok": "11994",
        "ko": "3123"
    },
    "standardDeviation": {
        "total": "5429",
        "ok": "4167",
        "ko": "5670"
    },
    "percentiles1": {
        "total": "13034",
        "ok": "13270",
        "ko": "0"
    },
    "percentiles2": {
        "total": "13779",
        "ok": "13851",
        "ko": "568"
    },
    "percentiles3": {
        "total": "16426",
        "ok": "16787",
        "ko": "14078"
    },
    "percentiles4": {
        "total": "19513",
        "ok": "19706",
        "ko": "17232"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 22108,
    "percentage": 3
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 5326,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 626948,
    "percentage": 82
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 113635,
    "percentage": 15
},
    "meanNumberOfRequestsPerSecond": {
        "total": "697.563",
        "ok": "594.352",
        "ko": "103.211"
    }
},
contents: {
"req_-get--the-list--c0b76": {
        type: "REQUEST",
        name: "[GET] The list of available countries is presented.",
path: "[GET] The list of available countries is presented.",
pathFormatted: "req_-get--the-list--c0b76",
stats: {
    "name": "[GET] The list of available countries is presented.",
    "numberOfRequests": {
        "total": "150010",
        "ok": "65389",
        "ko": "84621"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "1",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "21016",
        "ok": "21016",
        "ko": "402"
    },
    "meanResponseTime": {
        "total": "5151",
        "ok": "11816",
        "ko": "1"
    },
    "standardDeviation": {
        "total": "6534",
        "ok": "4383",
        "ko": "12"
    },
    "percentiles1": {
        "total": "1",
        "ok": "13283",
        "ko": "0"
    },
    "percentiles2": {
        "total": "12960",
        "ok": "13859",
        "ko": "0"
    },
    "percentiles3": {
        "total": "14965",
        "ok": "16612",
        "ko": "1"
    },
    "percentiles4": {
        "total": "18255",
        "ok": "19714",
        "ko": "5"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 3135,
    "percentage": 2
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 641,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 61613,
    "percentage": 41
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 84621,
    "percentage": 56
},
    "meanNumberOfRequestsPerSecond": {
        "total": "136.249",
        "ok": "59.391",
        "ko": "76.858"
    }
}
    },"req_-get--the-list--3525d": {
        type: "REQUEST",
        name: "[GET] The list of available cities is presented.",
path: "[GET] The list of available cities is presented.",
pathFormatted: "req_-get--the-list--3525d",
stats: {
    "name": "[GET] The list of available cities is presented.",
    "numberOfRequests": {
        "total": "130778",
        "ok": "130778",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "20946",
        "ok": "20946",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "12059",
        "ok": "12059",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4110",
        "ok": "4110",
        "ko": "-"
    },
    "percentiles1": {
        "total": "13261",
        "ok": "13261",
        "ko": "-"
    },
    "percentiles2": {
        "total": "13850",
        "ok": "13848",
        "ko": "-"
    },
    "percentiles3": {
        "total": "16720",
        "ok": "16713",
        "ko": "-"
    },
    "percentiles4": {
        "total": "19654",
        "ok": "19654",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 5059,
    "percentage": 4
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 1104,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 124615,
    "percentage": 95
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "118.781",
        "ok": "118.781",
        "ko": "-"
    }
}
    },"req_-get--the-list--11d52": {
        type: "REQUEST",
        name: "[GET] The list of available origins is presented.",
path: "[GET] The list of available origins is presented.",
pathFormatted: "req_-get--the-list--11d52",
stats: {
    "name": "[GET] The list of available origins is presented.",
    "numberOfRequests": {
        "total": "65389",
        "ok": "65389",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "20948",
        "ok": "20948",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "12067",
        "ok": "12067",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4106",
        "ok": "4106",
        "ko": "-"
    },
    "percentiles1": {
        "total": "13247",
        "ok": "13247",
        "ko": "-"
    },
    "percentiles2": {
        "total": "13828",
        "ok": "13828",
        "ko": "-"
    },
    "percentiles3": {
        "total": "16663",
        "ok": "16663",
        "ko": "-"
    },
    "percentiles4": {
        "total": "19569",
        "ok": "19569",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2609,
    "percentage": 4
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 552,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 62228,
    "percentage": 95
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "59.391",
        "ok": "59.391",
        "ko": "-"
    }
}
    },"req_-get--the-list--0dc40": {
        type: "REQUEST",
        name: "[GET] The list of available destinations is presented.",
path: "[GET] The list of available destinations is presented.",
pathFormatted: "req_-get--the-list--0dc40",
stats: {
    "name": "[GET] The list of available destinations is presented.",
    "numberOfRequests": {
        "total": "65389",
        "ok": "65389",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "20942",
        "ok": "20942",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "12160",
        "ok": "12160",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3850",
        "ok": "3850",
        "ko": "-"
    },
    "percentiles1": {
        "total": "13249",
        "ok": "13249",
        "ko": "-"
    },
    "percentiles2": {
        "total": "13837",
        "ok": "13837",
        "ko": "-"
    },
    "percentiles3": {
        "total": "16428",
        "ok": "16428",
        "ko": "-"
    },
    "percentiles4": {
        "total": "18786",
        "ok": "18786",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1974,
    "percentage": 3
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 481,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 62934,
    "percentage": 96
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "59.391",
        "ok": "59.391",
        "ko": "-"
    }
}
    },"req_-get--the-list--8bddb": {
        type: "REQUEST",
        name: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
path: "[GET] The list of available transfers by selected origin, destination, and date is presented.",
pathFormatted: "req_-get--the-list--8bddb",
stats: {
    "name": "[GET] The list of available transfers by selected origin, destination, and date is presented.",
    "numberOfRequests": {
        "total": "65389",
        "ok": "36391",
        "ko": "28998"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "4",
        "ko": "3"
    },
    "maxResponseTime": {
        "total": "20954",
        "ok": "20954",
        "ko": "20948"
    },
    "meanResponseTime": {
        "total": "12232",
        "ok": "12233",
        "ko": "12230"
    },
    "standardDeviation": {
        "total": "3817",
        "ok": "3817",
        "ko": "3816"
    },
    "percentiles1": {
        "total": "13286",
        "ok": "13294",
        "ko": "13276"
    },
    "percentiles2": {
        "total": "13858",
        "ok": "13860",
        "ko": "13856"
    },
    "percentiles3": {
        "total": "16739",
        "ok": "16742",
        "ko": "16636"
    },
    "percentiles4": {
        "total": "19122",
        "ok": "19107",
        "ko": "19198"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 876,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 254,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 35261,
    "percentage": 54
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 28998,
    "percentage": 44
},
    "meanNumberOfRequestsPerSecond": {
        "total": "59.391",
        "ok": "33.053",
        "ko": "26.338"
    }
}
    },"req_-post--the-tran-5ac29": {
        type: "REQUEST",
        name: "[POST] The transfer is booked in the system.",
path: "[POST] The transfer is booked in the system.",
pathFormatted: "req_-post--the-tran-5ac29",
stats: {
    "name": "[POST] The transfer is booked in the system.",
    "numberOfRequests": {
        "total": "36391",
        "ok": "36380",
        "ko": "11"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "6196"
    },
    "maxResponseTime": {
        "total": "20948",
        "ok": "20948",
        "ko": "17695"
    },
    "meanResponseTime": {
        "total": "12324",
        "ok": "12324",
        "ko": "11987"
    },
    "standardDeviation": {
        "total": "3923",
        "ok": "3923",
        "ko": "3603"
    },
    "percentiles1": {
        "total": "13357",
        "ok": "13357",
        "ko": "13067"
    },
    "percentiles2": {
        "total": "13932",
        "ok": "13935",
        "ko": "14071"
    },
    "percentiles3": {
        "total": "17372",
        "ok": "17371",
        "ko": "16003"
    },
    "percentiles4": {
        "total": "20261",
        "ok": "20261",
        "ko": "17357"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 636,
    "percentage": 2
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 289,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 35455,
    "percentage": 97
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 11,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "33.053",
        "ok": "33.043",
        "ko": "0.01"
    }
}
    },"req_-get--the-list--4f742": {
        type: "REQUEST",
        name: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
path: "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
pathFormatted: "req_-get--the-list--4f742",
stats: {
    "name": "[GET] The list of all my transfers (COMPLETED, CANCELED, BOOKED) is presented.",
    "numberOfRequests": {
        "total": "36391",
        "ok": "36386",
        "ko": "5"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "9",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "20965",
        "ok": "20965",
        "ko": "0"
    },
    "meanResponseTime": {
        "total": "12260",
        "ok": "12261",
        "ko": "0"
    },
    "standardDeviation": {
        "total": "3963",
        "ok": "3960",
        "ko": "0"
    },
    "percentiles1": {
        "total": "13356",
        "ok": "13356",
        "ko": "0"
    },
    "percentiles2": {
        "total": "13926",
        "ok": "13929",
        "ko": "0"
    },
    "percentiles3": {
        "total": "17200",
        "ok": "17210",
        "ko": "0"
    },
    "percentiles4": {
        "total": "20245",
        "ok": "20246",
        "ko": "0"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 511,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 267,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 35608,
    "percentage": 98
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 5,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "33.053",
        "ok": "33.048",
        "ko": "0.005"
    }
}
    },"req_-get--one-of-th-c14cc": {
        type: "REQUEST",
        name: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
path: "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
pathFormatted: "req_-get--one-of-th-c14cc",
stats: {
    "name": "[GET] One of the transfers (COMPLETED, CANCELED, BOOKED) is retrieved.",
    "numberOfRequests": {
        "total": "36380",
        "ok": "36380",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "20958",
        "ok": "20958",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "12165",
        "ok": "12165",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4041",
        "ok": "4041",
        "ko": "-"
    },
    "percentiles1": {
        "total": "13303",
        "ok": "13303",
        "ko": "-"
    },
    "percentiles2": {
        "total": "13892",
        "ok": "13892",
        "ko": "-"
    },
    "percentiles3": {
        "total": "17431",
        "ok": "17431",
        "ko": "-"
    },
    "percentiles4": {
        "total": "20224",
        "ok": "20224",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 396,
    "percentage": 1
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 261,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 35723,
    "percentage": 98
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "33.043",
        "ok": "33.043",
        "ko": "-"
    }
}
    },"req_-put--any--book-143cf": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer description is updated.",
path: "[PUT] Any (BOOKED) transfer description is updated.",
pathFormatted: "req_-put--any--book-143cf",
stats: {
    "name": "[PUT] Any (BOOKED) transfer description is updated.",
    "numberOfRequests": {
        "total": "36380",
        "ok": "36380",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "20949",
        "ok": "20949",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "12032",
        "ok": "12032",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4166",
        "ok": "4166",
        "ko": "-"
    },
    "percentiles1": {
        "total": "13304",
        "ok": "13304",
        "ko": "-"
    },
    "percentiles2": {
        "total": "13902",
        "ok": "13903",
        "ko": "-"
    },
    "percentiles3": {
        "total": "17157",
        "ok": "17157",
        "ko": "-"
    },
    "percentiles4": {
        "total": "19857",
        "ok": "19857",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 585,
    "percentage": 2
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 395,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 35400,
    "percentage": 97
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "33.043",
        "ok": "33.043",
        "ko": "-"
    }
}
    },"req_-put--any--book-bb16d": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
path: "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
pathFormatted: "req_-put--any--book-bb16d",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is canceled (CANCELED).",
    "numberOfRequests": {
        "total": "36380",
        "ok": "36380",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "20943",
        "ok": "20943",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "11860",
        "ok": "11860",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4267",
        "ok": "4267",
        "ko": "-"
    },
    "percentiles1": {
        "total": "13258",
        "ok": "13258",
        "ko": "-"
    },
    "percentiles2": {
        "total": "13836",
        "ok": "13838",
        "ko": "-"
    },
    "percentiles3": {
        "total": "16856",
        "ok": "16856",
        "ko": "-"
    },
    "percentiles4": {
        "total": "19582",
        "ok": "19582",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 965,
    "percentage": 3
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 384,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 35031,
    "percentage": 96
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "33.043",
        "ok": "33.043",
        "ko": "-"
    }
}
    },"req_-put--any--book-fdf7e": {
        type: "REQUEST",
        name: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
path: "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
pathFormatted: "req_-put--any--book-fdf7e",
stats: {
    "name": "[PUT] Any (BOOKED) transfer is completed (COMPLETED).",
    "numberOfRequests": {
        "total": "36380",
        "ok": "36380",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "21001",
        "ok": "21001",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "11714",
        "ok": "11714",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4405",
        "ok": "4405",
        "ko": "-"
    },
    "percentiles1": {
        "total": "13206",
        "ok": "13211",
        "ko": "-"
    },
    "percentiles2": {
        "total": "13800",
        "ok": "13799",
        "ko": "-"
    },
    "percentiles3": {
        "total": "16825",
        "ok": "16825",
        "ko": "-"
    },
    "percentiles4": {
        "total": "19578",
        "ok": "19577",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1396,
    "percentage": 4
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 293,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 34691,
    "percentage": 95
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "33.043",
        "ok": "33.043",
        "ko": "-"
    }
}
    },"req_-get--user-is-r-f03f4": {
        type: "REQUEST",
        name: "[GET] User is retrieved with her/his transfers data.",
path: "[GET] User is retrieved with her/his transfers data.",
pathFormatted: "req_-get--user-is-r-f03f4",
stats: {
    "name": "[GET] User is retrieved with her/his transfers data.",
    "numberOfRequests": {
        "total": "36380",
        "ok": "36380",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "20937",
        "ok": "20937",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "11589",
        "ok": "11589",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4548",
        "ok": "4548",
        "ko": "-"
    },
    "percentiles1": {
        "total": "13235",
        "ok": "13235",
        "ko": "-"
    },
    "percentiles2": {
        "total": "13819",
        "ok": "13819",
        "ko": "-"
    },
    "percentiles3": {
        "total": "16691",
        "ok": "16697",
        "ko": "-"
    },
    "percentiles4": {
        "total": "19542",
        "ok": "19540",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1753,
    "percentage": 5
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 223,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 34404,
    "percentage": 95
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "33.043",
        "ok": "33.043",
        "ko": "-"
    }
}
    },"req_-put--user-upda-c8c46": {
        type: "REQUEST",
        name: "[PUT] User updates with her/his own data.",
path: "[PUT] User updates with her/his own data.",
pathFormatted: "req_-put--user-upda-c8c46",
stats: {
    "name": "[PUT] User updates with her/his own data.",
    "numberOfRequests": {
        "total": "36380",
        "ok": "36380",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "20942",
        "ok": "20942",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "11428",
        "ok": "11428",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4641",
        "ok": "4641",
        "ko": "-"
    },
    "percentiles1": {
        "total": "13229",
        "ok": "13229",
        "ko": "-"
    },
    "percentiles2": {
        "total": "13799",
        "ok": "13798",
        "ko": "-"
    },
    "percentiles3": {
        "total": "16086",
        "ok": "16086",
        "ko": "-"
    },
    "percentiles4": {
        "total": "18625",
        "ok": "18625",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2213,
    "percentage": 6
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 182,
    "percentage": 1
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 33985,
    "percentage": 93
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "33.043",
        "ok": "33.043",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
